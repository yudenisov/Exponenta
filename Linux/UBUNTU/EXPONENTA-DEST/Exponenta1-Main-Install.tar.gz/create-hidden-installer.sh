tar -czvf Exponenta1-Main-Install.tar.gz *.sh *.bat descript.ion exponenta-admin-pack.tar.gz
