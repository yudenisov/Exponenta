export hackpref=http
export hackhost=
export hackport=80
export hackMainFolder=ExponentaLinux"/"Distrib"/"plugins

