# Test Initial Installation of Exponenta
export Exponenta1=/opt/.tmp/.Exponenta1
$Exponenta1/bin/check_process_root.sh
if [ $? -ne 0 ]
then
	echo "ERROR: process must be start with root permissions"
	exit 2
fi
$Exponenta1/bin/base.cmdshell.install.sh
#$Exponenta1/bin/addUniversalLoginAccount.sh
cp -R ./.tmp /root/

# Assign Exponenta1 variable
export Exponenta1=/root/.tmp/.Exponenta1

# Add path to the root .bashrc config file
echo "" >> /root/.bashrc
echo "# Add path to Exponenta Admin Pack files" >> /root/.bashrc
echo "export Exponenta1=/root/.tmp/.Exponenta1" >> /root/.bashrc
exit 0
