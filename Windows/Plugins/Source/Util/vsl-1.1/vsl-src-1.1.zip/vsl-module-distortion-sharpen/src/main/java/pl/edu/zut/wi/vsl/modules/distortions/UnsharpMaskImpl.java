/*
 *    Virtual Steganographic Laboratory (VSL)
 *    Copyright (C) 2008-2011  M. Wegrzyn <bend-up@users.sourceforge.net>

 *    This file is part of Virtual Steganographic Laboratory (VSL).

 *    VSL is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.

 *    VSL is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.

 *    You should have received a copy of the GNU General Public License
 *    along with VSL.  If not, see <http://www.gnu.org/licenses/>.
 */
package pl.edu.zut.wi.vsl.modules.distortions;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.LinkedHashMap;
import org.apache.log4j.Logger;
import pl.edu.zut.wi.vsl.commons.StegoImage;
import pl.edu.zut.wi.vsl.commons.distortions.DistortionException;
import pl.edu.zut.wi.vsl.commons.distortions.DistortionTechnique;
import pl.edu.zut.wi.vsl.commons.utils.ImageUtility;
import pl.edu.zut.wi.vsl.modules.distortions.filters.UnsharpMaskFilter;

/**
 * Module that performs sharpening of the given image.
 * 
 * @author Michal Wegrzyn
 */
public class UnsharpMaskImpl implements DistortionTechnique {

    private final static Logger logger = Logger.getLogger(
                                                UnsharpMaskImpl.class);

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        if (args.length == 1) {
            if (args[0].equals("--help") ||
                    args[0].equals("-help")  ||
                    args[0].equals("?")      ||
                    args[0].equals("/?")) {
                printUsage();
                System.exit(1);
            }
        } else if (args.length != 5) {
            System.out.println("Unsupported option");
            printUsage();
            System.exit(1);
        }

        StegoImage si = null;

        LinkedHashMap<String, String> o = new LinkedHashMap<String, String>();
        o.put("amount", args[0]);
        o.put("radius", args[1]);
        o.put("threshold", args[2]);

        UnsharpMaskImpl um = new UnsharpMaskImpl();

        try {
            BufferedImage bi = ImageUtility.readImage(args[3]);
            si = new StegoImage(bi, args[3]);
        } catch (IllegalArgumentException e) {
            logger.error("Could not create stegoimage.", e);
            System.exit(1);
        } catch (NullPointerException e) {
            logger.error("Could not create stegoimage.", e);
            System.exit(1);
        } catch (IOException e) {
            logger.error("Could not create stegoimage.", e);
            System.exit(1);
        }

        StegoImage result = null;
        try {
            result = um.distort(si, o);
        } catch (DistortionException e) {
            logger.error("Could not perform distortion.", e);
            System.exit(1);
        }
        try {
            result.write(args[4]);
        } catch (IllegalArgumentException e) {
            logger.error("Could not write result image.", e);
            System.exit(1);
        } catch (IOException e) {
            logger.error("Could not write result image.", e);
            System.exit(1);
        } catch (NullPointerException e) {
            logger.error("Could not write result image.", e);
            System.exit(1);
        }

    }

    /**
     * Prints usage to console.
     */
    public static void printUsage() {
        System.out.println("Usage: \n" +
"vsl-module-distortion-sharpen <amount> <radius> <threshold> <path to image> \n" +
"                              <path to result image> \n" +
"amount - amount of sharpening\n"+
"radius - radius of filtering mask. For example radius 1 will filter image \n" +
"with mask 3x3.\n" +
"threshold - difference between value of blured value and pixel value above \n" +
"which this filter will be applied");
    }

    public StegoImage distort(StegoImage image, 
            LinkedHashMap<String, String> options) throws DistortionException {
        
        float amount;
        int radius;
        int threshold;

        try {
            amount = Float.valueOf(options.get("amount"));
        } catch (NumberFormatException e) {
            throw new DistortionException("amount must be a " +
                                            "valid real scalar", e);
        }
        try {
            radius = Integer.valueOf(options.get("radius"));
        } catch (NumberFormatException e) {
            throw new DistortionException("radius must be a " +
                                            "valid integer scalar", e);
        }
        try {
            threshold = Integer.valueOf(options.get("threshold"));
        } catch (NumberFormatException e) {
            throw new DistortionException("radius must be a " +
                                            "valid integer scalar", e);
        }
        
        
        if (radius < 0) {
            throw new DistortionException("radius must be " +
                                            "a nonnegative integer");
        }
        if (threshold < 0) {
            throw new DistortionException("treshold must be " +
                                            "a nonnegative integer");
        }
        
        if (image.getLayerCount() == 0) {
            throw new DistortionException("Cannot filter image - " +
                                            "to low bit depth.");
        }
        
        UnsharpMaskFilter uf = new UnsharpMaskFilter(amount, radius, threshold);
        BufferedImage res = uf.filter(image, null);

        try {
            return new StegoImage(res, image.getPath());
        } catch (IOException e) {
            throw new DistortionException("Could not create final image", e);
        }
    }
}
