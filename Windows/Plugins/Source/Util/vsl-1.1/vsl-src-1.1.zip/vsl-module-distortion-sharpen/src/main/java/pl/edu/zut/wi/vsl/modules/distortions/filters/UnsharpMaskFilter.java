/*
 *    Virtual Steganographic Laboratory (VSL)
 *    Copyright (C) 2008-2011  M. Wegrzyn <bend-up@users.sourceforge.net>

 *    This file is part of Virtual Steganographic Laboratory (VSL).

 *    VSL is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.

 *    VSL is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.

 *    You should have received a copy of the GNU General Public License
 *    along with VSL.  If not, see <http://www.gnu.org/licenses/>.
 */
package pl.edu.zut.wi.vsl.modules.distortions.filters;

import java.awt.image.BufferedImage;
import pl.edu.zut.wi.vsl.commons.distortions.AbstractPixelFilter;
import pl.edu.zut.wi.vsl.commons.utils.ImageUtility;

/**
 * A filter which sharpens image by subtracting Gaussian blur from it.
 * <p>
 * Unsharp masking subtracts a blurred copy of the image and re-scales the image
 * to obtain the same contrast of large (low-frequency) structures as in the
 * input image. This is equivalent to adding a high-pass filtered image and
 * thus sharpens the image.
 * 
 * @see pl.edu.zut.wi.vsl.modules.distortions.filters.GaussianBlurFilter;
 * @author Michal Wegrzyn
 */
public class UnsharpMaskFilter extends AbstractPixelFilter {
    
    private final float amount;
    private final int radius;
    private final int threshold;

    public UnsharpMaskFilter() {
        this(1f, 1, 2);
    }
    
    /**
     * A filter which subtracts Gaussian blur from an image, sharpening it.
     * @param amount Amount of sharpening
     * @param radius Radius (Sigma) is the standard deviation
     * (blur radius) of the Gaussian blur that is subtracted.
     * @param threshold Difference between value of blurred value and
     * pixel value above which this filter will be applied.
     */
    public UnsharpMaskFilter(float amount, int radius, int threshold) {
        this.amount = amount;
        this.radius = radius;
        this.threshold = threshold;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public BufferedImage filter(BufferedImage src, BufferedImage dst) {
        int width = src.getWidth();
        int height = src.getHeight();

        if (dst == null) {
            dst = createCompatibleDestImage(src, null);
        }

        int[] srcPixels = new int[width * height];
        int[] dstPixels = new int[width * height];

        float[] kernel = GaussianBlurFilter.createGaussianKernel(radius);

        ImageUtility.getPixels(src, 0, 0, width, height, srcPixels);
        /* horizontal pass */
        GaussianBlurFilter.blur(srcPixels, dstPixels, width, 
                                            height, kernel, radius);
        /* vertical pass */
        GaussianBlurFilter.blur(dstPixels, srcPixels, 
                                            height, width, kernel, radius);
        /* blurred image is in srcPixels, we copy the original to dstPixels */
        ImageUtility.getPixels(src, 0, 0, width, height, dstPixels);
        /* sharpen and store the result in srcPixels */
        sharpen(dstPixels, srcPixels, width, height, amount, threshold);
        /* the result is now stored in srcPixels due to the second pass */
        ImageUtility.setPixels(dst, 0, 0, width, height, srcPixels);
        
        return dst;
    }

    static void sharpen(int[] original, int[] blurred, int width, int height,
            float amount, int threshold) {
        
        int index = 0;
        int srcR;
        int srcB;
        int srcG;
        int destR; 
        int destB;
        int destG;
                
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                int srcColor = original[index];
                srcR = (srcColor >> 16) & 0xFF;
                srcG = (srcColor >>  8) & 0xFF;
                srcB = (srcColor      ) & 0xFF;
                
                int dstColor = blurred[index];
                destR = (dstColor >> 16) & 0xFF;
                destG = (dstColor >>  8) & 0xFF;
                destB = (dstColor      ) & 0xFF;
                
                if (Math.abs(srcR - destR) >= threshold) {
                    srcR = (int) (amount * (srcR - destR) + srcR);
                    srcR = ImageUtility.clamp(srcR);
                }
                
                if (Math.abs(srcG - destG) >= threshold) {
                    srcG = (int) (amount * (srcG - destG) + srcG);
                    srcG = ImageUtility.clamp(srcG);
                }

                if (Math.abs(srcB - destB) >= threshold) {
                    srcB = (int) (amount * (srcB - destB) + srcB);
                    srcB = ImageUtility.clamp(srcB);
                }
                
                int alpha = srcColor & 0xFF000000;
                blurred[index] = alpha | (srcR << 16) | (srcG << 8) | srcB;

                index++;
            }
        }
    }
}