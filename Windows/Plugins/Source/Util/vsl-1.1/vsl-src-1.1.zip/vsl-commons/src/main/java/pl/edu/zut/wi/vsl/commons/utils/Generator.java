/*
 *    Virtual Steganographic Laboratory (VSL)
 *    Copyright (C) 2008-2011  M. Wegrzyn <bend-up@users.sourceforge.net>

 *    This file is part of Virtual Steganographic Laboratory (VSL).

 *    VSL is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.

 *    VSL is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.

 *    You should have received a copy of the GNU General Public License
 *    along with VSL.  If not, see <http://www.gnu.org/licenses/>.
 */
package pl.edu.zut.wi.vsl.commons.utils;

import java.security.SecureRandom;

/**
 * Class providing generating secure random numbers.
 * 
 * @author Michal Wegrzyn
 */
public class Generator {

    /**
     * Returns array with given length with randomly placed integers
     * in "from" (inclusive) to "to" (exclusive) range.
     * @param from Lowest number which returned array should contain
     * @param to Highest number which returned array should contain
     * @return array with numbers in given range with random placement.
     */
    public static int[] getRandIntArray(int from, int to) {
        int[] arr = new int[to - from + 1];
        // initialize array with succesive integers
        for (int i = 0; i < arr.length; i++) {
            arr[i] = from + i;
        }
        // randomize array
        randomizeArray(arr);
        
        return arr;
    }
    
    /**
     * Randomizes given array - rearranges randomly elements.
     * @param a Array to randomize
     */
    private static void randomizeArray(int a[]) {
        SecureRandom sr = new SecureRandom();
        
        for (int j = (a.length - 1); j >= 0; j--) {
            int random = sr.nextInt(a.length);
            if (random != j) {
                int tmp = a[j];
                a[j] = a[random];
                a[random] = tmp;
            }
        }
    }
}
