/*
 *    Virtual Steganographic Laboratory (VSL)
 *    Copyright (C) 2008-2011  M. Wegrzyn <bend-up@users.sourceforge.net>

 *    This file is part of Virtual Steganographic Laboratory (VSL).

 *    VSL is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.

 *    VSL is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.

 *    You should have received a copy of the GNU General Public License
 *    along with VSL.  If not, see <http://www.gnu.org/licenses/>.
 */
package pl.edu.zut.wi.vsl.commons;

import pl.edu.zut.wi.vsl.commons.utils.ImageUtility;

/**
 * Class for performing various types of benchmarks.
 * 
 * @author Michal Wegrzyn
 */
public class Benchmark {


    /**
     * Calculates Peak Signal to Noise Ratio between original and changed
     * image.
     * @param img1 Original image
     * @param img2 Changed image
     * @return PSNR between given images.
     */
    public static double calculatePSNR(StegoImage img1, StegoImage img2) {

        int size = img1.getHeight()*img1.getWidth();
        int px1, px2;
        
        if (img1.getLayerCount() == 3) {
            double peakR = 0;
            double peakG = 0;
            double peakB = 0;        
            double noiseR = 0;
            double noiseG = 0;
            double noiseB = 0;
            double psnrR = 0;
            double psnrG = 0;
            double psnrB = 0;
            int pxr1, pxg1, pxb1, pxr2, pxg2, pxb2;

            try {
                for (int i = 0; i < img1.getHeight(); i++) {
                    for (int j = 0; j < img1.getWidth(); j++) {
                        px1 = img1.getRGB(j, i);
                        px2 = img2.getRGB(j, i);
                        pxr1 = ImageUtility.getRed(px1);
                        pxg1 = ImageUtility.getGreen(px1);
                        pxb1 = ImageUtility.getBlue(px1);
                        pxr2 = ImageUtility.getRed(px2);
                        pxg2 = ImageUtility.getGreen(px2);
                        pxb2 = ImageUtility.getBlue(px2);

                        //signal += px1 * px1;
                        noiseR += (pxr1 - pxr2) * (pxr1 - pxr2);
                        noiseG += (pxg1 - pxg2) * (pxg1 - pxg2);
                        noiseB += (pxb1 - pxb2) * (pxb1 - pxb2);
                        if (peakR < pxr1)
                          peakR = pxr1;
                        if (peakG < pxg1)
                          peakG = pxg1;
                        if (peakB < pxb1)
                          peakB = pxb1;
                    }
                }
            } catch (ArrayIndexOutOfBoundsException e ){
                return -1;
            }
            // Mean square error
            double mseR = noiseR / size;
            double mseG = noiseG / size;
            double mseB = noiseB / size;

            psnrR = mseR == 0 ? 0 :  10 * Math.log10((peakR * peakR) / mseR);
            psnrG = mseG == 0 ? 0 :  10 * Math.log10((peakG * peakG) / mseG);
            psnrB = mseB == 0 ? 0 :  10 * Math.log10((peakB * peakB) / mseB);

            return (psnrR + psnrG + psnrB) / 3;
        } else if (img1.getLayerCount() == 1) {
            double noise = 0;
            double peak = 0;

            try {
                for (int i = 0; i < img1.getHeight(); i++) {
                    for (int j = 0; j < img1.getWidth(); j++) {
                        px1 = img1.getRaster().getSample(i, j, 0);
                        px2 = img2.getRaster().getSample(i, j, 0);
                        noise += (px1 - px2) * (px1 - px2);
                        if (peak < px1)
                            peak = px1;
                    }
                }
            } catch (ArrayIndexOutOfBoundsException e ){
                return -1;
            }
            double mse = noise / size;
            
            return mse == 0 ? 0 : 10 * Math.log10((peak * peak) / mse);
        } else {
            return -1;
        }
    }
    
    /**
     * Calculates Relative Peak Signal to Noise Ratio between 
     * original and changed image.
     * @param img1 Original image
     * @param img2 Changed image
     * @return PSNR between given images.
     */
    public static double calculateRPSNR(StegoImage img1, StegoImage img2) {

        int size = img1.getHeight()*img1.getWidth();
        int px1, px2, tmp, tmp2;
        
        if (img1.getLayerCount() == 3) {
            double peakR = 0;
            double peakG = 0;
            double peakB = 0;  
            double noiseR = 0;
            double noiseG = 0;
            double noiseB = 0;
            double rpsnrR = 0;
            double rpsnrG = 0;
            double rpsnrB = 0;
            int pxr1, pxg1, pxb1, pxr2, pxg2, pxb2;

            try {
                for (int i = 0; i < img1.getHeight(); i++) {
                    for (int j = 0; j < img1.getWidth(); j++) {
                        px1 = img1.getRGB(j, i);
                        px2 = img2.getRGB(j, i);
                        pxr1 = ImageUtility.getRed(px1);
                        pxg1 = ImageUtility.getGreen(px1);
                        pxb1 = ImageUtility.getBlue(px1);
                        pxr2 = ImageUtility.getRed(px2);
                        pxg2 = ImageUtility.getGreen(px2);
                        pxb2 = ImageUtility.getBlue(px2);

                        tmp = (tmp2 = Math.abs(pxr1 + pxr2)) == 0
                                            ? 0
                                            : (2 * Math.abs(pxr1 - pxr2) / tmp2 );
                        noiseR += tmp * tmp;
                        tmp = (tmp2 = Math.abs(pxg1 + pxg2)) == 0
                                            ? 0
                                            : (2 * Math.abs(pxg1 - pxg2) / tmp2 );
                        noiseG += tmp * tmp;
                        tmp = (tmp2 = Math.abs(pxb1 + pxb2)) == 0
                                            ? 0
                                            : (2 * Math.abs(pxb1 - pxb2) / tmp2 );
                        noiseB += tmp * tmp;
                        if (peakR < pxr1)
                          peakR = pxr1;
                        if (peakG < pxg1)
                          peakG = pxg1;
                        if (peakB < pxb1)
                          peakB = pxb1;
                    }
                }
            } catch (ArrayIndexOutOfBoundsException e ){
                return -1;
            }

            // Relative mean square error for image 
            double rmseR = noiseR / size;
            double rmseG = noiseG / size;
            double rmseB = noiseB / size;

            rpsnrR = rmseR == 0 ? 0 : 10 * Math.log10((peakR * peakR) / rmseR);
            rpsnrG = rmseG == 0 ? 0 : 10 * Math.log10((peakG * peakG) / rmseG);
            rpsnrB = rmseB == 0 ? 0 : 10 * Math.log10((peakB * peakB) / rmseB);

            return (rpsnrR + rpsnrG + rpsnrB) / 3;
        } else if (img1.getLayerCount() == 1) {
            double noise = 0;
            double peak = 0;

            try {
                for (int i = 0; i < img1.getHeight(); i++) {
                    for (int j = 0; j < img1.getWidth(); j++) {
                        px1 = img1.getRaster().getSample(i, j, 0);
                        px2 = img2.getRaster().getSample(i, j, 0);
                        tmp = (tmp2 = Math.abs(px1 + px2)) == 0
                                            ? 0
                                            : (2 * Math.abs(px1 - px2) / tmp2 );
                        noise += tmp * tmp;
                        if (peak < px1)
                            peak = px1;
                    }
                }
            } catch (ArrayIndexOutOfBoundsException e ){
                return -1;
            }
            
            double rmse = noise / size;
            
            return rmse == 0 ? 0 : 10 * Math.log10((peak * peak) / rmse);
        } else {
            return -1;
        }
    }
    
}
