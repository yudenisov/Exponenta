/*
 *    Virtual Steganographic Laboratory (VSL)
 *    Copyright (C) 2008-2011  M. Wegrzyn <bend-up@users.sourceforge.net>

 *    This file is part of Virtual Steganographic Laboratory (VSL).

 *    VSL is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.

 *    VSL is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.

 *    You should have received a copy of the GNU General Public License
 *    along with VSL.  If not, see <http://www.gnu.org/licenses/>.
 */
package pl.edu.zut.wi.vsl.commons.utils;

import java.awt.Graphics;
import java.awt.GraphicsConfiguration;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.awt.HeadlessException;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.Transparency;
import java.awt.color.ColorSpace;
import java.awt.image.BufferedImage;
import java.awt.image.ColorModel;
import java.awt.image.ComponentColorModel;
import java.awt.image.DataBuffer;
import java.awt.image.DataBufferByte;
import java.awt.image.Raster;
import java.awt.image.SampleModel;
import java.awt.image.WritableRaster;
import javax.swing.ImageIcon;

/**
 * Class for various image converting.
 * 
 * @author Michal Wegrzyn
 */
public class ImageConverter {

    /**
     * Default constructor.
     */
    public ImageConverter() {
    }

    /**
     * Converts <code>BufferedImage</code> to byte array.
     * @param img <code>BufferedImage</code> that has to be converted.
     * @return byte[] of image.
     */
    public static byte[] imageToByte(BufferedImage img) {

        WritableRaster raster = img.getRaster();
        DataBufferByte buffer = (DataBufferByte) raster.getDataBuffer();
        return buffer.getData();
    }

    /**
     * Converts byte array to a <code>BufferedImage</code>.
     * @param bytes byte[] of image
     * @return <code>BufferedImage</code> created from bytes
     */
    public static BufferedImage byteToImage(int width, int height, 
                                            byte[] bytes, int[] sampleSize, 
                                            ColorSpace ics, int transparency, 
                                            boolean alpha) {

        ColorModel cm = new ComponentColorModel(ics, sampleSize, alpha, 
                                    alpha, transparency, DataBuffer.TYPE_BYTE);
        SampleModel sm = cm.createCompatibleSampleModel(width, height);
        DataBufferByte db = new DataBufferByte(bytes, width * height);
        WritableRaster raster = Raster.createWritableRaster(sm, db, null);
        return new BufferedImage(cm, raster, false, null);

    }

    /**
     * Returns <code>BufferedImage</code> representation of 
     * an <code>Image</code> compatible with the given instance of 
     * <code>BufferedImage</code>.
     * @param image Image that should be converted
     * @param source image to which result should be compatible.
     * @return <code>BufferedImage</code> representation of an Image compatible 
     * to the given <code>BufferedImage</code>.
     */
    public static BufferedImage toCompatibleBufferedImage(Image image, 
                                                        BufferedImage source) {
        if (image instanceof BufferedImage) {
            return (BufferedImage) image;
        }

        /* This code ensures that all the pixels in the image are loaded */
        image = new ImageIcon(image).getImage();

        ColorModel destCM = source.getColorModel();

        /* Create a buffered image with a format that's 
         * compatible with the screen */
        BufferedImage bimage = new BufferedImage(destCM,
                destCM.createCompatibleWritableRaster(
                image.getWidth(null), image.getHeight(null)),
                destCM.isAlphaPremultiplied(), null);

        /* Copy image to buffered image */
        Graphics g = bimage.createGraphics();

        /* Paint the image onto the buffered image */
        g.drawImage(image, 0, 0, null);
        g.dispose();

        return bimage;
    }

    /**
     * Returns <code>BufferedImage</code> from an <code>Image</code> object.
     * @param image Image that should be converted.
     * @return <code>BufferedImage</code> representation of the given 
     * image.
     */
    public static BufferedImage toBufferedImage(Image image) {
        if (image instanceof BufferedImage) {
            return (BufferedImage) image;
        }

        /* This code ensures that all the pixels in the image are loaded */
        image = new ImageIcon(image).getImage();

        /* Determine if the image has transparent pixels */
        boolean hasAlpha = ImageUtility.hasAlpha(image);

        /* Create a buffered image with a format that's 
         * compatible with the screen */
        BufferedImage bimage = null;
        GraphicsEnvironment ge = 
                            GraphicsEnvironment.getLocalGraphicsEnvironment();
        try {
            /* Determine the type of transparency of the new buffered image */
            int transparency = Transparency.OPAQUE;
            if (hasAlpha == true) {
                transparency = Transparency.BITMASK;
            }

            /* Create the buffered image */
            GraphicsDevice gs = ge.getDefaultScreenDevice();
            GraphicsConfiguration gc = gs.getDefaultConfiguration();
            bimage = gc.createCompatibleImage(image.getWidth(null), 
                                        image.getHeight(null), transparency);
        } catch (HeadlessException e) {
        } //No screen

        if (bimage == null) {
            /* Create a buffered image using the default color model */
            int type = BufferedImage.TYPE_INT_RGB;
            if (hasAlpha == true) {
                type = BufferedImage.TYPE_INT_ARGB;
            }
            bimage = new BufferedImage(image.getWidth(null), 
                                        image.getHeight(null), type);
        }

        /* Copy image to buffered image */
        Graphics g = bimage.createGraphics();

        /* Paint the image onto the buffered image */
        g.drawImage(image, 0, 0, null);
        g.dispose();

        return bimage;
    }

    /**
     * Returns an <code>Image</code> object from a <code>BufferedImage</code>.
     * @param bufferedImage Image that should be converted.
     * @return <code>Image</code> object representation of the given 
     * <code>BufferedImage</code>.
     */
    public static Image toImage(BufferedImage bufferedImage) {
        return Toolkit.getDefaultToolkit().createImage(
                                                bufferedImage.getSource());
    }
}