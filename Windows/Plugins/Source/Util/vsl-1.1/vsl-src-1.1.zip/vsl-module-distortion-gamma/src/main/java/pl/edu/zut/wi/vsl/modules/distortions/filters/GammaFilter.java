/*
 *    Virtual Steganographic Laboratory (VSL)
 *    Copyright (C) 2008-2011  M. Wegrzyn <bend-up@users.sourceforge.net>

 *    This file is part of Virtual Steganographic Laboratory (VSL).

 *    VSL is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.

 *    VSL is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.

 *    You should have received a copy of the GNU General Public License
 *    along with VSL.  If not, see <http://www.gnu.org/licenses/>.
 */
package pl.edu.zut.wi.vsl.modules.distortions.filters;

import java.awt.image.BufferedImage;
import pl.edu.zut.wi.vsl.commons.distortions.AbstractPixelFilter;
import pl.edu.zut.wi.vsl.commons.utils.BitUtility;
import pl.edu.zut.wi.vsl.commons.utils.ImageUtility;

/**
 * Filter that performs gamma correction on the given image.
 * 
 * @author Michal Wegrzyn
 */
public class GammaFilter extends AbstractPixelFilter {

    private int[] rLut;
    private int[] gLut;
    private int[] bLut;

    /**
     * Creates <code>GammaFilter</code> with the given factors of gamma
     * correction for every color component.
     * @param rGamma gamma factor for the red component
     * @param gGamma gamma factor for the green component
     * @param bGamma gamma factor for the blue component
     */
    public GammaFilter(double rGamma, double gGamma, double bGamma) {
        rLut = makeLUT(rGamma);

        /* make Look Up Tables to speed up calculations */
        if (gGamma == rGamma) {
            gLut = rLut;
        } else {
            gLut = makeLUT(gGamma);
        }
        if (bGamma == rGamma) {
            bLut = rLut;
        } else if (bGamma == gGamma) {
            bLut = gLut;
        } else {
            bLut = makeLUT(bGamma);
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override    
    public BufferedImage filter(BufferedImage src, BufferedImage dst) {
        if (dst == null) {
            dst = createCompatibleDestImage(src, null);
        }

        int width = src.getWidth();
        int height = src.getHeight();
        int[] pixels = new int[width * height];
        ImageUtility.getPixels(src, 0, 0, width,
                height, pixels);

        for (int i = 0; i < pixels.length; i++) {
            int argb = pixels[i];
            byte[]  bytes = BitUtility.intToByteArray(argb);

            pixels[i] = BitUtility.byteArrayToInt(new byte[] {
                (byte) (bytes[0]&0xff),
                (byte) rLut[bytes[1]&0xff],
                (byte) gLut[bytes[2]&0xff],
                (byte) bLut[bytes[3]&0xff]});
        }

        ImageUtility.setPixels(dst, 0, 0, width,
                height, pixels);
        return dst;
    }

    /**
     * Makes Look Up Table for processing for the given gamma value.
     * @param gamma value of gamma factor
     * @return table which consist of calculated results for every 
     * possible pixel value.
     */
    private int[] makeLUT(double gamma) {
        int[] table = new int[256];
        for (int i = 0; i < 256; i++) {
            int v = (int) ((255.0 * Math.pow(i / 255.0, 1.0 / gamma)) + 0.5);
            if (v > 255) {
                v = 255;
            }
            table[i] = v;
        }
        return table;
    }
}