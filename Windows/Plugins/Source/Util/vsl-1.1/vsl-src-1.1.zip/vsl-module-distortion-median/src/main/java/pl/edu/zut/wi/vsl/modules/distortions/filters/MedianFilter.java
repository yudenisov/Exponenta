/*
 *    Virtual Steganographic Laboratory (VSL)
 *    Copyright (C) 2008-2011  M. Wegrzyn <bend-up@users.sourceforge.net>

 *    This file is part of Virtual Steganographic Laboratory (VSL).

 *    VSL is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.

 *    VSL is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.

 *    You should have received a copy of the GNU General Public License
 *    along with VSL.  If not, see <http://www.gnu.org/licenses/>.
 */
package pl.edu.zut.wi.vsl.modules.distortions.filters;

import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.Collections;
import pl.edu.zut.wi.vsl.commons.distortions.AbstractPixelFilter;
import pl.edu.zut.wi.vsl.commons.utils.BitUtility;
import pl.edu.zut.wi.vsl.commons.utils.ImageUtility;

/**
 * Filter that performs median filtering on the given image.
 * 
 * @author Michal Wegrzyn
 */
public class MedianFilter extends AbstractPixelFilter {

    private int radius;
    private int width;
    private int height;

    public MedianFilter() {
        radius = 1;
    }
        
    /** Creates MedianFilter with the given mask radius */
    public MedianFilter(int r) {
        radius = r;
    }

    /**
     * {@inheritDoc}
     */
    @Override    
    public BufferedImage filter(BufferedImage src, BufferedImage dst) {
        if (dst == null) {
            dst = createCompatibleDestImage(src, null);
        }

        width = src.getWidth();
        height = src.getHeight();
        int[] pixels = new int[width * height];
        int[] resultPixels = new int[width * height];
        ImageUtility.getPixels(src, 0, 0, width,
                height, pixels);

        for (int i = 0; i < pixels.length; i++) {
            resultPixels[i] = getMedian(i, pixels);
        }

        ImageUtility.setPixels(dst, 0, 0, width,
                height, resultPixels);
        return dst;
    }

    /**
     * Gets median for the pixel of the given index.
     * <p>
     * For the edges, where mask do no covers fully image, only existing
     * pixels are added to list and considered - there is no duplication of 
     * edge pixels and output image is same size as input image.
     * @param index Index of pixel which median should be returned
     * @param pixels One dimensional array of all image pixels
     * @return Median value from the list of values which consists of
     * the pixel and surrounding it pixels within #radius
     * @see java.util.Collections#sort(java.util.List) 
     */
    private int getMedian(int index, int[] pixels) {

        /* calculate column and row number of the pixel */
        int col = index % width;
        int row = index / width;

        /* create list for every color component */
        ArrayList<Integer> aa = new ArrayList<Integer>();
        ArrayList<Integer> ar = new ArrayList<Integer>();
        ArrayList<Integer> ag = new ArrayList<Integer>();
        ArrayList<Integer> ab = new ArrayList<Integer>();

        /* grab pixels around current pixel within radius */
        for (int i = -radius; i <= radius; i++) {
            for (int j = -radius; j <= radius; j++) {
                /* if index is beyond image do not add pixel to the list */
                if (col + j >= 0 && row + i >= 0 &&
                        col + j < width && row + i < height) {
                    int argb = pixels[index + i * width + j];
                    byte[] bs = BitUtility.intToByteArray(argb);

                    aa.add((int)(bs[0]&0xff));
                    ar.add((int)(bs[1]&0xff));
                    ag.add((int)(bs[2]&0xff));
                    ab.add((int)(bs[3]&0xff));
                }
            }
        }

        /* sort values */
        Collections.sort(aa);
        Collections.sort(ar);
        Collections.sort(ag);
        Collections.sort(ab);

        return BitUtility.byteArrayToInt(new byte[] {
                    (byte)aa.get(aa.size() / 2).intValue(),
                    (byte)ar.get(ar.size() / 2).intValue(),
                    (byte)ag.get(ag.size() / 2).intValue(),
                    (byte)ab.get(ab.size() / 2).intValue()
        });

    }
}