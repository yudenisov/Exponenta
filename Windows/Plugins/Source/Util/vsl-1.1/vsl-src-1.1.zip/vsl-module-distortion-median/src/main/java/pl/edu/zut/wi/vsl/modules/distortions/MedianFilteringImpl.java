/*
 *    Virtual Steganographic Laboratory (VSL)
 *    Copyright (C) 2008-2011  M. Wegrzyn <bend-up@users.sourceforge.net>

 *    This file is part of Virtual Steganographic Laboratory (VSL).

 *    VSL is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.

 *    VSL is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.

 *    You should have received a copy of the GNU General Public License
 *    along with VSL.  If not, see <http://www.gnu.org/licenses/>.
 */
package pl.edu.zut.wi.vsl.modules.distortions;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.LinkedHashMap;
import org.apache.log4j.Logger;
import pl.edu.zut.wi.vsl.commons.StegoImage;
import pl.edu.zut.wi.vsl.commons.distortions.DistortionException;
import pl.edu.zut.wi.vsl.commons.distortions.DistortionTechnique;
import pl.edu.zut.wi.vsl.commons.utils.ImageUtility;
import pl.edu.zut.wi.vsl.modules.distortions.filters.MedianFilter;

/**
 * Module that performs median filtering on the given image.
 * 
 * @author Michal Wegrzyn
 */
public class MedianFilteringImpl implements DistortionTechnique {

    private final static Logger logger = Logger.getLogger(
                                                MedianFilteringImpl.class);
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        if (args.length == 1) {
            if (args[0].equals("--help") ||
                    args[0].equals("-help")  ||
                    args[0].equals("?")      ||
                    args[0].equals("/?")) {
                printUsage();
                System.exit(1);
            }
        } else if (args.length != 3) {
            System.out.println("Unsupported option");
            printUsage();
            System.exit(1);
        }

        StegoImage si = null;

        LinkedHashMap<String, String> o = new LinkedHashMap<String, String>();
        o.put("radius", args[0]);

        MedianFilteringImpl sp = new MedianFilteringImpl();

        try {
            BufferedImage bi = ImageUtility.readImage(args[1]);
            si = new StegoImage(bi, args[1]);
        } catch (IllegalArgumentException e) {
            logger.error("Could not create stegoimage.", e);
            System.exit(1);
        } catch (NullPointerException e) {
            logger.error("Could not create stegoimage.", e);
            System.exit(1);
        } catch (IOException e) {
            logger.error("Could not create stegoimage.", e);
            System.exit(1);
        }

        StegoImage result = null;
        try {
            result = sp.distort(si, o);
        } catch (DistortionException e) {
            logger.error("Could not perform distortion.", e);
            System.exit(1);
        }
        try {
            result.write(args[2]);
        } catch (IllegalArgumentException e) {
            logger.error("Could not write result image.", e);
            System.exit(1);
        } catch (IOException e) {
            logger.error("Could not write result image.", e);
            System.exit(1);
        } catch (NullPointerException e) {
            logger.error("Could not write result image.", e);
            System.exit(1);
        }

    }

    /**
     * Prints usage to console.
     */
    public static void printUsage() {
        System.out.println("Usage: \n" +
"vsl-module-distortion-median <mask size> <path to image> \n" +
"                             <path to result image> \n" +
"radius - radius of filtering mask. For example radius 1 will filter image \n" +
"with mask 3x3.");
    }

    public StegoImage distort(StegoImage image, 
            LinkedHashMap<String, String> options) throws DistortionException {
        
        int r;
        
        try {
            r = Integer.valueOf(options.get("radius"));
        } catch (NumberFormatException e) {
            throw new DistortionException("radius must be a " +
                                            "valid integer scalar");
        }

        if (r < 0) {
            throw new DistortionException("radius must be " +
                                            "a nonnegative integer");
        }
                
        if (image.getLayerCount() == 0) {
            throw new DistortionException("Cannot filter image - " +
                                            "to low bit depth.");
        }
                
        MedianFilter sp = new MedianFilter(r);
        BufferedImage res = sp.filter(image, null);
        
        try {
            return new StegoImage(res, image.getPath());
        } catch (IOException e) {
            throw new DistortionException("Could not create final image", e);
        }
    }
}
