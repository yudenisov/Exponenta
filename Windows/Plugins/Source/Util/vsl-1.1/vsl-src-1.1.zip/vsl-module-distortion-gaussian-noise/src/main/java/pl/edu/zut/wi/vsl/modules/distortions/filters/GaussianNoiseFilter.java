/*
 *    Virtual Steganographic Laboratory (VSL)
 *    Copyright (C) 2008-2011  M. Wegrzyn <bend-up@users.sourceforge.net>

 *    This file is part of Virtual Steganographic Laboratory (VSL).

 *    VSL is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.

 *    VSL is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.

 *    You should have received a copy of the GNU General Public License
 *    along with VSL.  If not, see <http://www.gnu.org/licenses/>.
 */
package pl.edu.zut.wi.vsl.modules.distortions.filters;

import java.awt.image.BufferedImage;
import java.util.Random;
import pl.edu.zut.wi.vsl.commons.distortions.AbstractPixelFilter;
import pl.edu.zut.wi.vsl.commons.utils.BitUtility;
import pl.edu.zut.wi.vsl.commons.utils.ImageUtility;

/**
 * Filter that adds Gaussian noise to the image.
 * 
 * @author Michal Wegrzyn
 */
public class GaussianNoiseFilter extends AbstractPixelFilter {

    /** Mean of Gaussian noise. */
    private double mean;
    /** Variation of Gaussian noise. */
    private double variation;
    /** Random for generating random Gaussian numbers. */
    private Random random;

    public GaussianNoiseFilter() {
        this(0, 0.01);
    }

    /** Creates new GaussianNoiseFilter with the given mean and variation */
    public GaussianNoiseFilter(double m, double v) {
        mean = m;
        variation = v;
        random = new Random();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public BufferedImage filter(BufferedImage src, BufferedImage dst) {
        if (dst == null) {
            dst = createCompatibleDestImage(src, null);
        }

        int width = src.getWidth();
        int height = src.getHeight();
        int[] pixels = new int[width * height];
        ImageUtility.getPixels(src, 0, 0, width,
                height, pixels);

        for (int i = 0; i < pixels.length; i++) {

            int argb = pixels[i];
            byte[] bs = BitUtility.intToByteArray(argb);

            // noise
            int n = generateNoise();

            byte r = (byte) ImageUtility.clamp((int)(bs[1]&0xff) + n);
            byte g = (byte) ImageUtility.clamp((int)(bs[2]&0xff) + n);
            byte b = (byte) ImageUtility.clamp((int)(bs[3]&0xff) + n);

            pixels[i] = BitUtility.byteArrayToInt(new byte[] {bs[0], r, g, b});
        }

        ImageUtility.setPixels(dst, 0, 0, width,
                height, pixels);
        return dst;
    }

    private int generateNoise() {
        return (int) (Math.sqrt(variation) * random.nextGaussian() + mean);
    }
}
