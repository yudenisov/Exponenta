/*
 *    Virtual Steganographic Laboratory (VSL)
 *    Copyright (C) 2008-2011  M. Wegrzyn <bend-up@users.sourceforge.net>

 *    This file is part of Virtual Steganographic Laboratory (VSL).

 *    VSL is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.

 *    VSL is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.

 *    You should have received a copy of the GNU General Public License
 *    along with VSL.  If not, see <http://www.gnu.org/licenses/>.
 */
package pl.edu.zut.wi.vsl.modules.distortions;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.LinkedHashMap;
import org.apache.log4j.Logger;
import pl.edu.zut.wi.vsl.commons.StegoImage;
import pl.edu.zut.wi.vsl.commons.distortions.DistortionException;
import pl.edu.zut.wi.vsl.commons.distortions.DistortionTechnique;
import pl.edu.zut.wi.vsl.commons.utils.ImageUtility;
import pl.edu.zut.wi.vsl.modules.distortions.filters.GaussianNoiseFilter;

/**
 * Module that adds Gaussian noise to the image.
 * 
 * @author Michal Wegrzyn
 */
public class GaussianNoiseImpl implements DistortionTechnique {

    private final static Logger logger = Logger.getLogger(
                                                GaussianNoiseImpl.class);

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        if (args.length == 1) {
            if (args[0].equals("--help") ||
                    args[0].equals("-help")  ||
                    args[0].equals("?")      ||
                    args[0].equals("/?")) {
                printUsage();
                System.exit(1);
            }
        } else if (args.length != 4) {
            System.out.println("Unsupported option");
            printUsage();
            System.exit(1);
        }

        StegoImage si = null;

        LinkedHashMap<String, String> o = new LinkedHashMap<String, String>();
        o.put("mean", args[0]);
        o.put("variation", args[1]);

        GaussianNoiseImpl gn = new GaussianNoiseImpl();

        try {
            BufferedImage bi = ImageUtility.readImage(args[2]);
            si = new StegoImage(bi, args[2]);
        } catch (IllegalArgumentException e) {
            logger.error("Could not create stegoimage.", e);
            System.exit(1);
        } catch (NullPointerException e) {
            logger.error("Could not create stegoimage.", e);
            System.exit(1);
        } catch (IOException e) {
            logger.error("Could not create stegoimage.", e);
            System.exit(1);
        }

        StegoImage result = null;
        try {
            result = gn.distort(si, o);
        } catch (DistortionException e) {
            logger.error("Could not perform distortion.", e);
            System.exit(1);
        }
        try {
            result.write(args[3]);
        } catch (IllegalArgumentException e) {
            logger.error("Could not write result image.", e);
            System.exit(1);
        } catch (IOException e) {
            logger.error("Could not write result image.", e);
            System.exit(1);
        } catch (NullPointerException e) {
            logger.error("Could not write result image.", e);
            System.exit(1);
        }

    }

    /**
     * Prints usage to console.
     */
    public static void printUsage() {
        System.out.println("Usage: \n" +
"vsl-module-distortion-gaussian-noise <mean> <variation> <path to image> \n" +
"                                     <path to result image> \n" +
"mean - real value of gaussian noise mean \n" +
"variation - real positivie value of gaussian noise variation");
    }

    public StegoImage distort(StegoImage image, 
            LinkedHashMap<String, String> options) throws DistortionException {
        
        double m, v;
        
        try {
            m = Double.valueOf(options.get("mean"));
        } catch (NumberFormatException e) {
            throw new DistortionException("Mean must be a valid real scalar");
        }
        try {
            v = Double.valueOf(options.get("variation"));
        } catch (NumberFormatException e) {
            throw new DistortionException("Variation must be " +
                                            "a valid real scalar");
        }

        if (v < 0) {
            throw new DistortionException("Variation must be " +
                                            "a real nonnegative scalar");
        }
        
        if (image.getLayerCount() == 0) {
            throw new DistortionException("Cannot filter image - " +
                                            "to low bit depth.");
        }
        
        GaussianNoiseFilter sp = new GaussianNoiseFilter(m, v);
        BufferedImage res = sp.filter(image, null);

        try {
            return new StegoImage(res, image.getPath());
        } catch (IOException e) {
            throw new DistortionException("Could not create final image", e);
        }
    }
}
