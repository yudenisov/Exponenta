/*
 *    Virtual Steganographic Laboratory (VSL)
 *    Copyright (C) 2008-2011  M. Wegrzyn <bend-up@users.sourceforge.net>

 *    This file is part of Virtual Steganographic Laboratory (VSL).

 *    VSL is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.

 *    VSL is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.

 *    You should have received a copy of the GNU General Public License
 *    along with VSL.  If not, see <http://www.gnu.org/licenses/>.
 */
package pl.edu.zut.wi.vsl.modules.distortions;

import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.awt.image.ColorModel;
import java.io.IOException;
import java.util.LinkedHashMap;
import org.apache.log4j.Logger;
import pl.edu.zut.wi.vsl.commons.StegoImage;
import pl.edu.zut.wi.vsl.commons.distortions.DistortionException;
import pl.edu.zut.wi.vsl.commons.distortions.DistortionTechnique;
import pl.edu.zut.wi.vsl.commons.utils.ImageUtility;

/**
 * Module that resizes given image.
 * 
 * @author Michal Wegrzyn
 */
public class ResizeImpl implements DistortionTechnique {

    private final static Logger logger = Logger.getLogger(ResizeImpl.class);
        
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        if (args.length == 1) {
            if (args[0].equals("--help") ||
                    args[0].equals("-help")  ||
                    args[0].equals("?")      ||
                    args[0].equals("/?")) {
                printUsage();
                System.exit(1);
            }
        } else if (args.length != 4) {
            System.out.println("Unsupported option");
            printUsage();
            System.exit(1);
        }

        StegoImage si = null;
        ResizeImpl sp = new ResizeImpl();
        StegoImage result = null;
        LinkedHashMap<String, String> o = new LinkedHashMap<String, String>();
        o.put("xscale", args[0]);
        o.put("yscale", args[1]);
        
        try {
            BufferedImage bi = ImageUtility.readImage(args[2]);
            si = new StegoImage(bi, args[2]);
        } catch (IllegalArgumentException e) {
            logger.error("Could not create stegoimage.", e);
            System.exit(1);
        } catch (NullPointerException e) {
            logger.error("Could not create stegoimage.", e);
            System.exit(1);
        } catch (IOException e) {
            logger.error("Could not create stegoimage.", e);
            System.exit(1);
        }
        
        try {
            result = sp.distort(si, o);
        } catch (DistortionException e) {
            logger.error("Could not perform distortion.", e);
            System.exit(1);
        }
        try {
            result.write(args[3]);
        } catch (IllegalArgumentException e) {
            logger.error("Could not write result image.", e);
            System.exit(1);
        } catch (IOException e) {
            logger.error("Could not write result image.", e);
            System.exit(1);
        } catch (NullPointerException e) {
            logger.error("Could not write result image.", e);
            System.exit(1);
        }

    }

    public ResizeImpl() {
    }

    /**
     * Prints usage to console.
     */
    public static void printUsage() {
        System.out.println("Usage: \n" +
"vsl-module-distortion-resize <xscale> <yscale> <path to image> \n" +
"                             <path to result image>\n" +
"xscale - the factor by which coordinates are scaled along the X axis \n" +
"direction \n" +
"yscale - the factor by which coordinates are scaled along the Y axis \n" +
"direction");
    }

    public StegoImage distort(StegoImage image, 
            LinkedHashMap<String, String> options) throws DistortionException {
        
        double xscale, yscale;
        
        try {
            xscale = Double.valueOf(options.get("xscale"));
        } catch (NumberFormatException e) {
            throw new DistortionException("xscale must be a valid integer scalar");
        }
        try {
            yscale = Double.valueOf(options.get("yscale"));
        } catch (NumberFormatException e) {
            throw new DistortionException("yscale must be a valid integer scalar");
        }
        if (xscale <= 0) {
            throw new DistortionException("scale must be greater than 0");
        }
        if (yscale <= 0) {
            throw new DistortionException("yscale must be greater than 0");
        }

        BufferedImage resized = resize(image, xscale, yscale, 
                                    RenderingHints.VALUE_INTERPOLATION_BICUBIC);
        
        try {
            return new StegoImage(resized, image.getPath());
        } catch (IOException e) {
            throw new DistortionException("Could not create final image", e);
        }
    }

    public static BufferedImage resize(StegoImage source, double xScale, 
                                        double yScale, Object interpolation) {
        if (source == null) {
            throw new NullPointerException("source image is NULL!");
        }
        
        int sourceWidth = source.getWidth();
        int sourceHeight = source.getHeight();
        int destWidth = (int) Math.rint(xScale * sourceWidth);
        int destHeight = (int) Math.rint(yScale * sourceHeight);
        
        //create dest bufferedimage
        ColorModel destCM = source.getColorModel();
        BufferedImage result =  new BufferedImage(destCM,
                destCM.createCompatibleWritableRaster(
                destWidth, destHeight),
                destCM.isAlphaPremultiplied(), null);
        Graphics2D g2d = null;
        
        try {
            g2d = result.createGraphics();
            g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, 
                                    interpolation);
            AffineTransform at =
                    AffineTransform.getScaleInstance(xScale, yScale);
            g2d.drawRenderedImage(source, at);
        } finally {
            if (g2d != null) {
                g2d.dispose();
            }
        }
        return result;
    }

}
