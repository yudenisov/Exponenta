/*
 *    Virtual Steganographic Laboratory (VSL)
 *    Copyright (C) 2008-2011  M. Wegrzyn <bend-up@users.sourceforge.net>

 *    This file is part of Virtual Steganographic Laboratory (VSL).

 *    VSL is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.

 *    VSL is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.

 *    You should have received a copy of the GNU General Public License
 *    along with VSL.  If not, see <http://www.gnu.org/licenses/>.
 */
package pl.edu.zut.wi.vsl.modules.distortions.filters;

import java.awt.image.BufferedImage;
import java.util.Random;
import pl.edu.zut.wi.vsl.commons.distortions.AbstractPixelFilter;
import pl.edu.zut.wi.vsl.commons.utils.BitUtility;
import pl.edu.zut.wi.vsl.commons.utils.ImageUtility;

/**
 * Filter that adds Salt and Pepper noise to the given image.
 * 
 * @author Michal Wegrzyn
 */
public class SaltPepperFilter extends AbstractPixelFilter {

    /** Byte representing black pixel */
    private static final byte BLACK = (byte) 0x00;
    /** Byte representing white pixel */
    private static final byte WHITE = (byte) 0xff;
    /** Probability of filtering pixel. */
    private double density;
    
    public SaltPepperFilter() {
        this(0.05);
    }

    /** Creates filter with the given intensity of the noise */
    public SaltPepperFilter(double d) {
        density = d;
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    public BufferedImage filter(BufferedImage src, BufferedImage dst) {
        if (dst == null) {
            dst = createCompatibleDestImage(src, null);
        }

        int width = src.getWidth();
        int height = src.getHeight();
        int[] pixels = new int[width * height];
        ImageUtility.getPixels(src, 0, 0, width,
                height, pixels);
        Random rand = new Random();

        for (int i = 0; i < pixels.length; i++) {

            int argb = pixels[i];
            byte[] bs = BitUtility.intToByteArray(argb);

            byte a = bs[0];
            byte r = bs[1];
            byte g = bs[2];
            byte b = bs[3];
            double randNum = rand.nextDouble();

            if (randNum < density / 2) {
                r = BLACK; // Minimum value - black pixel
                g = BLACK;
                b = BLACK;
            } else if (randNum >= density / 2 && randNum < density) {
                r = WHITE; // Maximum (saturated) value - white pixel
                g = WHITE;
                b = WHITE;
            }

            pixels[i] = BitUtility.byteArrayToInt(new byte[] {a, r, g, b});
        }

        ImageUtility.setPixels(dst, 0, 0, width,
                height, pixels);

        return dst;
    }
}