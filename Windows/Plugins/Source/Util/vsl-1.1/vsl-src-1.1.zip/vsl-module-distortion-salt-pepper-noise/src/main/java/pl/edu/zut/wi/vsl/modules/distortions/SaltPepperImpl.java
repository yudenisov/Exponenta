/*
 *    Virtual Steganographic Laboratory (VSL)
 *    Copyright (C) 2008-2011  M. Wegrzyn <bend-up@users.sourceforge.net>

 *    This file is part of Virtual Steganographic Laboratory (VSL).

 *    VSL is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.

 *    VSL is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.

 *    You should have received a copy of the GNU General Public License
 *    along with VSL.  If not, see <http://www.gnu.org/licenses/>.
 */
package pl.edu.zut.wi.vsl.modules.distortions;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.LinkedHashMap;
import org.apache.log4j.Logger;
import pl.edu.zut.wi.vsl.commons.StegoImage;
import pl.edu.zut.wi.vsl.commons.distortions.DistortionException;
import pl.edu.zut.wi.vsl.commons.distortions.DistortionTechnique;
import pl.edu.zut.wi.vsl.commons.utils.ImageUtility;
import pl.edu.zut.wi.vsl.modules.distortions.filters.SaltPepperFilter;

/**
 * Module that adds Salt and Pepper noise to the given image.
 * 
 * @author Michal Wegrzyn
 */
public class SaltPepperImpl implements DistortionTechnique {

    private final static Logger logger = Logger.getLogger(SaltPepperImpl.class);
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        if (args.length == 1) {
            if (args[0].equals("--help") ||
                    args[0].equals("-help")  ||
                    args[0].equals("?")      ||
                    args[0].equals("/?")) {
                printUsage();
                System.exit(1);
            }
        } else if (args.length != 3) {
            System.out.println("Unsupported option");
            printUsage();
            System.exit(1);
        }
        
        StegoImage si = null;
        LinkedHashMap<String, String> o = new LinkedHashMap<String, String>();
        o.put("density", args[0]);
        SaltPepperImpl sp = new SaltPepperImpl();
        StegoImage result = null;

        try {
            BufferedImage bi = ImageUtility.readImage(args[1]);
            si = new StegoImage(bi, args[1]);
        } catch (IllegalArgumentException e) {
            logger.error("Could not create stegoimage.", e);
            System.exit(1);
        } catch (NullPointerException e) {
            logger.error("Could not create stegoimage.", e);
            System.exit(1);
        } catch (IOException e) {
            logger.error("Could not create stegoimage.", e);
            System.exit(1);
        }
        
        try {
            result = sp.distort(si, o);
        } catch (DistortionException e) {
            logger.error("Could not perform distortion.", e);
            System.exit(1);
        }
        try {
            result.write(args[2]);
        } catch (IllegalArgumentException e) {
            logger.error("Could not write result image.", e);
            System.exit(1);
        } catch (IOException e) {
            logger.error("Could not write result image.", e);
            System.exit(1);
        } catch (NullPointerException e) {
            logger.error("Could not write result image.", e);
            System.exit(1);
        }

    }

    /**
     * Prints usage to console.
     */
    public static void printUsage() {
        System.out.println("Usage: \n" +
"vsl-module-distortion-salt-pepper-noise <density> <path to image> \n " +
"                                        <path to result image>\n" +
"density - density of salt and pepper noise");
    }

    public StegoImage distort(StegoImage image, 
            LinkedHashMap<String, String> options) throws DistortionException {
        
        double d;
        
        try {
            d = Double.valueOf(options.get("density"));
        } catch (NumberFormatException e) {
            throw new DistortionException("Density must be " +
                                            "a valid real scalar");
        }
        if (d <= 0 || d > 100) {
            throw new DistortionException("Density must be " +
                                            "a value from range (0;100>");
        }
        
        if (image.getLayerCount() == 0) {
                throw new DistortionException("Cannot filter image - " +
                                                "to low bit depth.");
        }
        
        SaltPepperFilter sp = new SaltPepperFilter(d);
        BufferedImage res = sp.filter(image, null);

        try {
            return new StegoImage(res, image.getPath());
        } catch (IOException e) {
            throw new DistortionException("Could not create final image", e);
        }
    }
}
