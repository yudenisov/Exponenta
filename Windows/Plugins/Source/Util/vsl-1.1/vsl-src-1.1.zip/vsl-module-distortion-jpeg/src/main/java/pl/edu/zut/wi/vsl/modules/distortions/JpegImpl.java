/*
 *    Virtual Steganographic Laboratory (VSL)
 *    Copyright (C) 2008-2011  M. Wegrzyn <bend-up@users.sourceforge.net>

 *    This file is part of Virtual Steganographic Laboratory (VSL).

 *    VSL is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.

 *    VSL is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.

 *    You should have received a copy of the GNU General Public License
 *    along with VSL.  If not, see <http://www.gnu.org/licenses/>.
 */
package pl.edu.zut.wi.vsl.modules.distortions;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.LinkedHashMap;
import org.apache.log4j.Logger;
import pl.edu.zut.wi.vsl.commons.StegoImage;
import pl.edu.zut.wi.vsl.commons.distortions.DistortionException;
import pl.edu.zut.wi.vsl.commons.distortions.DistortionTechnique;
import pl.edu.zut.wi.vsl.commons.utils.ImageUtility;

/**
 * Module that performs JPEG compression on the given image.
 * 
 * @author Michal Wegrzyn
 */
public class JpegImpl implements DistortionTechnique {

    private final static Logger logger = Logger.getLogger(JpegImpl.class);

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        if (args.length == 1) {
            if (args[0].equals("--help") ||
                    args[0].equals("-help") ||
                    args[0].equals("?") ||
                    args[0].equals("/?")) {
                printUsage();
                System.exit(1);
            }
        } else if (args.length != 3) {
            System.out.println("Unsupported option");
            printUsage();
            System.exit(1);
        }

        StegoImage si = null;

        LinkedHashMap<String, String> o = new LinkedHashMap<String, String>();
        o.put("quality", args[0]);

        JpegImpl sp = new JpegImpl();

        try {
            BufferedImage bi = ImageUtility.readImage(args[1]);
            si = new StegoImage(bi, args[1]);
        } catch (IllegalArgumentException e) {
            logger.error("Could not create stegoimage.", e);
            System.exit(1);
        } catch (NullPointerException e) {
            logger.error("Could not create stegoimage.", e);
            System.exit(1);
        } catch (IOException e) {
            logger.error("Could not create stegoimage.", e);
            System.exit(1);
        }

        StegoImage result = null;
        try {
            result = sp.distort(si, o);
        } catch (DistortionException e) {
            logger.error("Could not perform distortion.", e);
            System.exit(1);
        }
        try {
            result.write(args[2]);
        } catch (IllegalArgumentException e) {
            logger.error("Could not write result image.", e);
            System.exit(1);
        } catch (IOException e) {
            logger.error("Could not write result image.", e);
            System.exit(1);
        } catch (NullPointerException e) {
            logger.error("Could not write result image.", e);
            System.exit(1);
        }

    }

    /**
     * Prints usage to console.
     */
    public static void printUsage() {
        System.out.println("Usage: \n" +
"vsl-module-distortion-jpeg <quality> <path to image> <path to result image> \n"+
"quality - Quality of JPEG compression - 0.0 means high compression is " +
"important, wheras 1.0 means high image quality is important.");
    }

    public StegoImage distort(StegoImage image,
            LinkedHashMap<String, String> options) throws DistortionException {

        float quality;
        
        try {
            quality = Float.valueOf(options.get("quality"));
        } catch (NumberFormatException e) {
            throw new DistortionException("quality must be " +
                                                "a valid real scalar", e);
        }
        
        if (quality < 0 || quality > 1) {
            throw new DistortionException("Quality factor must be " +
                                            "a real scalar within 0-1 range");
        }

        if (image.getLayerCount() == 0) {
            throw new DistortionException("Cannot filter image - " +
                    "to low bit depth.");
        }
        
        final String tempFilename = "vsl-distorted-jpeg-tmp-" + 
                System.currentTimeMillis() + ".jpg";
        try {
            ImageUtility.writeJPEG(image, tempFilename, quality);
        } catch (Exception e) {
            throw new DistortionException("Could not save " +
                    "distorted JPEG temporary file:" + tempFilename, e);
        }
        StegoImage distorted = null;
        try {
            BufferedImage bi = ImageUtility.readImage(tempFilename);
            distorted = new StegoImage(bi, image.getPath());
        } catch (Exception e) {
            try {
                deleteTempFile(tempFilename);
            } catch (Exception ex) {
                logger.warn("Could not delete temporary file: "+ tempFilename, ex);
            }
            throw new DistortionException("Could not load saved " +
                    "distorted JPEG temporary file", e);
        } 
        
        try {
            deleteTempFile(tempFilename);
        } catch (Exception ex) {
            logger.warn("Could not delete temporary file: "+ tempFilename, ex);
        }        
        return distorted;
    }
    
    private void deleteTempFile(String path) throws Exception {
        File f = new File(path);
        f.delete();
    }

}
