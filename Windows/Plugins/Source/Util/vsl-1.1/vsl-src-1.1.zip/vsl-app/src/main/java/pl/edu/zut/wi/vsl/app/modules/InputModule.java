/*
 *    Virtual Steganographic Laboratory (VSL)
 *    Copyright (C) 2008-2011  M. Wegrzyn <bend-up@users.sourceforge.net>

 *    This file is part of Virtual Steganographic Laboratory (VSL).

 *    VSL is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.

 *    VSL is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.

 *    You should have received a copy of the GNU General Public License
 *    along with VSL.  If not, see <http://www.gnu.org/licenses/>.
 */
package pl.edu.zut.wi.vsl.app.modules;

import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;
import pl.edu.zut.wi.vsl.app.VslException;
import pl.edu.zut.wi.vsl.commons.StegoPackage;

/**
 * Module for input utilities.
 *
 * @author Michal Wegrzyn
 */
public class InputModule extends VslModule implements Serializable {

    /** For serialization. */
    private static final long serialVersionUID = -8595874399645645216L;
    /** List of files */
    private ArrayList<File> inputFiles;
    private static final String DESC = "Input for images. Selects input "
            + "images. This is always the first module in flow ";
    
    public InputModule() {
        super("Input", DESC, ModuleType.Input);
        inputFiles = new ArrayList<File>();
    }

    public InputModule(ArrayList<File> files) {
        this();
        inputFiles = files;
    }

    public InputModule(InputModule v) {
        super(v);
        
        inputFiles = new ArrayList<File>();

        if (v.getInputFiles() != null && !v.getInputFiles().isEmpty()) {
            inputFiles.addAll(v.getInputFiles());
        }
    }

    /**
     * Getter for input files.
     * @return ArrayList - list with files used to hide message.
     */
    public ArrayList<File> getInputFiles() {
        return inputFiles;
    }

    /**
     * Sets input files used to cover message to hide.
     * @param files - list of files
     */
    public void setInputFiles(ArrayList<File> files) {
        inputFiles.clear();
        inputFiles.addAll(files);
    }

    @Override
    public StegoPackage execute(StegoPackage cp) throws VslException {
        // nothing to do on input
        return cp;
    }

}
