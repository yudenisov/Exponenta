/*
 *    Virtual Steganographic Laboratory (VSL)
 *    Copyright (C) 2008-2011  M. Wegrzyn <bend-up@users.sourceforge.net>

 *    This file is part of Virtual Steganographic Laboratory (VSL).

 *    VSL is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.

 *    VSL is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.

 *    You should have received a copy of the GNU General Public License
 *    along with VSL.  If not, see <http://www.gnu.org/licenses/>.
 */
package pl.edu.zut.wi.vsl.app;

import java.awt.Event;
import java.awt.Point;
import java.awt.dnd.DnDConstants;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.ArrayList;
import java.util.List;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.JComponent;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JProgressBar;
import javax.swing.KeyStroke;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreePath;
import javax.xml.parsers.ParserConfigurationException;
import org.apache.log4j.Logger;
import org.xml.sax.SAXException;
import pl.edu.zut.wi.vsl.app.gui.DeskItem;
import pl.edu.zut.wi.vsl.app.gui.panels.AboutPanel;
import pl.edu.zut.wi.vsl.app.gui.TreeDragSource;
import pl.edu.zut.wi.vsl.app.gui.TransferableTreeNode;
import pl.edu.zut.wi.vsl.app.logging.LogPanel;
import pl.edu.zut.wi.vsl.app.modules.DisplayModule;
import pl.edu.zut.wi.vsl.app.modules.InputModule;
import pl.edu.zut.wi.vsl.app.modules.ModuleConnection;
import pl.edu.zut.wi.vsl.app.modules.OutputModule;
import pl.edu.zut.wi.vsl.app.modules.ReportModule;
import pl.edu.zut.wi.vsl.app.utils.FileUtil;
import pl.edu.zut.wi.vsl.app.utils.ParseUtil;
import pl.edu.zut.wi.vsl.app.utils.VslUtil;

/**
 * Class of the main application window. Creates whole GUI
 * and manages top level actions.
 * 
 * @author Michal Wegrzyn
 */
public class MainWindow extends javax.swing.JFrame {

    /** Creates new form MainWindow */
    public MainWindow() {
        super();
        logger.debug("Initializing components");
        initComponents();
        logger.info("Components initialized, creating tree drag source");
        logPanel.statusMessage("VSL initializated.");
        logPanel.startLog();
        ds = new TreeDragSource(modulesTree, DnDConstants.ACTION_COPY);
        setLocationRelativeTo(null);
    }

    
    /**
     * Returns MainWindow's <code>LogPanel</code>.
     * @return <code>LogPanel</code> instance of this object.
     */
    public static LogPanel getLogger() {
        return logPanel;
    }

    /**
     * Returns default scroll increment unit for windows.
     * @return default scroll increment unit
     */
    public static int getDefaultScrollIncrement() {
        return windowsScrollIncrement;
    }

    /**
     * Returns coordinates of viewport (current offset of scrollbars).
     * @return Point - offset of scrollbars
     */
    public static Point getWindowScrollOffset() {
        return windowScrollPane.getViewport().getViewPosition();
    }
    
    /**
     * Tries to stop experiment. If all threads have done their work,
     * stops it. 
     */
    public void endExperiment() {
        logger.trace("Trying to end experiment");
        
        FileUtil.moveResultFiles(flowMonitor.getStartTime(),
                System.currentTimeMillis(),
                new File(Main.getProperty("java.dir",
                FileUtil.getCurrentDir())), new File(
                                FileUtil.getOutputDirectory() +
                                File.separator +
                                flowMonitor.getBaseDirectory() +
                                File.separator + "modules-output"));
        desktop.blockModules(false);
        stopExperimentButton.setEnabled(false);
        startExperimentButton.setEnabled(true);
        newWorkspaceButton.setEnabled(true);
        openWorkspaceButton.setEnabled(true);
        saveWorkspaceButton.setEnabled(true);
        progressBar.setVisible(false);
        progressBar.setValue(0);
        logPanel.taskFinished();
        logger.debug("Experiment stopped.");
    }
    
    /**
     * Repaints desktop - main graphical pane of the application.
     */
    public void repaintDesktop() {
        desktop.repaint();
    }
    
    /**
     * Returns progress bar indicating progress in performed experiment.s
     * @return
     */
    public JProgressBar getProgressBar() {
        return progressBar;
    }
    
    /**
     * Starts experiment.
     */
    private void startExperiment() {
        if (desktop.checkModules()) {
            ArrayList<InputModule> inputs = desktop.getInputs();
            logPanel.taskStarted();
            startExperimentButton.setEnabled(false);
            stopExperimentButton.setEnabled(true);
            newWorkspaceButton.setEnabled(false);
            openWorkspaceButton.setEnabled(false);
            saveWorkspaceButton.setEnabled(false);
            desktop.blockModules(true);
            desktop.cleanUpModules();

            String date = new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss-SSS",
                    Locale.getDefault()).format(new Date());
            
            flowMonitor = new FlowMonitor(this, inputs.size(), date);

            for (int i = 0; i < inputs.size(); i++) {
                /* create thread for every input */
                Flow flow = new Flow(flowMonitor, inputs.get(i), i);
                flowMonitor.add(flow);
            }
            desktop.setAllConnectionsInactive();
            progressBar.setVisible(true);
            progressBar.setToolTipText("0 / " + flowMonitor.getTotalExecutions());
            logger.debug("Starting experiment. Inputs: " + inputs.size() +
                    " Executions to perform: " + flowMonitor.getTotalExecutions());
            flowMonitor.startThreads();
        }
    }

    /**
     * Immediately stops experiment.
     */
    private void stopExperiment() {
        logger.debug("Stopping experiment");
        flowMonitor.interrupt();
    }
    

    /**
     * Creates new workspace.
     */
    private void newWorkspace() {
        int decision = JOptionPane.showConfirmDialog(this,
                "Do you really want to create new worspace?\n" +
                "All unsaved changes will be lost.",
                NEW_WORKSPACE_TITLE, JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE, VslUtil.WARN_ICON);
        if (decision == JOptionPane.YES_OPTION) {
            desktop.clear();
            logger.trace("Creating new workspace.");
        }
    }

    /**
     * Loads workspace from a file.
     */
    private void openWorkspace() {
        JFileChooser fc = new JFileChooser();
        FileNameExtensionFilter wokrspaceFilter = new FileNameExtensionFilter(
                "VSL workspace files (*." + VSL_WORKSPACE_EXTENSION + ")", 
                VSL_WORKSPACE_EXTENSION);
        fc.addChoosableFileFilter(wokrspaceFilter);
        fc.setDialogTitle("VSL - load workspace...");
        int returnVal = fc.showOpenDialog(this);
        if (returnVal == JFileChooser.APPROVE_OPTION) {
            File f = fc.getSelectedFile();
            //add extension if necessary
            if (!f.getName().toLowerCase().endsWith(VSL_WORKSPACE_EXTENSION)) {
                f = new File(f.getAbsolutePath() + VSL_WORKSPACE_EXTENSION);
            }
            logger.trace("Loading workspace: " + f.getAbsolutePath());
            try {
                List<DeskItem> items = new ArrayList<DeskItem>();
                List<ModuleConnection> connections = new ArrayList<ModuleConnection>();
                InputStream is = new FileInputStream(f);
                ObjectInputStream ois = new ObjectInputStream(is);
                items = (ArrayList<DeskItem>) ois.readObject();
                connections = (ArrayList<ModuleConnection>) ois.readObject();
                logger.debug("ite: "+ desktop.getModuleInstances().size());
                logger.debug("conne: "+ desktop.getConnections().size());
                ois.close();
                desktop.loadWorkspace(items, connections);
            } catch (Exception e) {
                logger.error("Could not load workspace from file.", e);
                VslUtil.showError(this, 
                                    "Could not load workspace from file.", e);
            }
        }
    }

    /**
     * Saves workspace to a file.
     */
    private void saveWorkspace() {
        JFileChooser fc = new JFileChooser();
        FileNameExtensionFilter wokrspaceFilter = new FileNameExtensionFilter(
                "VSL workspace files (*." + VSL_WORKSPACE_EXTENSION + ")", 
                VSL_WORKSPACE_EXTENSION);
        fc.addChoosableFileFilter(wokrspaceFilter);
        fc.setDialogTitle("VSL - save workspace...");
        int returnVal = fc.showSaveDialog(this);
        if (returnVal == JFileChooser.APPROVE_OPTION) {
            File f = fc.getSelectedFile();
            //add extension if necessary
            if (!f.getName().toLowerCase().endsWith(VSL_WORKSPACE_EXTENSION)) {
                f = new File(f.getAbsolutePath() + "." 
                                                 + VSL_WORKSPACE_EXTENSION);
            }
            logger.trace("Saving workspace: " + f.getAbsolutePath());
            if (f.exists()) {
                int decision = JOptionPane.showConfirmDialog(this,
                        "Do you want to  replace existing file?",
                        "VSL - replace file", JOptionPane.YES_NO_OPTION,
                        JOptionPane.QUESTION_MESSAGE, VslUtil.QUESTION_ICON);
                if (decision == JOptionPane.NO_OPTION) {
                    return;
                }
            }
            //save deskitems and connections to file
            try {
                OutputStream os = new FileOutputStream(f);
                ObjectOutputStream oos = new ObjectOutputStream(os);
                oos.writeObject(desktop.getModuleInstances());
                oos.writeObject(desktop.getConnections());
                oos.flush();
                oos.close();
            } catch (Exception e) {
                logger.error("Could not save workspace to file.", e);
                VslUtil.showError(this, "Could not save workspace to file.",
                        e);
            }
        }
    }
    
    /**
     * Shows About dialog.
     */
    private void showAbout() {
        JOptionPane.showConfirmDialog(this, new AboutPanel(), "VSL - About", 
                                            JOptionPane.DEFAULT_OPTION, 
                                            JOptionPane.PLAIN_MESSAGE);
    }


    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        windowScrollPane = new javax.swing.JScrollPane();
        int scroll;
        try {
            scroll = Integer.parseInt(Main.getProperty("vsl.desktop.scrollBarIncrement", String.valueOf(SCROLL_INC)));
        } catch (NumberFormatException e) {
            logger.warn("Could not read vsl.desktop.scrollBarIncrement property", e);
            scroll = SCROLL_INC;
        }
        windowScrollPane.getVerticalScrollBar().setUnitIncrement(scroll);
        int dwidth, dheight;
        try {
            dwidth = Integer.parseInt(Main.getProperty("vsl.desktop.width", String.valueOf(DESKTOP_WIDTH)));
        } catch (NumberFormatException e) {
            logger.warn("Could not read vsl.desktop.width property", e);
            dwidth = DESKTOP_WIDTH;
        }
        try {
            dheight = Integer.parseInt(Main.getProperty("vsl.desktop.height", String.valueOf(DESKTOP_WIDTH)));
        } catch (NumberFormatException e) {
            logger.warn("Could not read vsl.desktop.height property", e);
            dheight = DESKTOP_HEIGHT;
        }
        desktop = new pl.edu.zut.wi.vsl.app.gui.Desktop();
        desktop.setPreferredSize(new java.awt.Dimension(dwidth, dheight));
        desktopFrame = new javax.swing.JInternalFrame();
        desktopFrame.setFrameIcon(VslUtil.LOGO_ICON);
        desktopFrameScrollPane = new javax.swing.JScrollPane();
        try {
            scroll = Integer.parseInt(Main.getProperty("vsl.windows.scrollBarIncrement", String.valueOf(WINDOWS_SCROLL_INC)));
        } catch (NumberFormatException e) {
            scroll = WINDOWS_SCROLL_INC;
        }
        desktopFrameScrollPane.getVerticalScrollBar().setUnitIncrement(scroll);
        windowsScrollIncrement = scroll;
        desktopFrameInternalScrollPane = new javax.swing.JScrollPane();
        DefaultMutableTreeNode treeRootNode = new DefaultMutableTreeNode("Modules");
        DefaultMutableTreeNode categoryTools = new DefaultMutableTreeNode("Tools");
        categoryTools.add(new TransferableTreeNode(new InputModule()));
        categoryTools.add(new TransferableTreeNode(new OutputModule()));
        categoryTools.add(new TransferableTreeNode(new DisplayModule()));
        categoryTools.add(new TransferableTreeNode(new ReportModule()));
        treeRootNode.add(categoryTools);
        ParseUtil pu = ParseUtil.getInstance();
        try {
            pu.createModuleListNodes(treeRootNode);
        } catch (ParserConfigurationException e) {
            String msg = "Exception occured during creating modules list.";
            logger.error(msg, e);
            VslUtil.showError(this, msg, e);
        } catch (SAXException e) {
            String msg = "Exception occured during creating modules list.";
            logger.error(msg, e);
            VslUtil.showError(this, msg, e);
        } catch (IOException e) {
            String msg = "Exception occured during creating modules list.";
            logger.error(msg, e);
            VslUtil.showError(this, msg, e);
        }
        DefaultTreeModel treeModel = new DefaultTreeModel(treeRootNode);
        modulesTree = new javax.swing.JTree(treeModel) {
            public String getToolTipText(MouseEvent evt) {
                if (getRowForLocation(evt.getX(), evt.getY()) == -1)
                return null;
                TreePath curPath = getPathForLocation(evt.getX(), evt.getY());
                Object o = curPath.getLastPathComponent();
                if (o.getClass().equals(TransferableTreeNode.class)) {
                    return ((TransferableTreeNode) o).getToolTipText();
                } else {
                    return ((DefaultMutableTreeNode) o).toString();
                }

            }
        };
        modulesTree.setToolTipText("");
        toolBar = new javax.swing.JToolBar();
        menuSeparator5 = new javax.swing.JToolBar.Separator();
        aboutButton = new javax.swing.JButton();
        menuSeparator3 = new javax.swing.JToolBar.Separator();
        newWorkspaceButton = new javax.swing.JButton();
        openWorkspaceButton = new javax.swing.JButton();
        saveWorkspaceButton = new javax.swing.JButton();
        menuSeparator1 = new javax.swing.JToolBar.Separator();
        startExperimentButton = new javax.swing.JButton();
        stopExperimentButton = new javax.swing.JButton();
        menuSeparator2 = new javax.swing.JToolBar.Separator();
        logButton = new javax.swing.JButton();
        menuSeparator6 = new javax.swing.JToolBar.Separator();
        logPanel = new pl.edu.zut.wi.vsl.app.logging.LogPanel();
        setIconImage(VslUtil.LOGO_ICON.getImage());
        KeyStroke newWorkspaceKeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_N, Event.CTRL_MASK);
        Action newWorkspaceAction = new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                if (startExperimentButton.isEnabled()) {
                    newWorkspace();
                }
            }
        };
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(newWorkspaceKeyStroke, "ctrl N");
        getRootPane().getActionMap().put("ctrl N", newWorkspaceAction);
        KeyStroke openWorkspaceKeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_O, Event.CTRL_MASK);
        Action openWorkspaceAction = new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                if (startExperimentButton.isEnabled()) {
                    openWorkspace();
                }
            }
        };
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(openWorkspaceKeyStroke, "ctrl O");
        getRootPane().getActionMap().put("ctrl O", openWorkspaceAction);
        KeyStroke saveWorkspaceKeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_S, Event.CTRL_MASK);
        Action saveWorkspaceAction = new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                if (startExperimentButton.isEnabled()) {
                    saveWorkspace();
                }
            }
        };
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(saveWorkspaceKeyStroke, "ctrl S");
        getRootPane().getActionMap().put("ctrl S", saveWorkspaceAction);
        KeyStroke executeKeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, Event.CTRL_MASK);
        Action executeAction = new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                if (startExperimentButton.isEnabled()) {
                    startExperiment();
                }
            }
        };
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(executeKeyStroke, "ctrl ENTER");
        getRootPane().getActionMap().put("ctrl ENTER", executeAction);
        KeyStroke breakExperimentKeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_PAUSE, Event.CTRL_MASK);
        Action breakExperimentAction = new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                if (stopExperimentButton.isEnabled()) {
                    stopExperiment();
                }
            }
        };
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(breakExperimentKeyStroke, "ctrl BREAK");
        getRootPane().getActionMap().put("ctrl BREAK", breakExperimentAction);
        KeyStroke showLogKeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_L, Event.CTRL_MASK);
        Action showLogAction = new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                logPanel.showWindow();
            }
        };
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(showLogKeyStroke, "ctrl L");
        getRootPane().getActionMap().put("ctrl L", showLogAction);
        menuSeparator4 = new javax.swing.JToolBar.Separator();
        progressBar = new javax.swing.JProgressBar();
        progressBar.setVisible(false);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("VSL - Virtual Steganographic Laboratory");
        setName(""); // NOI18N

        desktopFrame.setIconifiable(true);
        desktopFrame.setMaximizable(true);
        desktopFrame.setResizable(true);
        desktopFrame.setTitle("VSL Modules");
        desktopFrame.setVisible(true);

        desktopFrameInternalScrollPane.setPreferredSize(new java.awt.Dimension(80, 120));

        modulesTree.setToggleClickCount(1);
        desktopFrameInternalScrollPane.setViewportView(modulesTree);

        desktopFrameScrollPane.setViewportView(desktopFrameInternalScrollPane);

        javax.swing.GroupLayout desktopFrameLayout = new javax.swing.GroupLayout(desktopFrame.getContentPane());
        desktopFrame.getContentPane().setLayout(desktopFrameLayout);
        desktopFrameLayout.setHorizontalGroup(
            desktopFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 162, Short.MAX_VALUE)
            .addGroup(desktopFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(desktopFrameScrollPane, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
        );
        desktopFrameLayout.setVerticalGroup(
            desktopFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 204, Short.MAX_VALUE)
            .addGroup(desktopFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(desktopFrameScrollPane, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
        );

        desktopFrame.setBounds(630, 20, 170, 230);
        desktop.add(desktopFrame, javax.swing.JLayeredPane.DEFAULT_LAYER);

        windowScrollPane.setViewportView(desktop);

        toolBar.setFloatable(false);
        toolBar.setRollover(true);
        toolBar.add(menuSeparator5);

        aboutButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pl/edu/zut/wi/vsl/app/gui/icons/logo.png"))); // NOI18N
        aboutButton.setToolTipText("About...");
        aboutButton.setFocusable(false);
        aboutButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        aboutButton.setPreferredSize(new java.awt.Dimension(29, 29));
        aboutButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        aboutButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                aboutButtonActionPerformed(evt);
            }
        });
        toolBar.add(aboutButton);
        toolBar.add(menuSeparator3);

        newWorkspaceButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pl/edu/zut/wi/vsl/app/gui/icons/document-new16x16.png"))); // NOI18N
        newWorkspaceButton.setToolTipText("Clears current workspace and creates a new one (CTRL-N)");
        newWorkspaceButton.setFocusable(false);
        newWorkspaceButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        newWorkspaceButton.setPreferredSize(new java.awt.Dimension(29, 29));
        newWorkspaceButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        newWorkspaceButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                newWorkspaceButtonActionPerformed(evt);
            }
        });
        toolBar.add(newWorkspaceButton);

        openWorkspaceButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pl/edu/zut/wi/vsl/app/gui/icons/document-open16x16.png"))); // NOI18N
        openWorkspaceButton.setToolTipText("Loads workspace from a file (CTRL-O)");
        openWorkspaceButton.setFocusable(false);
        openWorkspaceButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        openWorkspaceButton.setPreferredSize(new java.awt.Dimension(29, 29));
        openWorkspaceButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        openWorkspaceButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                openWorkspaceButtonActionPerformed(evt);
            }
        });
        toolBar.add(openWorkspaceButton);

        saveWorkspaceButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pl/edu/zut/wi/vsl/app/gui/icons/document-save16x16.png"))); // NOI18N
        saveWorkspaceButton.setToolTipText("Saves current workspace to a file (CTRL-S)");
        saveWorkspaceButton.setFocusable(false);
        saveWorkspaceButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        saveWorkspaceButton.setPreferredSize(new java.awt.Dimension(29, 29));
        saveWorkspaceButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        saveWorkspaceButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveWorkspaceButtonActionPerformed(evt);
            }
        });
        toolBar.add(saveWorkspaceButton);
        toolBar.add(menuSeparator1);

        startExperimentButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pl/edu/zut/wi/vsl/app/gui/icons/start16x16.png"))); // NOI18N
        startExperimentButton.setToolTipText("Starts experiment (CTRL-ENTER)");
        startExperimentButton.setFocusable(false);
        startExperimentButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        startExperimentButton.setPreferredSize(new java.awt.Dimension(29, 29));
        startExperimentButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        startExperimentButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                startExperimentButtonActionPerformed(evt);
            }
        });
        toolBar.add(startExperimentButton);

        stopExperimentButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pl/edu/zut/wi/vsl/app/gui/icons/stop16x16.png"))); // NOI18N
        stopExperimentButton.setToolTipText("Stops experiment (CTRL-Break)");
        stopExperimentButton.setEnabled(false);
        stopExperimentButton.setFocusable(false);
        stopExperimentButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        stopExperimentButton.setPreferredSize(new java.awt.Dimension(29, 29));
        stopExperimentButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        stopExperimentButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                stopExperimentButtonActionPerformed(evt);
            }
        });
        toolBar.add(stopExperimentButton);
        toolBar.add(menuSeparator2);

        logButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pl/edu/zut/wi/vsl/app/gui/icons/logviewer16x16.png"))); // NOI18N
        logButton.setToolTipText("Opens window with application's log (CTRL-L)");
        logButton.setFocusable(false);
        logButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        logButton.setPreferredSize(new java.awt.Dimension(29, 29));
        logButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        logButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                logButtonActionPerformed(evt);
            }
        });
        toolBar.add(logButton);
        toolBar.add(menuSeparator6);
        toolBar.add(logPanel);
        toolBar.add(menuSeparator4);

        progressBar.setPreferredSize(new java.awt.Dimension(146, 18));
        progressBar.setStringPainted(true);
        toolBar.add(progressBar);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(toolBar, javax.swing.GroupLayout.DEFAULT_SIZE, 831, Short.MAX_VALUE)
            .addComponent(windowScrollPane, javax.swing.GroupLayout.DEFAULT_SIZE, 831, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(windowScrollPane, javax.swing.GroupLayout.DEFAULT_SIZE, 440, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(toolBar, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    

private void newWorkspaceButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_newWorkspaceButtonActionPerformed
    newWorkspace();//GEN-LAST:event_newWorkspaceButtonActionPerformed
}


private void startExperimentButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_startExperimentButtonActionPerformed
    startExperiment();
}//GEN-LAST:event_startExperimentButtonActionPerformed

private void stopExperimentButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_stopExperimentButtonActionPerformed
    stopExperiment();
}//GEN-LAST:event_stopExperimentButtonActionPerformed

private void logButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_logButtonActionPerformed
    logPanel.showWindow();
}//GEN-LAST:event_logButtonActionPerformed

private void openWorkspaceButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_openWorkspaceButtonActionPerformed
    openWorkspace();
}//GEN-LAST:event_openWorkspaceButtonActionPerformed

private void saveWorkspaceButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveWorkspaceButtonActionPerformed
    saveWorkspace();
}//GEN-LAST:event_saveWorkspaceButtonActionPerformed

private void aboutButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_aboutButtonActionPerformed
    showAbout();
}//GEN-LAST:event_aboutButtonActionPerformed
 


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private static javax.swing.JButton aboutButton;
    private static pl.edu.zut.wi.vsl.app.gui.Desktop desktop;
    private javax.swing.JInternalFrame desktopFrame;
    private javax.swing.JScrollPane desktopFrameInternalScrollPane;
    private javax.swing.JScrollPane desktopFrameScrollPane;
    private static javax.swing.JButton logButton;
    private static pl.edu.zut.wi.vsl.app.logging.LogPanel logPanel;
    private javax.swing.JToolBar.Separator menuSeparator1;
    private javax.swing.JToolBar.Separator menuSeparator2;
    private javax.swing.JToolBar.Separator menuSeparator3;
    private javax.swing.JToolBar.Separator menuSeparator4;
    private javax.swing.JToolBar.Separator menuSeparator5;
    private javax.swing.JToolBar.Separator menuSeparator6;
    private javax.swing.JTree modulesTree;
    private static javax.swing.JButton newWorkspaceButton;
    private static javax.swing.JButton openWorkspaceButton;
    private static javax.swing.JProgressBar progressBar;
    private static javax.swing.JButton saveWorkspaceButton;
    private static javax.swing.JButton startExperimentButton;
    private static javax.swing.JButton stopExperimentButton;
    private javax.swing.JToolBar toolBar;
    private static javax.swing.JScrollPane windowScrollPane;
    // End of variables declaration//GEN-END:variables

    /** Extension for VSL's workspace files */
    public static final String VSL_WORKSPACE_EXTENSION = "vws"; 
    /** Number of increment units for windows scrollbars */
    public static int windowsScrollIncrement;
    /** Title <code>String</code> for new workspace dialog */
    private static final String NEW_WORKSPACE_TITLE = "VSL - create new Workspace";
    /** Log4J Logger */
    private static final Logger logger = Logger.getLogger(MainWindow.class);
    /** Flow monitor */
    FlowMonitor flowMonitor;
    /** GUI properties */
    private static final int DESKTOP_WIDTH = 800;
    private static final int DESKTOP_HEIGHT = 700;
    private static final int SCROLL_INC = 16;
    private static final int WINDOWS_SCROLL_INC = 16;
    /** Class providing drag and drop operations */
    private TreeDragSource ds;
    
}
