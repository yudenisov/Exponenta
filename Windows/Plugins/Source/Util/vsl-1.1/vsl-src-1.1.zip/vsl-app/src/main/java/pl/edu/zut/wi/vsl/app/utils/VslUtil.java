/*
 *    Virtual Steganographic Laboratory (VSL)
 *    Copyright (C) 2008-2011  M. Wegrzyn <bend-up@users.sourceforge.net>

 *    This file is part of Virtual Steganographic Laboratory (VSL).

 *    VSL is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.

 *    VSL is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.

 *    You should have received a copy of the GNU General Public License
 *    along with VSL.  If not, see <http://www.gnu.org/licenses/>.
 */
package pl.edu.zut.wi.vsl.app.utils;

import pl.edu.zut.wi.vsl.app.gui.panels.ErrorPane;
import java.awt.Component;
import java.net.URL;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import pl.edu.zut.wi.vsl.app.MainWindow;

/**
 * Utility for various type of functions.
 * 
 * @author Michal Wegrzyn
 */
public class VslUtil {

    private static volatile VslUtil INSTANCE;
    private static final String preferredErrorTitle = "VSL - Error";
    private static final String preferredWarningTitle = "VSL - Warning";
    private static final String BASE_ICON_PATH =
            "/pl/edu/zut/wi/vsl/app/gui/icons/";
    private static final URL ERROR =
            MainWindow.class.getResource(BASE_ICON_PATH + "dialog-error32x32.png");
    private static final URL WARN =
            MainWindow.class.getResource(BASE_ICON_PATH + "dialog-warning32x32.png");
    private static final URL INFO =
            MainWindow.class.getResource(BASE_ICON_PATH + "dialog-information32x32.png");
    private static final URL QUESTION =
            MainWindow.class.getResource(BASE_ICON_PATH + "dialog-question32x32.png");
    private static final URL LOGO =
            MainWindow.class.getResource(BASE_ICON_PATH + "logo.png");
    public static final ImageIcon ERROR_ICON = new ImageIcon(ERROR);
    public static final ImageIcon WARN_ICON = new ImageIcon(WARN);
    public static final ImageIcon INFO_ICON = new ImageIcon(INFO);
    public static final ImageIcon QUESTION_ICON = new ImageIcon(QUESTION);
    public static final ImageIcon LOGO_ICON = new ImageIcon(LOGO);
    public static final String OUT_OF_MEMORY_MSG =
            "Out of memory - there is no more heap space that" +
            " can currently\nbe reclaimed, and either the operating" +
            " system cannot provide\nany more memory to the JVM or" +
            " you have reached the JVM upper\nmemory bound.\n" +
            " In the second case, you may want to specify the Java" +
            " heap space.\nFor example, if you want to specify" +
            " an initial Java heap \nsize of 50 MB and a maximum " +
            "Java heap size of 512 MB, \nyou would start VSL as:\n" +
            "java -Xms50M -Xmx512M -jar <jar name>.jar";

    protected VslUtil() { }

    private static synchronized VslUtil tryCreateInstance() {
        if (INSTANCE == null) {
            INSTANCE = new VslUtil();
        }
        return INSTANCE;
    }

    public static VslUtil getInstance() {
        // use local variable, don't issue 2 reads (memory fences) to 'INSTANCE'
        VslUtil s = INSTANCE;
        if (s == null) {
            /* check under lock; 
             * move creation logic to a separate method to allow 
             * inlining of getInstance() */
            s = tryCreateInstance();
        }
        return s;
    }

    public static void showWarn(Component parentComponent, String message) {
        JOptionPane.showMessageDialog(parentComponent,
                message,
                preferredWarningTitle,
                JOptionPane.WARNING_MESSAGE, VslUtil.WARN_ICON);
    }

    public static void showError(Component parentComponent, String message) {
        JOptionPane.showMessageDialog(parentComponent,
                message,
                preferredErrorTitle,
                JOptionPane.ERROR_MESSAGE, ERROR_ICON);
    }

    public static void showError(final Component parentComponent,
            final String message, Throwable error) {
        final String errorMessage = getErrorTrace(error);
        final ErrorPane e = new ErrorPane(message, errorMessage);
        JOptionPane.showMessageDialog(parentComponent,
                e,
                preferredErrorTitle,
                JOptionPane.ERROR_MESSAGE, ERROR_ICON);
    }

    public static void showError(final Component parentComponent,
            final String message, final Throwable error, final String title) {
        final String windowTitle = title == null ? preferredErrorTitle : title;
        final String errorMessage = getErrorTrace(error);
        JOptionPane.showMessageDialog(parentComponent,
                message + "\n\nError message:\n" + errorMessage,
                windowTitle,
                JOptionPane.ERROR_MESSAGE, ERROR_ICON);
    }

    /**
     * Prepends zeros to given number and length and return String
     * representation of it.
     * @param number - number to prepend with zeros
     * @param length - length of result String
     * @return String representation with prepending zeros.
     */
    public static String prependZeros(final int number, final int length) {
        if (number < 0) {
            throw new IllegalArgumentException("Number must be " +
                    "a non-negative integer");
        }
        if (length < 1) {
            throw new IllegalArgumentException("Lenght must be" +
                    "a positive integer value");
        }
        if (String.valueOf(number).length() > length) {
            throw new IllegalArgumentException("Number's length must be " +
                    "greater than given length");
        }
        // twelve zeros prepended
        final String s = "000000000000" + number;
        // keep the rightmost 'length' chars    
        return s.substring(s.length() - length);
    }

    /**
     * Gets error whole trace as string.
     * @param error - error from which trace must be retrieved
     * @return String - trace from error as String
     */
    public static String getErrorTrace(final Throwable error) {
        final StackTraceElement[] trace = error.getStackTrace();
        String errorMessage = error.toString() + "\n";
        final Throwable cause = error.getCause();
        StringBuffer buf = new StringBuffer();
        for (int i = 0; i < trace.length; i++) {
            buf.append("\nat ");
            buf.append(trace[i]);
        }
        errorMessage += buf.toString();
        buf = new StringBuffer();
        if (cause != null) {
            buf.append("\nCause: ");
            buf.append(cause.toString());
            buf.append("\n");
            StackTraceElement[] causeTrace = cause.getStackTrace();
            for (int i = 0; i < causeTrace.length; i++) {
                buf.append("\nat ");
                buf.append(causeTrace[i]);
            }
        }
        errorMessage += buf.toString();
        return errorMessage;
    }

    /**
     * Converts string to boolean.
     * @param name String that should be converted to boolean
     * @return boolean value of given String
     */
    public static boolean toBoolean(final String text) {
        return ((text != null) && text.equalsIgnoreCase("true"));
    }
}
