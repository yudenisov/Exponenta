/*
 *    Virtual Steganographic Laboratory (VSL)
 *    Copyright (C) 2008-2011  M. Wegrzyn <bend-up@users.sourceforge.net>

 *    This file is part of Virtual Steganographic Laboratory (VSL).

 *    VSL is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.

 *    VSL is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.

 *    You should have received a copy of the GNU General Public License
 *    along with VSL.  If not, see <http://www.gnu.org/licenses/>.
 */
package pl.edu.zut.wi.vsl.app.gui.panels;

import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.io.File;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFileChooser;
import javax.swing.KeyStroke;
import org.apache.log4j.Logger;

/**
 * Panel for customizing report module.
 * 
 * @author Michal Wegrzyn
 */
public class ReportPanel extends javax.swing.JPanel {

    public static final int REPORT_ALL_ID = 0;
    public static final int ITERATION_ID = 1;
    public static final int INPUT_ID = 2;
    public static final int IN_ID = 3;
    public static final int OUT_ID = 4;    
    public static final int FILENAME_ID = 5;
    public static final int SIZE_ID = 6;
    public static final int MSG_SIZE_ID = 7;     
    public static final int PSNR_ID = 8;
    public static final int RPSNR = 9;
    public static final int ANALYSIS_ID = 10;
    
    
    private final static Logger logger = Logger.getLogger(ReportPanel.class);
    /** Title for <code>JFileChooser</code> opened during 
     * choosing output folder for report file. */
    private static final String preferredTitle = "VSL - choose output folder";
    private static final String REPORT_ALL = "Report all";
    private static final String REPORT_ALL_DESC = "Creates report on every " +
                                                    "execution";
    private static final String REPORT_LATEST = "Report latest";
    private static final String REPORT_LATEST_DESC = "Creates report only on " +
                                                    "the module that is input" +
                                                    " of this Report module";
    private File selectedDirectory;
    private boolean reportAll;
    private boolean iteration;
    private boolean input;
    private boolean in;
    private boolean out;    
    private boolean filename;
    private boolean size;
    private boolean msgSize;  
    private boolean psnr;
    private boolean rpsnr;
    private boolean analysisResult;
    
      

    /** Creates new form ReportPanel */
    public ReportPanel(File dir, String pattern, boolean[] reportVars) {
        reportAll = reportVars[ReportPanel.REPORT_ALL_ID];
        iteration = reportVars[ReportPanel.ITERATION_ID];
        input = reportVars[ReportPanel.INPUT_ID];
        in = reportVars[ReportPanel.IN_ID];
        out = reportVars[ReportPanel.OUT_ID];
        filename = reportVars[ReportPanel.FILENAME_ID];
        size = reportVars[ReportPanel.SIZE_ID];
        msgSize = reportVars[ReportPanel.MSG_SIZE_ID];
        psnr = reportVars[ReportPanel.PSNR_ID];
        rpsnr = reportVars[ReportPanel.RPSNR];
        analysisResult = reportVars[ReportPanel.ANALYSIS_ID];
        
        initComponents();
        reportTypeComboBox.setToolTipText(reportAll ? REPORT_ALL_DESC 
                                                : REPORT_LATEST_DESC);
        selectedDirectory = dir;
        folderpathField.setText(dir.getAbsolutePath());
        namePatternField.setText(pattern);
        KeyStroke chooseKeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_INSERT, 
                                                                    0, false);
        Action deleteAction = new AbstractAction() {
            //insert opens file chooser
            public void actionPerformed(ActionEvent e) {
                chooseDirectory();
            }
        };
        getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(chooseKeyStroke, 
                                                                    "INSERT");
        getActionMap().put("INSERT", deleteAction);
    }
    
    public boolean[] getReportVariables() {
        boolean[] rv = {reportAll, iteration, input, in, out, filename,
                        size, msgSize, psnr, rpsnr, analysisResult};        
        return rv;
    }
    
    /**
     * Getter for output directory.
     * @return Path to directory in which report will be saved.
     */
    public File getDirectory() {
        return selectedDirectory;
    }

    /**
     * Getter for name pattern.
     * @return Pattern for report
     */
    public String getPattern() {
        return namePatternField.getText();
    }
    
    /**
     * Handles choosing output directory.
     */
    private void chooseDirectory() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        fileChooser.setDialogTitle(preferredTitle);
        fileChooser.setFileHidingEnabled(false);
        fileChooser.setMultiSelectionEnabled(false);
        int returnValue = fileChooser.showDialog(getTopLevelAncestor(), 
                                                                    "Select");
        if (returnValue == JFileChooser.APPROVE_OPTION) {
            if (selectedDirectory != fileChooser.getSelectedFile()) {
                selectedDirectory = fileChooser.getSelectedFile();
                String dir = selectedDirectory.getAbsolutePath();
                logger.info("Selected output directory: " + dir);
                folderpathField.setText(dir);
            }
        }
    }    

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        namePatternLabel = new javax.swing.JLabel();
        folderpathLabel = new javax.swing.JLabel();
        namePatternField = new javax.swing.JTextField();
        folderpathField = new javax.swing.JTextField();
        chooseFolderButton = new javax.swing.JButton();
        reportTypeLabel = new javax.swing.JLabel();
        String[] types = {REPORT_ALL, REPORT_LATEST};
        reportTypeComboBox = new JComboBox(types);
        itemsLabel = new javax.swing.JLabel();
        inputCb = new javax.swing.JCheckBox();
        inputCb.setSelected(input);
        iterationCb = new javax.swing.JCheckBox();
        iterationCb.setSelected(iteration);
        inCb = new javax.swing.JCheckBox();
        inCb.setSelected(in);
        outCb = new javax.swing.JCheckBox();
        outCb.setSelected(out);
        filenameCb = new javax.swing.JCheckBox();
        filenameCb.setSelected(filename);
        sizeCb = new javax.swing.JCheckBox();
        sizeCb.setSelected(size);
        psnrCb = new javax.swing.JCheckBox();
        psnrCb.setSelected(psnr);
        analysisResultCb = new javax.swing.JCheckBox();
        analysisResultCb.setSelected(analysisResult);
        rpsnrCb = new javax.swing.JCheckBox();
        rpsnrCb.setSelected(rpsnr);
        msgSizeCb = new javax.swing.JCheckBox();
        msgSizeCb.setSelected(msgSize);

        namePatternLabel.setText("Name pattern:");
        namePatternLabel.setToolTipText("Name pattern for output files");

        folderpathLabel.setText("Folder:");
        folderpathLabel.setToolTipText("Folder for output file(s)");

        namePatternField.setToolTipText("Specify output file name pattern (without fileformat)");

        folderpathField.setEditable(false);
        folderpathField.setToolTipText("Path to the folder in which trport file should be be written");

        chooseFolderButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pl/edu/zut/wi/vsl/app/gui/icons/folder22x22.png"))); // NOI18N
        chooseFolderButton.setToolTipText("Choose folder for report file (Ins)");
        chooseFolderButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chooseFolderButtonActionPerformed(evt);
            }
        });

        reportTypeLabel.setText("Report type:");
        reportTypeLabel.setToolTipText("Choose report type. All - reports all executions; latest - only previous (the one before this Report module)");

        reportTypeComboBox.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Report all", "Report latest" }));
        reportTypeComboBox.setSelectedIndex((reportAll) ? 0 : 1);
        reportTypeComboBox.setToolTipText(reportAll ? REPORT_ALL_DESC : REPORT_LATEST_DESC);
        reportTypeComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                reportTypeComboBoxActionPerformed(evt);
            }
        });

        itemsLabel.setText("Items to report:");
        itemsLabel.setToolTipText("Choose items that Report should contain");

        inputCb.setText("number of Input");
        inputCb.setToolTipText("Number of Input which is source of flow that contains this Report module");
        inputCb.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputCbActionPerformed(evt);
            }
        });

        iterationCb.setText("number of iteration");
        iterationCb.setToolTipText("Number of iteration during experiment");
        iterationCb.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                iterationCbActionPerformed(evt);
            }
        });

        inCb.setText("module IN");
        inCb.setToolTipText("Input module of currently examined module");
        inCb.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inCbActionPerformed(evt);
            }
        });

        outCb.setText("module OUT");
        outCb.setToolTipText("Examined module - module that is input of this Report module");
        outCb.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                outCbActionPerformed(evt);
            }
        });

        filenameCb.setText("image filename");
        filenameCb.setToolTipText("Filename of the carried image");
        filenameCb.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                filenameCbActionPerformed(evt);
            }
        });

        sizeCb.setText("image size");
        sizeCb.setToolTipText("Size of the carried image");
        sizeCb.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sizeCbActionPerformed(evt);
            }
        });

        psnrCb.setText("PSNR");
        psnrCb.setToolTipText("Peak to Signal Noise Ratio");
        psnrCb.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                psnrCbActionPerformed(evt);
            }
        });

        analysisResultCb.setText("analysis result");
        analysisResultCb.setToolTipText("Result message from steganalysis module");
        analysisResultCb.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                analysisResultCbActionPerformed(evt);
            }
        });

        rpsnrCb.setText("RPSNR");
        rpsnrCb.setToolTipText("Relative Peak to Signal Noise Ratio");
        rpsnrCb.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rpsnrCbActionPerformed(evt);
            }
        });

        msgSizeCb.setText("message size");
        msgSizeCb.setToolTipText("Size of the carried message");
        msgSizeCb.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                msgSizeCbActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(namePatternLabel)
                            .addComponent(folderpathLabel)
                            .addComponent(reportTypeLabel))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(inCb)
                                    .addComponent(outCb)
                                    .addComponent(filenameCb)
                                    .addComponent(inputCb)
                                    .addComponent(iterationCb))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(msgSizeCb)
                                    .addComponent(sizeCb)
                                    .addComponent(psnrCb)
                                    .addComponent(rpsnrCb)
                                    .addComponent(analysisResultCb)))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(reportTypeComboBox, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(namePatternField, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(folderpathField, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 340, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(chooseFolderButton))))
                    .addComponent(itemsLabel))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(folderpathLabel)
                            .addComponent(folderpathField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(13, 13, 13)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(namePatternLabel)
                            .addComponent(namePatternField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(16, 16, 16)
                                .addComponent(reportTypeLabel)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(itemsLabel))
                            .addGroup(layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(reportTypeComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(iterationCb)
                            .addComponent(sizeCb))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(inputCb)
                            .addComponent(msgSizeCb))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(inCb)
                            .addComponent(psnrCb))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(outCb)
                            .addComponent(rpsnrCb))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(filenameCb)
                            .addComponent(analysisResultCb)))
                    .addComponent(chooseFolderButton))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

private void chooseFolderButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chooseFolderButtonActionPerformed
    chooseDirectory();
}//GEN-LAST:event_chooseFolderButtonActionPerformed

private void iterationCbActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_iterationCbActionPerformed
    iteration = !iteration;
}//GEN-LAST:event_iterationCbActionPerformed

private void inCbActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inCbActionPerformed
    in = !in;
}//GEN-LAST:event_inCbActionPerformed

private void filenameCbActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_filenameCbActionPerformed
    filename = !filename;
}//GEN-LAST:event_filenameCbActionPerformed

private void inputCbActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputCbActionPerformed
    input = !input;
}//GEN-LAST:event_inputCbActionPerformed

private void outCbActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_outCbActionPerformed
    out = !out;
}//GEN-LAST:event_outCbActionPerformed

private void sizeCbActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sizeCbActionPerformed
    size = !size;
}//GEN-LAST:event_sizeCbActionPerformed

private void psnrCbActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_psnrCbActionPerformed
    psnr = !psnr;
}//GEN-LAST:event_psnrCbActionPerformed

private void analysisResultCbActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_analysisResultCbActionPerformed
    analysisResult = !analysisResult;
}//GEN-LAST:event_analysisResultCbActionPerformed

private void rpsnrCbActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rpsnrCbActionPerformed
    rpsnr = !rpsnr;
}//GEN-LAST:event_rpsnrCbActionPerformed

private void msgSizeCbActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_msgSizeCbActionPerformed
    msgSize = !msgSize;
}//GEN-LAST:event_msgSizeCbActionPerformed

private void reportTypeComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_reportTypeComboBoxActionPerformed
    JComboBox cb = (JComboBox) evt.getSource();
    String selectedType = (String)cb.getSelectedItem();
    reportAll = selectedType.equals(ReportPanel.REPORT_ALL) ? true : false;
    reportTypeComboBox.setToolTipText(reportAll ? REPORT_ALL_DESC 
                                                : REPORT_LATEST_DESC);
}//GEN-LAST:event_reportTypeComboBoxActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JCheckBox analysisResultCb;
    private javax.swing.JButton chooseFolderButton;
    private javax.swing.JCheckBox filenameCb;
    private javax.swing.JTextField folderpathField;
    private javax.swing.JLabel folderpathLabel;
    private javax.swing.JCheckBox inCb;
    private javax.swing.JCheckBox inputCb;
    private javax.swing.JLabel itemsLabel;
    private javax.swing.JCheckBox iterationCb;
    private javax.swing.JCheckBox msgSizeCb;
    private javax.swing.JTextField namePatternField;
    private javax.swing.JLabel namePatternLabel;
    private javax.swing.JCheckBox outCb;
    private javax.swing.JCheckBox psnrCb;
    private javax.swing.JComboBox reportTypeComboBox;
    private javax.swing.JLabel reportTypeLabel;
    private javax.swing.JCheckBox rpsnrCb;
    private javax.swing.JCheckBox sizeCb;
    // End of variables declaration//GEN-END:variables



}
