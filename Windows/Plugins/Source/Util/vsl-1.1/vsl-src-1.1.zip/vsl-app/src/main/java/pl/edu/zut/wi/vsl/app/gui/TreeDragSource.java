/*
 *    Virtual Steganographic Laboratory (VSL)
 *    Copyright (C) 2008-2011  M. Wegrzyn <bend-up@users.sourceforge.net>

 *    This file is part of Virtual Steganographic Laboratory (VSL).

 *    VSL is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.

 *    VSL is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.

 *    You should have received a copy of the GNU General Public License
 *    along with VSL.  If not, see <http://www.gnu.org/licenses/>.
 */
package pl.edu.zut.wi.vsl.app.gui;

import java.awt.dnd.DnDConstants;
import java.awt.dnd.DragGestureEvent;
import java.awt.dnd.DragGestureListener;
import java.awt.dnd.DragGestureRecognizer;
import java.awt.dnd.DragSource;
import java.awt.dnd.DragSourceDragEvent;
import java.awt.dnd.DragSourceDropEvent;
import java.awt.dnd.DragSourceEvent;
import java.awt.dnd.DragSourceListener;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreePath;
import org.apache.log4j.Logger;
import pl.edu.zut.wi.vsl.app.utils.VslUtil;

/**
 * A drag source wrapper for a JTree. This class can be used to make
 * a rearrangeable DnD tree with the TransferableTreeNode class as the
 * transfer data type.   
 * 
 * @author Michal Wegrzyn
 */
public class TreeDragSource implements DragSourceListener, DragGestureListener {

    private static final Logger logger = Logger.getLogger(TreeDragSource.class);
    DragSource source;
    DragGestureRecognizer recognizer;
    TransferableTreeNode transferable;
    DefaultMutableTreeNode oldNode;
    JTree sourceTree;

    public TreeDragSource(JTree tree, int actions) {
        sourceTree = tree;
        source = new DragSource();
        recognizer = source.createDefaultDragGestureRecognizer(sourceTree,
                actions, this);
    }

    /*
     * Creates Drag Gesture Handler.
     */
    public void dragGestureRecognized(DragGestureEvent dge) {
        TreePath path = sourceTree.getSelectionPath();
        if ((path == null) || (path.getPathCount() <= 1) ||
                !path.getLastPathComponent().getClass().equals(
                                                TransferableTreeNode.class)) {
            // We can't move the root node or an empty selection
            return;
        }

        oldNode = (DefaultMutableTreeNode) path.getLastPathComponent();
        try {
            transferable = (TransferableTreeNode) 
                            path.getPathComponent(path.getPathCount() - 1);
            source.startDrag(dge, DragSource.DefaultCopyDrop, 
                                            transferable, this);
        } catch (Exception e) {
            String msg = "Cannot perform this drop.";
            logger.warn(msg, e);
            VslUtil.showWarn(null, msg);
        }
    }

    /*
     * Drag Event Handlers
     */
    public void dragEnter(DragSourceDragEvent dsde) {
    }

    public void dragExit(DragSourceEvent dse) {
    }

    public void dragOver(DragSourceDragEvent dsde) {
    }

    public void dropActionChanged(DragSourceDragEvent dsde) {
    }

    public void dragDropEnd(DragSourceDropEvent dsde) {

        /* to support move or copy, we have to check which occurred: */
        if (dsde.getDropSuccess() && 
                        (dsde.getDropAction() == DnDConstants.ACTION_MOVE)) {
            ((DefaultTreeModel) 
                    sourceTree.getModel()).removeNodeFromParent(oldNode);
        }
    }
}
