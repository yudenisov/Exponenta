/*
 *    Virtual Steganographic Laboratory (VSL)
 *    Copyright (C) 2008-2011  M. Wegrzyn <bend-up@users.sourceforge.net>

 *    This file is part of Virtual Steganographic Laboratory (VSL).

 *    VSL is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.

 *    VSL is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.

 *    You should have received a copy of the GNU General Public License
 *    along with VSL.  If not, see <http://www.gnu.org/licenses/>.
 */
package pl.edu.zut.wi.vsl.app.gui;

import pl.edu.zut.wi.vsl.app.gui.panels.ParametersWindow;
import pl.edu.zut.wi.vsl.app.gui.panels.MessagePanel;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;
import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;
import org.apache.log4j.Logger;
import pl.edu.zut.wi.vsl.app.Main;
import pl.edu.zut.wi.vsl.app.modules.DisplayModule;
import pl.edu.zut.wi.vsl.app.modules.EncoderModule;
import pl.edu.zut.wi.vsl.app.modules.InputModule;
import pl.edu.zut.wi.vsl.app.modules.ModuleConnection;
import pl.edu.zut.wi.vsl.app.modules.OutputModule;
import pl.edu.zut.wi.vsl.app.modules.ReportModule;
import pl.edu.zut.wi.vsl.app.modules.VslModule;
import pl.edu.zut.wi.vsl.app.modules.VslModule.ModuleType;
import pl.edu.zut.wi.vsl.app.gui.panels.DisplayWindow;
import pl.edu.zut.wi.vsl.app.gui.panels.InputPanel;
import pl.edu.zut.wi.vsl.app.gui.panels.OutputPanel;
import pl.edu.zut.wi.vsl.app.gui.panels.ReportPanel;
import pl.edu.zut.wi.vsl.app.utils.VslUtil;
import pl.edu.zut.wi.vsl.commons.Message;

/**
 * Class representing appearance of every <code>VslModule</code>.
 * 
 * @see pl.edu.zut.wi.vsl.client.modules.VslModule
 * @author Michal Wegrzyn
 */
public class DeskItem extends JLabel implements ActionListener, Serializable {

    /**
     * Enumeration representing possible modes of DeskItem.
     */
    public enum Mode {
        /** No action actually taken on this module */
        None,
        /** Moving a <code>DeskItem</code> */
        Moving,
        /** Connecting this <code>DeskItem</code> with another */
        Connecting,
        /** Executing some experiment. Used to block mouse input while
         * processing experiment. */
        Executing;
    };

    /** Global mode of all instances of <code>DeskItem</code>. */
    protected static Mode globalMode;
    /** Current location of mouse cursor. Used for drawing connection
     * during Mode.Connecting mode.
     */
    protected static Point current;
    /** Previous location of mouse cursor. Used for drawing connection
     * during Mode.Connecting mode.
     */
    protected static Point previous;
    /** Should gradient rendering be down at all? */
    protected static final boolean GRADIENTS = true;
    /** Is this DeskItem in a selected state? */
    protected boolean selected;
    /** Current Mode of this <code>DeskItem</code>. */
    protected Mode currentMode;
    /** For serialization */
    private static final long serialVersionUID = -4611324549112439948L;    
    /** Title for dialog window. */
    private static final String removeItemTitle = "VSL - remove item";
    /** <code>Logger</code> instance for this class. */
    private static final Logger logger = Logger.getLogger(DeskItem.class);
    /** The parent desktop */
    private transient Desktop parent;
    /** Preferred width of <code>DeskItem</code> instances.
     * This value is used when value from properties could not been obtained. */
    private static final int preferredWidth = 80;
    /** Preferred height of <code>DeskItem</code> instances.
     * This value is used when value from properties could not been obtained. */
    private static final int preferredHeight = 50;
    /** Actual width that will be applied to this <code>DeskItem</code>. */
    private static int mWidth;
    /** Actual width that will be applied to this <code>DeskItem</code>. */
    private static int mHeight;     
    /** <code>VslModule</code> that is representing 
     * this <code>DeskItem</code> */
    private VslModule vslModule;    
    /** The MouseMotionListener created to manage our drag state. */
    private DeskItemMouseMotionListener mml;
    /** <code>JPopupMenu</code> for this <code>DeskItem</code> */
    private JPopupMenu popupMenu;
    private JMenuItem connectMI;
    private JMenuItem removeMI;
    private JMenuItem propertiesMI;
    private JMenuItem messageMI;
    private JMenuItem inputMI;
    private JMenuItem outputMI;
    private JMenuItem reportMI;
    private JMenuItem viewImagesMI;

    /* Apply properties for all DeskItems */
    static {
        globalMode = Mode.None;
        try {
            mWidth = Integer.parseInt(Main.getProperty("vsl.modules.width",
                    String.valueOf(preferredWidth)));
        } catch (NumberFormatException e) {
            logger.error("Could not set preferred width", e);
            mWidth = preferredWidth;
        }
        try {
            mHeight = Integer.parseInt(Main.getProperty("vsl.modules.height",
                    String.valueOf(preferredWidth)));
        } catch (NumberFormatException e) {
            logger.error("Could not set preferred height", e);
            mHeight = preferredHeight;
        }
    }

    /** Default constructor for serialization */
    public DeskItem() {
    }
    
    /**
     * Creates a DeskItem that is on a JLayeredPane with 
     * the passed String identifier, position and module 
     * which this item should be representing.
     * @param pane The <code>JLayeredPane</code> that the item 
     * will be placed on.
     * @param label The <code>Label</code> string to use.
     * @param x X coordinate of item's initial position.
     * @param y Y coordinate of item's initial position.
     * @param vModule <code>VslModule</code> that this item
     * should represent.
     */
    public DeskItem(final Desktop pane, final String label, final int x,
            final int y, final VslModule vModule) {
        super(label, JLabel.CENTER);
        this.parent = pane;
        vslModule = vModule;
        initialize();
        setLocation(x, y);
        if (vslModule == null) {
            setToolTipText(label);
        } else {
            setToolTipText(vslModule.getDescription());
        }
        setName(vslModule.getName());
    }

    /**
     * Shows window with properties that can be adjusted for contained module.
     */
    public void invoke() {
        logger.trace("Invoking " + getName() + " module");
        if (vslModule.getModuleType() == ModuleType.Input) {
            showInputDialog();
        } else if (vslModule.getModuleType() == ModuleType.Output) {
            showOutputDialog();
        } else if (vslModule.getModuleType() == ModuleType.Report) {
           showReportDialog(); 
        } else if (vslModule.getModuleType() == ModuleType.SteganographicEncoder) {
            showMessageDialog();
        } else if (vslModule.getModuleType() == ModuleType.Display) {
            showDisplayWindow();
        } else {
            showPropertiesWindow();
        }
    }

    /**
     * {@inheritDoc}
     */
    public void actionPerformed(ActionEvent e) {
        JMenuItem menuItem = (JMenuItem) e.getSource();
        // Find out which command was selected
        if (menuItem.equals(connectMI)) {
            logger.info("Connecting...");
            connectComponents();
        } else if (menuItem.equals(removeMI)) {
            int decision = JOptionPane.showConfirmDialog(getTopLevelAncestor(),
                    "Do you really want to remove this item?",
                    DeskItem.removeItemTitle, JOptionPane.YES_NO_OPTION,
                    JOptionPane.QUESTION_MESSAGE, VslUtil.QUESTION_ICON);
            if (decision == JOptionPane.YES_OPTION) {
                logger.info(getName() + " - removing");
                remove();
            }
        } else if (menuItem.equals(propertiesMI)) {
            logger.info(getName() + " showing properties");
            showPropertiesWindow();
        } else if (menuItem.equals(messageMI)) {
            logger.info(getName() + " showing message dialog");
            showMessageDialog();
        } else if (menuItem.equals(inputMI)) {
            logger.info(getName() + " showing Input dialog");
            showInputDialog();
        } else if (menuItem.equals(outputMI)) {
            logger.info(getName() + " showing Output dialog");
            showOutputDialog();
        } else if (menuItem.equals(reportMI)) {
            logger.info(getName() + " showing Report dialog");
            showReportDialog();
        } else if (menuItem.equals(viewImagesMI)) {
            logger.info(getName() + " showing display window");
            showDisplayWindow();
        }
    }

    /**
     * Returns the coordinates of the closest "connector" point to the
     * supplied point. Coordinates are in the parent containers coordinate
     * space.
     *
     * @param pt the reference point
     * @return the closest connector point
     */
    public Point getClosestConnectorPoint(final Point pt) {
        int sourceX = getX();
        int sourceY = getY();
        int sourceWidth = getWidth();
        int sourceHeight = getHeight();
        int sourceMidX = sourceX + (sourceWidth / 2);
        int sourceMidY = sourceY + (sourceHeight / 2);
        int x = (int) pt.getX();
        int y = (int) pt.getY();

        Point closest = new Point();
        int cx = (Math.abs(x - sourceMidX) < Math.abs(y - sourceMidY)) 
                                ? sourceMidX 
                                : ((x < sourceMidX) 
                                                ? sourceX 
                                                : sourceX + sourceWidth);
        int cy = (Math.abs(y - sourceMidY) < Math.abs(x - sourceMidX)) 
                                ? sourceMidY 
                                : ((y < sourceMidY) 
                                                ? sourceY 
                                                : sourceY + sourceHeight);
        closest.setLocation(cx, cy);
        return closest;
    }

    private DeskItem getLast() {
        return parent.getLastItem();
    }

    private void setLast(DeskItem item) {
        parent.setLastItem(item);
    }

    /**
     * Marks items to which we cannot connect.
     */
    private void markUnconnectableItems() {
        parent.markUnconnectableItems(this);
    }
    
    /**
     * Unmarks items to which we could not connect after exiting connecting mode.
     */
    public void unmarkUnconnectableItems() {
        parent.unmarkUnconnectableItems(this);
    }
    
    /**
     * Tells whether GRADIENTS should be painted at all.
     * @return <code>true</code> if GRADIENTS should be painted,
     * otherwise <code>false</code>
     */
    public static boolean hasGradients() {
        return GRADIENTS;
    }

    /**
     * Sets layer for this <code>DeskItem</code> instance.
     * @param p The <code>JLayeredPane</code> that the item will be placed on.
     */
    public void setParentPane(final Desktop p) {
        parent = p;
    }

    /**
     * Removed given connection from the parent container.
     * @param connection Module connection which should be removed
     */
    public void removeConnection(ModuleConnection connection) {
        parent.removeConnection(connection);
    }

    /**
     * Adds given connection to the parent container
     * @param connection Module connection which should be added
     */
    public void addConnection(ModuleConnection connection) {
        parent.addConnection(connection);
    }

    /**
     * Gets global mode - mode that describes state of all instances
     * of <code>DeskItem</code>.
     * @return global mode of all items placed on <code>DeskTop</code>.
     */
    public static Mode getGlobalMode() {
        return globalMode;
    }

    /**
     * Sets global mode - mode that describes state of all instances
     * of <code>DeskItem</code>.
     * @param newMode global mode of all items placed on <code>DeskTop</code>.
     */    
    public static void setGlobalMode(final Mode newMode) {
        logger.debug("global mode: " + newMode.toString());
        globalMode = newMode;
    }

    public Mode getMode() {
        return currentMode;
    }

    public void setMode(final Mode newMode) {
        logger.debug("current mode: " + newMode.toString());
        currentMode = newMode;
    }

    /**
     * Gets <code>VslModule</code> instance.
     * @return <code>VslModule</code> instance that is representing this
     * <code>DeskItem</code>.
     */
    public VslModule getModuleInstance() {
        return vslModule;
    }

    /**
     * Make the selectable object bigger to surround the text 
     * with coloring.
     */
    protected void setBorder() {
        setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
    }

    /**
     * Called when the mouse enters this DeskItem.
     */
    protected void enter() {
        if (GRADIENTS && globalMode != Mode.Connecting) {
            selected = true;
            setUI(DeskItemUI.UI_SELECTED);
            setOpaque(true);
            repaint();
        }
    }

    /**
     * Called when the mouse exits this DeskItem.
     */
    protected void exit() {
        //setOpaque(false);
        if (GRADIENTS && globalMode != Mode.Connecting) {
            selected = false;
            setUI(DeskItemUI.UI_NORMAL);
            repaint();
        }
        
    }

    /**
     * Called when the user performs a context menu click using the popup 
     * trigger button/operation associated with the component.
     * @param ev The associated mouse event to get the context from.
     */
    protected void popup(MouseEvent ev) {
        popupMenu.show(ev.getComponent(), ev.getX(), ev.getY());
    }

    private void initialize() {
        mouseInit();
        setVisible(true);
        setForeground(Color.black);
        createPopupMenu();
        setSize(new Dimension(mWidth, mHeight));
        setBorder(new javax.swing.border.LineBorder(Color.BLACK, 1, true));
        currentMode = Mode.None;
        globalMode = Mode.None;
        enter();
        if (getLast() != null) {
            getLast().exit();
        }
        setLast(this);
    }

    /**
     * Activates all the mouse listening activities
     */
    private void mouseInit() {
        mml = new DeskItemMouseMotionListener();
        addMouseMotionListener(mml);
        addMouseListener(new DeskItemMouseAdapter());
    }    

    /**
     * Creates <code>JPopupMenu</code> for this <code>DeskItem</code>
     * that is stores and showed when needed.
     */
    private void createPopupMenu() {
        popupMenu = new JPopupMenu();
        connectMI = new JMenuItem("Connect");
        connectMI.setMnemonic(KeyEvent.VK_C);
        connectMI.addActionListener(this);
        popupMenu.add(connectMI);
        popupMenu.addSeparator();
        if (vslModule.getModuleType() == ModuleType.Input) {
            inputMI = new JMenuItem("Select input...");
            inputMI.setMnemonic(KeyEvent.VK_I);
            inputMI.addActionListener(this);
            popupMenu.add(inputMI);
            popupMenu.addSeparator();
        } else if (vslModule.getModuleType() == ModuleType.Output) {
            outputMI = new JMenuItem("Select output...");
            outputMI.setMnemonic(KeyEvent.VK_O);
            outputMI.addActionListener(this);
            popupMenu.add(outputMI);
            popupMenu.addSeparator();
        } else if (vslModule.getModuleType() == ModuleType.Report) {
            reportMI = new JMenuItem("Configure report...");
            reportMI.setMnemonic(KeyEvent.VK_T);
            reportMI.addActionListener(this);
            popupMenu.add(reportMI);
            popupMenu.addSeparator();
        } else if (vslModule.getModuleType() == ModuleType.Display) {
            viewImagesMI = new JMenuItem("View images...");
            viewImagesMI.setMnemonic(KeyEvent.VK_V);
            viewImagesMI.addActionListener(this);
            popupMenu.add(viewImagesMI);
            popupMenu.addSeparator();
        } else if (vslModule.getModuleType() == 
                                        ModuleType.SteganographicEncoder) {
            messageMI = new JMenuItem("Message...");
            messageMI.setMnemonic(KeyEvent.VK_M);
            messageMI.addActionListener(this);
            popupMenu.add(messageMI);
            popupMenu.addSeparator();
        }
        removeMI = new JMenuItem("Remove");
        removeMI.setMnemonic(KeyEvent.VK_R);
        removeMI.addActionListener(this);
        popupMenu.add(removeMI);
        if (vslModule.hasParameters()) {
            popupMenu.addSeparator();
            propertiesMI = new JMenuItem("Parameters...");
            propertiesMI.setMnemonic(KeyEvent.VK_P);
            propertiesMI.addActionListener(this);
            popupMenu.add(propertiesMI);
        }
    }    

    /**
     * Initiates the connection process for two 
     * instances of <code>DeskItem</code>.
     */
    private void connectComponents() {
        
        // connecting only with connectable (distinguish visually modules
        // to which user can connect

        Point p = getLocation();
        Point closest = getClosestConnectorPoint(new Point(getX(), getY()));
        current = new Point(p.x + (int) closest.getX(), 
                                p.y + (int) closest.getY());
        previous = current;
        Graphics2D g = (Graphics2D) getParent().getGraphics();
        g.setXORMode(java.awt.Color.white);
        g.dispose();

        currentMode = Mode.Connecting;
        globalMode = Mode.Connecting;
        VslModule m = vslModule;

        markUnconnectableItems();
        
        /* debug info */
        if (logger.isDebugEnabled()) {
            if(m.getInput() != null) {
                logger.debug(getName() + " has input");
            }
            if (m.getLoopInput() != null) {
                logger.debug(getName() + " has loop input");
            }
            if(m.getOutput() != null) {
                logger.debug(getName() + " has output");
            }
            if(m.getLoopOutput() !=  null) {
                logger.debug(getName() + " has loop output");
            }
        }

    }
    

    private void showPropertiesWindow() {
        if (vslModule.hasParameters()) {
            ParametersWindow pw = new ParametersWindow(
                                        vslModule.getParameters(),
                                        vslModule.getName());
            pw.show(this);

        } else {
            JOptionPane.showConfirmDialog(getTopLevelAncestor(),
                    "Module does not contain parameters to set.",
                    "VSL - Parameters for " + getText(),
                    JOptionPane.DEFAULT_OPTION,
                    JOptionPane.INFORMATION_MESSAGE,
                    VslUtil.INFO_ICON);
        }
    }

    private void showDisplayWindow() {
        if (((DisplayModule)vslModule).getImages() != null &&
                !((DisplayModule)vslModule).getImages().isEmpty()) {
            DisplayWindow d = new DisplayWindow(((DisplayModule)vslModule).getImages());
        } else {
            JOptionPane.showConfirmDialog(getTopLevelAncestor(),
                    "Module does not contain any images.",
                    "VSL - info ",
                    JOptionPane.DEFAULT_OPTION,
                    JOptionPane.INFORMATION_MESSAGE,
                    VslUtil.INFO_ICON);
        }
    }

    private void showMessageDialog() {
        Message m = ((EncoderModule)vslModule).getInitMessage();
        String path = m == null ? null
                : (m.getPath() == null ? null : m.getPath());
        MessagePanel op = new MessagePanel(path);
        int decision = JOptionPane.showConfirmDialog(getTopLevelAncestor(),
                op, MessagePanel.PREFERRED_TITLE,
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (decision == JOptionPane.OK_OPTION) {
            try {
                String p = op.getMessage().getPath();
                ((EncoderModule)vslModule).setInitMessage(p);
            } catch (Exception e) {
                logger.error("Could not create message", e);
                VslUtil.showError(getTopLevelAncestor(),
                        "Could not create message", e);
            }
        }
    }

    private void showInputDialog() {
        ArrayList<File> inputFiles = new ArrayList<File>();
        ArrayList<File> modFiles = ((InputModule)vslModule).getInputFiles();
        if (modFiles != null) {
            inputFiles.addAll(modFiles);
        }
        InputPanel ip = new InputPanel(inputFiles);
 
        int decision = JOptionPane.showConfirmDialog(getTopLevelAncestor(),
                ip, InputPanel.PREFERRED_TITLE,
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (decision == JOptionPane.OK_OPTION) {
            ((InputModule)vslModule).setInputFiles(ip.getFiles());
        }
    }

    private void showOutputDialog() {
        OutputPanel op = new OutputPanel(((OutputModule)vslModule).getOutputDirectory(),
                ((OutputModule)vslModule).getOutputPattern(),
                ((OutputModule)vslModule).getOutputNameFormat(),
                ((OutputModule)vslModule).getInput().getSource().getModuleType() !=
                                            ModuleType.SteganographicDecoder);
        int decision = JOptionPane.showConfirmDialog(getTopLevelAncestor(),
                op, OutputPanel.PREFERRED_TITLE,
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (decision == JOptionPane.OK_OPTION) {
            ((OutputModule)vslModule).setOutputDirectory(op.getDirectory());
            ((OutputModule)vslModule).setOutputPattern(op.getPattern());
            ((OutputModule)vslModule).setOutputNameFormat(op.getFormat());
        }
    }
    
    private void showReportDialog() {
        ReportPanel rp = new ReportPanel(((ReportModule)vslModule).getOutputDirectory(),
                ((ReportModule)vslModule).getOutputPattern(),
                ((ReportModule)vslModule).getReportVariables());
        int decision = JOptionPane.showConfirmDialog(getTopLevelAncestor(),
                rp, "VSL - configure Report module",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (decision == JOptionPane.OK_OPTION) {
            ((ReportModule)vslModule).setOutputDirectory(rp.getDirectory());
            ((ReportModule)vslModule).setOutputPattern(rp.getPattern());
            ((ReportModule)vslModule).setReportVariables(rp.getReportVariables());
        }
    }    

    /**
     * Removes this item from Desktop.
     */
    private void remove() {
        parent.removeItem(this);
    }    
    
    /**
     * The MouseAdapter that handles click events.
     */
    private class DeskItemMouseAdapter extends MouseAdapter 
                                                implements Serializable {

        /** For serialization */
        private static final long serialVersionUID = -4072487649056799851L;
        /**
         * The item this listener is associated with.
         */
        DeskItem item;

        /**
         * Creates an instance.
         */
        public DeskItemMouseAdapter() {
            this.item = DeskItem.this;
        }

        /**
         * Called when the user clicks on the DeskItem.
         * @param ev The event associated with the click operation.
         */
        @Override
        public void mouseClicked(MouseEvent ev) {
            if (globalMode == Mode.None) {
                if (ev.getClickCount() == 2 && 
                                    ev.getButton() == MouseEvent.BUTTON1) {
                    item.invoke();
                }
            }
        }

        /**
         * Called when the mouse is pressed down.
         * @param ev The associated event.
         */
        @Override
        public void mousePressed(MouseEvent ev) {
            switch (globalMode) {
                case None:
                    /* Check if popup */
                    if (ev.isPopupTrigger()) {
                        /* switch selected to this item */
                        if (getLast() != DeskItem.this && getLast() != null) {
                            getLast().exit();
                        }
                        setLast(DeskItem.this);
                        getLast().enter();
                        /* Show the menu if any */
                        popup(ev);
                        break;
                    }
                    /* Not popup, so clear last selected */
                    if (getLast() != null) {
                        getLast().exit();
                    }
                    if (ev.getButton() == 1) {
                        startDragging(ev);
                        currentMode = Mode.Moving;
                        globalMode = Mode.Moving;
                    }
                    break;
                case Connecting:
                    VslModule t = getModuleInstance();                  
                    
                    if (getLast() != this.item && getLast() != null &&
                            t.canConnect(getLast().getModuleInstance())) {

                        VslModule s = getLast().getModuleInstance();

                        if (t.isInputConnected() || 
                                        t.hasStraightForwardConnection(s)) {
                            /* creating loop connection between modules */
                            ModuleConnection mc = 
                                    new ModuleConnection(getLast(), item, 3);
                            s.setLoopOutput(mc);
                            t.setLoopInput(mc);
                            addConnection(mc);
                        } else {
                            /* creating normal module connection */
                            ModuleConnection mc = 
                                    new ModuleConnection(getLast(), item);
                            s.setOutput(mc);
                            t.setInput(mc);
                            addConnection(mc);
                        }
                        globalMode = Mode.None;
                        currentMode = Mode.None;
                        getLast().setMode(Mode.None);
                        getLast().exit();
                        setLast(DeskItem.this);
                        selected = true;
                        unmarkUnconnectableItems();
                        enter();
                        parent.repaint();

                    }
                    break;
                case Executing:
                default:
                    break;

            }
        }

        /**
         * Called when the mouse button is released.
         * @param ev The associated event.
         */
        @Override
        public void mouseReleased(MouseEvent ev) {

            switch (globalMode) {
                case None:
                    if (ev.isPopupTrigger()) {
                        /* Make sure the correct last item is identified */
                        if (getLast() != null && getLast() != DeskItem.this) {
                            getLast().exit();
                        }

                        setLast(DeskItem.this);
                        getLast().enter();
                        popup(ev);
                    }
                    break;
                case Moving:
                    /* When dropped, move back to the default layer */
                    if (parent != null) {
                        parent.setLayer(DeskItem.this,
                                JLayeredPane.DEFAULT_LAYER.intValue(), 0);
                    }
                    currentMode = Mode.None;
                    globalMode = Mode.None;
                    break;
                case Executing:
                default:
                    break;
            }
        }

        @Override
        public void mouseEntered(MouseEvent ev) {
            if (GRADIENTS && globalMode != Mode.Connecting) {
                setUI(selected
                               ? DeskItemUI.UI_SELECTED_ACTIVE
                               : DeskItemUI.UI_ACTIVE);
                setOpaque(true);
            }
            repaint();
        }

        @Override
        public void mouseExited(MouseEvent ev) {
            if (GRADIENTS && globalMode != Mode.Connecting) {
                setUI(selected ? DeskItemUI.UI_SELECTED : DeskItemUI.UI_NORMAL);
            }
            repaint();
        }
        /**
         * Called  when the drag operation starts.
         * @param ev The associated mouse event.
         */
        private void startDragging(MouseEvent ev) {
            setLast(DeskItem.this);
            getLast().enter();
            final int offx = ev.getX();
            final int offy = ev.getY();
            /* Create new listener as needed */
            if (mml == null) {
                mml = new DeskItemMouseMotionListener();
            }
            /* Set drag offsets into object */
            mml.setOffsets(offx, offy);
        }        
    }

    /**
     * The MouseMotionAdapter used to track motion operations.
     */
    private class DeskItemMouseMotionListener extends MouseMotionAdapter
            implements Serializable {

        /** For serialization */
        private static final long serialVersionUID = -4173244776578930084L;        
        /**
         * The x offset of the initial mouse click from the left 
         * edge of the DeskItem.
         */
        int offx;
        /**
         * The y offset of the mouse from the top of the DeskItem
         */
        int offy;

        /**
         * Updates the current offsets for each successive drag operation 
         * to the click point that the mouse was out when the mouse was pressed.
         * @param x The X location of the initial mouse down event.
         * @param y The Y location of the initial mouse down event.
         */
        public void setOffsets(int x, int y) {
            offx = x;
            offy = y;
        }

        /**
         * Called when the mouse is moved without a button down.
         * @param ev The associated event for this operation.
         */
        @Override
        public void mouseMoved(MouseEvent ev) {
        }

        /**
         * Called when the mouse is moved with button one down.
         * @param ev The associated mouse event.
         */
        @Override
        public void mouseDragged(MouseEvent ev) {
            if (globalMode == Mode.Moving) {
                Point pt = getLocation();
                Point p = new Point(ev.getX() + pt.x - offx,
                        ev.getY() + pt.y - offy);
                /* Positioning is every 5 pixels to make it easier to 
                 line things up. */
                p = new Point(p.x - p.x % 5 + 5, p.y - p.y % 5 + 5);
                /* On a JDesktopPane, change the layer so that
                 we pass over everything on the desktop */
                if (parent != null) {
                    parent.setLayer(DeskItem.this,
                            JLayeredPane.DRAG_LAYER.intValue());
                }
                int w = ((DeskItem)ev.getSource()).getWidth();
                int h = ((DeskItem)ev.getSource()).getHeight();
                int x = (ev.getX() + pt.x + w) > parent.getWidth() ?
                    parent.getWidth() - w : Math.max(0, p.x);
                int y = (ev.getY() + pt.y + h) > parent.getHeight() ?
                    parent.getHeight() - h : Math.max(0, p.y);
                setLocation(x, y);
                parent.repaint();
            }
        }
    }
}
