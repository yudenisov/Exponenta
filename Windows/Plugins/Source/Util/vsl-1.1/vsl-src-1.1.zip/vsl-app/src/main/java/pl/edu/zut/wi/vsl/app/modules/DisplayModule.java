/*
 *    Virtual Steganographic Laboratory (VSL)
 *    Copyright (C) 2008-2011  M. Wegrzyn <bend-up@users.sourceforge.net>

 *    This file is part of Virtual Steganographic Laboratory (VSL).

 *    VSL is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.

 *    VSL is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.

 *    You should have received a copy of the GNU General Public License
 *    along with VSL.  If not, see <http://www.gnu.org/licenses/>.
 */
package pl.edu.zut.wi.vsl.app.modules;

import java.io.Serializable;
import java.util.ArrayList;
import pl.edu.zut.wi.vsl.app.VslException;
import pl.edu.zut.wi.vsl.commons.StegoImage;
import pl.edu.zut.wi.vsl.commons.StegoPackage;

/**
 * Module for Display utilities.
 *
 * @author Michal Wegrzyn
 */
public class DisplayModule extends VslModule implements Serializable {

    /** For serialization. */
    private static final long serialVersionUID = 8930667929859212340L;
    private static final String DESC = "Displays images captured during "
            + "experiment";
    /** List of images for displayed by the module */
    private transient ArrayList<StegoImage> images;

    public DisplayModule() {
        super("Display", DESC, ModuleType.Display);
        images = new ArrayList<StegoImage>();
    }

    public DisplayModule(DisplayModule v) {
        super(v);
        
        images = new ArrayList<StegoImage>();
        if (v.getImages() == null) {
            images.addAll(v.getImages());
        }
    }

    /**
     * Gets <code>ArrayList</code> with images for this module.
     * @return set of images for display module
     * @see #resetImages()
     */
    public ArrayList<StegoImage> getImages() {
        return images;
    }

    /**
     * Resets images contained by Display Module.
     */
    public void resetImages() {
        images = new ArrayList<StegoImage>();
    }

    @Override
    public StegoPackage execute(StegoPackage cp) throws VslException {
        images.add(new StegoImage(cp.getImage()));

        return cp;
    }

    @Override
    public void cleanUpModule() {
        resetImages();
    }
    
}
