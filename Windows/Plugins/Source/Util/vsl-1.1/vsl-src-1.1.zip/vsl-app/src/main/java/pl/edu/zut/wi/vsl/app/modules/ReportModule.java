/*
 *    Virtual Steganographic Laboratory (VSL)
 *    Copyright (C) 2008-2011  M. Wegrzyn <bend-up@users.sourceforge.net>

 *    This file is part of Virtual Steganographic Laboratory (VSL).

 *    VSL is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.

 *    VSL is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.

 *    You should have received a copy of the GNU General Public License
 *    along with VSL.  If not, see <http://www.gnu.org/licenses/>.
 */
package pl.edu.zut.wi.vsl.app.modules;

import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import pl.edu.zut.wi.vsl.app.Main;
import pl.edu.zut.wi.vsl.app.VslException;
import pl.edu.zut.wi.vsl.app.gui.panels.ReportPanel;
import pl.edu.zut.wi.vsl.app.utils.FileUtil;
import pl.edu.zut.wi.vsl.app.utils.VslUtil;
import pl.edu.zut.wi.vsl.commons.Benchmark;
import pl.edu.zut.wi.vsl.commons.StegoImage;
import pl.edu.zut.wi.vsl.commons.StegoPackage;

/**
 * Module for report utilities.
 *
 * @author Michal Wegrzyn
 */
public class ReportModule extends VslModule implements Serializable {

    /** For serialization. */
    private static final long serialVersionUID = -5534537674390551052L;
    private static final String DESC = "Creates reports in flow";
    /** Output directory */
    private File outputDirectory;
    /** Output subdirectory */
    private String outputSubdirectory;
    /** Pattern for output results */
    private String outputNamePattern;
    /** Number of saved files so far */
    private int savedCounter;
    /** Array with Report variables */
    private boolean[] reportVariables;
    /** Content of the report */
    private ArrayList<String[]> reportContent;

    public ReportModule() {
        super("Report", DESC, ModuleType.Report);

        outputDirectory = new File(FileUtil.getOutputDirectory());
        outputNamePattern = Main.getProperty("vsl.report.filename",
                                                            "report");
        boolean reportAll = VslUtil.toBoolean(Main.getProperty(
                "vsl.report.all", "false"));
        boolean iteration = VslUtil.toBoolean(Main.getProperty(
                "vsl.report.include.numberOfIteration", "true"));
        boolean input = VslUtil.toBoolean(Main.getProperty(
                "vsl.report.include.numberOfInput", "true"));
        boolean mIn = VslUtil.toBoolean(Main.getProperty(
                "vsl.report.include.moduleIn", "true"));
        boolean mOut = VslUtil.toBoolean(Main.getProperty(
                "vsl.report.include.moduleOut", "true"));
        boolean filename = VslUtil.toBoolean(Main.getProperty(
                "vsl.report.include.imageFilename", "true"));
        boolean size = VslUtil.toBoolean(Main.getProperty(
                "vsl.report.include.imageSize", "true"));
        boolean msgSize = VslUtil.toBoolean(Main.getProperty(
                "vsl.report.include.messageSize", "true"));
        boolean psnr = VslUtil.toBoolean(Main.getProperty(
                "vsl.report.include.psnr", "true"));
        boolean rpsnr = VslUtil.toBoolean(Main.getProperty(
                "vsl.report.include.rpsnr", "false"));
        boolean analysisResult = VslUtil.toBoolean(Main.getProperty(
                "vsl.report.include.analysisResult", "true"));

        boolean[] rv = {reportAll, iteration, input, mIn, mOut,
                        filename, size, msgSize, psnr, rpsnr,
                        analysisResult};
        reportVariables = rv;
        reportContent = new ArrayList<String[]>();
    }

    public ReportModule(ReportModule v) {
        super(v);

        if (v.getOutputDirectory() != null) {
            outputDirectory = new File(
                            v.getOutputDirectory().getAbsolutePath());
        }
        if (v.getOutputSubdirectory() != null) {
            outputSubdirectory = v.getOutputSubdirectory();
        }
        if (v.getOutputPattern() != null) {
            outputNamePattern = v.getOutputPattern();
        }
        reportVariables = v.getReportVariables();
        if (reportContent == null) {
            reportContent = new ArrayList<String[]>();
        }
        if (v.getReportContent() != null &&
                                    !v.getReportContent().isEmpty()) {
            reportContent.addAll(v.getReportContent());
        }
    }

    /**
     * Returns report variables indicating which items should be
     * reported with report.
     * @return
     */
    public boolean[] getReportVariables() {
        return (boolean []) reportVariables.clone();
    }

    /**
     * Sets report variables indicating which items should be
     * reported with report.
     * @param rv new values of report flags.
     */
    public void setReportVariables(boolean[] rv) {
        reportVariables = (boolean []) rv.clone();
    }

    /**
     * Returns content of the report.
     * @return ArrayList with lines of the report.
     */
    public ArrayList<String[]> getReportContent() {
        return reportContent;
    }

    /**
     * Add to the content of this module's report a report line.
     * @param line Line which should be added to the report created by this
     * module.
     */
    public void addReportLine(String[] line) {
        reportContent.add(line);
    }

    /**
     * Resets content of report. Used to prepare module to next set of
     * iterations.
     */
    public void resetReportContent() {
        reportContent = new ArrayList<String[]>();
    }

    /**
     * Returns pattern for output files. 
     * @return Pattern used by this module while saving files.
     * @see #outputNamePattern
     * @see #execute(pl.edu.zut.wi.vsl.commons.StegoPackage)
     */
    public String getOutputPattern() {
        return outputNamePattern;
    }

    /**
     * Sets pattern for output files.
     * @param pattern Pattern used by this module while saving files.
     * @see #outputNamePattern
     * @see #execute(pl.edu.zut.wi.vsl.commons.StegoPackage)
     */
    public void setOutputPattern(String pattern) {
        outputNamePattern = pattern;
    }

    /**
     * Gets path to main output directory in which output files will be saved.
     * @return filepath to current experiment output directory.
     * @see #getOutputSubdirectory()
     */
    public File getOutputDirectory() {
        return outputDirectory;
    }

    /**
     * Sets path to main output directory in which output files will be saved.
     * @param dir filepath to current experiment output directory.
     * @see #setOutputSubdirectory()
     */
    public void setOutputDirectory(File dir) {
        outputDirectory = dir;
    }

    /**
     * Gets path to output subdirectory in which output files will be saved.
     * @return filepath to one of the Input modules output subdirectory
     * @see #getOutputDirectory()
     */
    public String getOutputSubdirectory() {
        return outputSubdirectory;
    }

    /**
     * Sets path to output subdirectory in which output files will be saved.
     * @param dir filepath to one of the Input modules output subdirectory
     * @see #setOutputDirectory()
     */
    public void setOutputSubdirectory(String dir) {
        outputSubdirectory = dir;
    }

    /**
     * Returns number of saved files by this module so far.
     * @return amount of saved output files
     */
    public int getSavedCounter() {
        return savedCounter;
    }

    /**
     * Sets number of saved files by this module.
     * @param cnt amount of saved output files
     */
    public void setSavedCounter(int cnt) {
        savedCounter = cnt;
    }

    @Override
    public StegoPackage execute(StegoPackage cp) throws VslException {

        outputSubdirectory = cp.getOutputSubdirectory();
        
        try {
            File outputDir = new File(outputDirectory.getAbsolutePath()
                                    + File.separator
                                    + outputSubdirectory);

            FileUtil.writeReport(reportContent,
                                        outputDir,
                                        outputNamePattern,
                                        getSavedCounter());
            savedCounter++;
            reportContent = new ArrayList<String[]>();
        } catch (IOException e) {
            throw new VslException("", e);
        }

        return cp;
    }

    @Override
    public void cleanUpModule() {
        setSavedCounter(0);
        resetReportContent();
    }

    public void report(StegoPackage pp, StegoPackage cp, VslModule previous, 
            VslModule processed, int iteration, int threadNumber) {

        boolean[] rv = getReportVariables();
        
        /* if this report reports all executions
         * or if it will be next executed module the perform report */
        if (rv[ReportPanel.REPORT_ALL_ID] == true ||
                (processed.hasNextModule() &&
                processed.getNextModule(false).equals(this))) {
            ArrayList<String> line = new ArrayList<String>();
            if (rv[ReportPanel.ITERATION_ID]) {
                line.add(String.valueOf(iteration));
            }
            if (rv[ReportPanel.INPUT_ID]) {
                line.add(String.valueOf(threadNumber));
            }
            if (rv[ReportPanel.IN_ID]) {
                line.add(previous.getName());
            }
            if (rv[ReportPanel.OUT_ID]) {
                line.add(processed.getName());
            }
            if (rv[ReportPanel.FILENAME_ID]) {
                line.add(cp.getImage().getPath());
            }
            if (rv[ReportPanel.SIZE_ID]) {
                if (cp.getImage() == null) {
                    line.add("no image");
                } else {
                    line.add(cp.getImage().getWidth() +
                            "x" +
                            cp.getImage().getHeight());
                }
            }
            if (rv[ReportPanel.PSNR_ID]) {
                StegoImage im1 = pp.getImage();
                StegoImage im2 = cp.getImage();
                if (im1 != null && im2 != null) {
                    if (im1.getWidth() == im2.getWidth() &&
                            im1.getHeight() == im2.getHeight()) {
                        line.add(String.valueOf(
                                Benchmark.calculatePSNR(im1, im2)));
                    } else {
                        line.add("different size");
                    }
                } else {
                    line.add("lack of image(s)");
                }

            }
            if (rv[ReportPanel.RPSNR]) {
                StegoImage im1 = pp.getImage();
                StegoImage im2 = cp.getImage();
                if (im1 != null && im2 != null) {
                    if (im1.getWidth() == im2.getWidth() &&
                            im1.getHeight() == im2.getHeight()) {
                        line.add(String.valueOf(
                                Benchmark.calculateRPSNR(im1, im2)));
                    } else {
                        line.add("different size");
                    }
                } else {
                    line.add("lack of image(s)");
                }
            }
            if (rv[ReportPanel.ANALYSIS_ID]) {
                if (cp.getInfo() != null) {
                    line.add(cp.getInfo());
                } else {
                    line.add("no results");
                }
            }
            if (rv[ReportPanel.MSG_SIZE_ID]) {
                if (cp.getMessage() != null) {
                    line.add(String.valueOf(cp.getMessage().getSize()));
                } else {
                    line.add("no message");
                }
            }

            String[] reportLine =
                    line.toArray(new String[line.size()]);
            addReportLine(reportLine);
        }
    }


}

