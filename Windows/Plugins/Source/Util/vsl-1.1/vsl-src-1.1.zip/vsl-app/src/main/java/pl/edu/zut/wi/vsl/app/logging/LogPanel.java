/*
 *    Virtual Steganographic Laboratory (VSL)
 *    Copyright (C) 2008-2011  M. Wegrzyn <bend-up@users.sourceforge.net>

 *    This file is part of Virtual Steganographic Laboratory (VSL).

 *    VSL is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.

 *    VSL is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.

 *    You should have received a copy of the GNU General Public License
 *    along with VSL.  If not, see <http://www.gnu.org/licenses/>.
 */
package pl.edu.zut.wi.vsl.app.logging;

import java.awt.BorderLayout;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JTextArea;
import javax.swing.JViewport;
import javax.swing.KeyStroke;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import org.apache.log4j.Logger;
import pl.edu.zut.wi.vsl.app.MainWindow;
import pl.edu.zut.wi.vsl.app.utils.VslUtil;

/**
 * Class used to showing internal log in separate window and main toolbar.
 * 
 * @author Michal Wegrzyn
 */
public class LogPanel extends JPanel implements InternalLogger, TaskLogger {

    /** Displays the current status */
    protected transient JLabel statusLabel = new JLabel("OK");
    /** Displays the log messages */
    protected transient JTextArea logTextArea = new JTextArea(4, 20);
    /** The button for viewing the log */
    protected JButton logButton = new JButton();
    private final static Logger logger = Logger.getLogger(LogPanel.class);
    /** For serialization */
    private static final long serialVersionUID = -4072464549112439484L;
    /** Frame with log text */
    private final JFrame jf = new JFrame("VSL - Log");
    private final static String CLEAR_LOG = "VSL - clear log";
    private final static String SAVE_TITLE = "VSL - save log...";
    private final static String REPLACE_TITLE = "VSL - replace file";
    /* Jf's items */
    private final JMenu fileMenu;
    private final JMenuBar menuBar;
    private final JMenuItem saveMenuItem;
    private final JMenuItem closeMenuItem;
    private final JSeparator jSeparator1;
    private final JMenuItem clearMenuItem;

    /**
     * Creates the log panel, where the log is hidden.
     */
    public LogPanel() {

        logTextArea.setEditable(false);
        statusLabel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createTitledBorder("Status"),
                BorderFactory.createEmptyBorder(0, 5, 0, 5)));
        logTextArea.append("--- VSL Log ---");
        // create scrolling log
        final JScrollPane js = new JScrollPane(logTextArea);
        js.getViewport().addChangeListener(new ChangeListener() {

            private int lastHeight;

            public void stateChanged(ChangeEvent e) {
                JViewport vp = (JViewport) e.getSource();
                int h = vp.getViewSize().height;
                if (h != lastHeight) {
                    // i.e. an addition not just a user scrolling
                    lastHeight = h;
                    int x = h - vp.getExtentSize().height;
                    vp.setViewPosition(new Point(0, x));
                }
            }
        });
        js.getVerticalScrollBar().setUnitIncrement(
                MainWindow.getDefaultScrollIncrement());
        menuBar = new javax.swing.JMenuBar();
        fileMenu = new javax.swing.JMenu();
        clearMenuItem = new javax.swing.JMenuItem();
        saveMenuItem = new javax.swing.JMenuItem();
        jSeparator1 = new javax.swing.JSeparator();
        closeMenuItem = new javax.swing.JMenuItem();
        fileMenu.setText("File");
        fileMenu.setMnemonic(KeyEvent.VK_F);

        clearMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(
                java.awt.event.KeyEvent.VK_R, 
                java.awt.event.InputEvent.CTRL_MASK));
        clearMenuItem.setText("Clear");
        clearMenuItem.setMnemonic(KeyEvent.VK_R);
        clearMenuItem.addActionListener(new java.awt.event.ActionListener() {

            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearMenuItemActionPerformed(evt);
            }
        });
        fileMenu.add(clearMenuItem);

        saveMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(
                java.awt.event.KeyEvent.VK_S, 
                java.awt.event.InputEvent.CTRL_MASK));
        saveMenuItem.setText("Save As...");
        saveMenuItem.setMnemonic(KeyEvent.VK_S);
        saveMenuItem.addActionListener(new java.awt.event.ActionListener() {

            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveLog();
            }
        });
        fileMenu.add(saveMenuItem);
        fileMenu.add(jSeparator1);

        closeMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(
                java.awt.event.KeyEvent.VK_W, 
                java.awt.event.InputEvent.CTRL_MASK));
        closeMenuItem.setText("Close");
        closeMenuItem.setMnemonic(KeyEvent.VK_L);
        closeMenuItem.addActionListener(new java.awt.event.ActionListener() {

            public void actionPerformed(java.awt.event.ActionEvent evt) {
                closeWindow();
            }
        });
        fileMenu.add(closeMenuItem);

        menuBar.add(fileMenu);

        jf.setJMenuBar(menuBar);

        // create log window
        jf.addWindowListener(new WindowAdapter() {

            @Override
            public void windowClosing(WindowEvent e) {
                closeWindow();
            }
        });
        KeyStroke escapeKeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE,
                0, false);
        Action escapeAction = new AbstractAction() {
            // close the frame when the user presses escape
            public void actionPerformed(ActionEvent e) {
                closeWindow();
            }
        };
        jf.getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(
                escapeKeyStroke, "ESCAPE");
        jf.getRootPane().getActionMap().put("ESCAPE", escapeAction);
        jf.setIconImage(VslUtil.LOGO_ICON.getImage());
        jf.getContentPane().setLayout(new BorderLayout());
        jf.getContentPane().add(js, BorderLayout.CENTER);
        jf.pack();
        jf.setSize(450, 350);
        jf.setLocationRelativeTo(getParent());

        // do layout
        setLayout(new BorderLayout());
        JPanel p1 = new JPanel();
        p1.setLayout(new BorderLayout());
        p1.add(statusLabel, BorderLayout.CENTER);
        add(p1, BorderLayout.SOUTH);
        addPopup();
    }

    /**
     * Initializes text log.
     */
    public void startLog() {
        String date = 
                new SimpleDateFormat("EEEE, d MMMM yyyy", 
                Locale.getDefault()).format(new Date());
        logMessage("Virtual Steganographic Laboratory");
        logMessage(date);
    }

    /**
     * Record the starting of a new task
     */
    public void taskStarted() {
        log("Starting experiment");
    }

    /**
     * Record a task ending
     */
    public void taskFinished() {
        log("Experiment finished");
    }

    /**
     * Sends the supplied message to the log area. The current timestamp will
     * be prepended.
     * @param message a value of type 'String'
     */
    public synchronized void logMessage(String message) {
        logTextArea.append("\n");
        logTextArea.append(LogPanel.getTimestamp() + ' ' + message);
    }

    private synchronized String getLogMessage() {
        return logTextArea.getText();
    }
    
    private synchronized void clearLogMessage() {
        logTextArea.setText("");
        logTextArea.append("--- VSL Log ---");
    }
    
    /**
     * Sends the supplied message to the status line.
     * @param message the status message
     */
    public synchronized void statusMessage(String message) {
        statusLabel.setText(message);
    }

    /**
     * Sends the supplied message to the log area and to the status line.
     * @param message to send
     */
    public synchronized void log(String message) {
        logMessage(message);
        statusMessage(message);
    }

    /**
     * Handles saving internal log to a file.
     */
    public void saveLog() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
        fileChooser.setDialogTitle(SAVE_TITLE);
        fileChooser.setFileHidingEnabled(false);
        fileChooser.setMultiSelectionEnabled(false);
        int returnValue = fileChooser.showSaveDialog(getTopLevelAncestor());
        if (returnValue == JFileChooser.APPROVE_OPTION) {
            File f = fileChooser.getSelectedFile();
            if (f.exists()) {
                int decision = JOptionPane.showConfirmDialog(jf,
                        "Do you want to  replace existing file?",
                        REPLACE_TITLE, JOptionPane.YES_NO_OPTION,
                        JOptionPane.QUESTION_MESSAGE, VslUtil.QUESTION_ICON);
                if (decision == JOptionPane.NO_OPTION) {
                    return;
                }
            }
            
            Writer writer = null;
            try {
                writer = new OutputStreamWriter(new FileOutputStream(f));
                writer.write(getLogMessage());
            } catch (Exception e) {
                String msg = "Error occured during writing to file.";
                logger.error(msg, e);
                VslUtil.showError(jf, msg, e);
            } finally {
                try {
                    writer.close();
                } catch (IOException e) {
                    String msg = "Error occured during closing writer stream.";
                    logger.error(msg, e);
                    VslUtil.showError(jf, msg, e);
                }
            }
        }
    }

    /**
     * Shows logger window.
     */
    public void showWindow() {
        jf.setVisible(true);
    }
    
    /**
     * Gets a string containing current date and time.
     * @return a string containing the date and time.
     */
    protected static String getTimestamp() {
        return new SimpleDateFormat("HH:mm:ss:", 
                Locale.getDefault()).format(new Date());
    }    

    /**
     * Adds thousand's-separators to the number
     * @param l       the number to print
     * @return        the number as string with separators
     */
    private String printLong(final long l) {
        String result = "";
        String str;
        int count = 0;

        str = Long.toString(l);


        
        for (int i = str.length() - 1; i >= 0; i--) {
            count++;
            result = str.charAt(i) + result;
            if ((count == 3) && (i > 0)) {
                result = "," + result;
                count = 0;
            }
        }

        return result;
    }

    private void closeWindow() {
        jf.setVisible(false);
    }

    private void clearMenuItemActionPerformed(ActionEvent evt) {
        clearLog();
    }

    private void clearLog() {
        int decision = JOptionPane.showConfirmDialog(jf,
                "Do you really want to clear log?",
                CLEAR_LOG, JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE, VslUtil.QUESTION_ICON);
        if (decision == JOptionPane.YES_OPTION) {
            clearLogMessage();
            startLog();
        }
    }

    /**
     * Add a popup menu for displaying the amount of free memory
     * and running the garbage collector
     */
    private void addPopup() {
        addMouseListener(new MouseAdapter() {

            @Override
            public void mouseClicked(MouseEvent e) {
                if (((e.getModifiers() & 
                        InputEvent.BUTTON1_MASK) != InputEvent.BUTTON1_MASK) || 
                                                                e.isAltDown()) {
                    JPopupMenu gcMenu = new JPopupMenu();
                    JMenuItem availMem = new JMenuItem("Memory information");
                    availMem.addActionListener(new ActionListener() {

                        public void actionPerformed(ActionEvent ee) {
                            System.gc();
                            Runtime currR = Runtime.getRuntime();
                            long freeM = currR.freeMemory();
                            long totalM = currR.totalMemory();
                            long maxM = currR.maxMemory();
                            String msg = "Memory (free/total/max.) in bytes: " +
                                    printLong(freeM) + " / " + 
                                    printLong(totalM) + " / " + 
                                    printLong(maxM);
                            logMessage(msg);
                            statusMessage(msg);
                        }
                    });
                    gcMenu.add(availMem);
                    JMenuItem runGC = new JMenuItem("Run garbage collector");
                    runGC.addActionListener(new ActionListener() {

                        public void actionPerformed(ActionEvent ee) {
                            statusMessage("Running garbage collector");
                            System.gc();
                            statusMessage("OK");
                        }
                    });
                    gcMenu.add(runGC);
                    gcMenu.show(LogPanel.this, e.getX(), e.getY());
                }
            }
        });
    }    
}