/*
 *    Virtual Steganographic Laboratory (VSL)
 *    Copyright (C) 2008-2011  M. Wegrzyn <bend-up@users.sourceforge.net>

 *    This file is part of Virtual Steganographic Laboratory (VSL).

 *    VSL is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.

 *    VSL is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.

 *    You should have received a copy of the GNU General Public License
 *    along with VSL.  If not, see <http://www.gnu.org/licenses/>.
 */
package pl.edu.zut.wi.vsl.app.gui;

import pl.edu.zut.wi.vsl.app.modules.VslModule;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.io.IOException;
import javax.swing.tree.DefaultMutableTreeNode;
import org.apache.log4j.Logger;
import pl.edu.zut.wi.vsl.app.utils.VslUtil;

/**
 * Class used for transferring <code>VslModule</code> items between
 * modules list and <code>Desktop</code>
 * 
 * @author Michal Wegrzyn
 */
public class TransferableTreeNode extends DefaultMutableTreeNode 
                                            implements Transferable {

    private static final Logger logger = Logger.getLogger(
                                                TransferableTreeNode.class);
    /** Transfered item */
    private VslModule item;

    /**
     * Creates transferable node for a given item.
     * @param v <code>VslModule</code> instance which this object
     * should transfer.
     */
    public TransferableTreeNode(VslModule v) {
        item = v;
    }

    /**
     * Returns an array of DataFlavor objects indicating the flavors the data 
     * can be provided in.
     * @return an array of data flavors in which this data can be transferred
     */
    public DataFlavor[] getTransferDataFlavors() {
        DataFlavor[] flavors = new DataFlavor[1];
        Class type = item.getClass();
        String mimeType = "application/x-java-jvm-local-objectref;class= " +
                                                                type.getName();
        try {
            flavors[0] = new DataFlavor(mimeType);
            return flavors;
        } catch (ClassNotFoundException e) {
            String msg = "Mimetype `" + mimeType + " was not found";
            logger.error(msg);
            VslUtil.showError(null, msg, e);
            return new DataFlavor[0];
        }
    }

    /**
     * Returns information about this object that will be displayed
     * in application.
     * @return Tooltip text of contained module.
     */
    public String getToolTipText() {
        return item.getDescription();
    }
    
    /**
     * Returns whether or not the specified data flavor is supported for
     * this object.
     * @param flavor the requested flavor for the data
     * @return boolean indicating whether or not the data flavor is supported
     */
    public boolean isDataFlavorSupported(DataFlavor flavor) {
        return "application".equals(flavor.getPrimaryType()) 
                    && "x-java-jvm-local-objectref".equals(flavor.getSubType()) 
                    && flavor.getRepresentationClass().isAssignableFrom(
                                                            item.getClass());
    }

    /**
     * Returns an object which represents the data to be transferred.  
     * The class of the object returned is defined by the representation
     * class of the flavor.
     *
     * @param flavor the requested flavor for the data
     * @see DataFlavor#getRepresentationClass
     * @exception IOException                if the data is no longer available
     *              in the requested flavor.
     * @exception UnsupportedFlavorException if the requested data flavor is
     *              not supported.
     */
    public Object getTransferData(DataFlavor flavor) 
                            throws UnsupportedFlavorException, IOException {
        if (!isDataFlavorSupported(flavor)) {
            throw new UnsupportedFlavorException(flavor);
        }
        return item;
    }
    
    @Override
    public String toString() {
        return item.toString();
    }    
}
