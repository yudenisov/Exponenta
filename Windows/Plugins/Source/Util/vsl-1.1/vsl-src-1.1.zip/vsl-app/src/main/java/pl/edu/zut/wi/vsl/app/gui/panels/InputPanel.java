/*
 *    Virtual Steganographic Laboratory (VSL)
 *    Copyright (C) 2008-2011  M. Wegrzyn <bend-up@users.sourceforge.net>

 *    This file is part of Virtual Steganographic Laboratory (VSL).

 *    VSL is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.

 *    VSL is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.

 *    You should have received a copy of the GNU General Public License
 *    along with VSL.  If not, see <http://www.gnu.org/licenses/>.
 */
package pl.edu.zut.wi.vsl.app.gui.panels;

import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.io.File;
import java.util.ArrayList;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.DefaultListModel;
import javax.swing.JComponent;
import javax.swing.JFileChooser;
import javax.swing.KeyStroke;
import org.apache.log4j.Logger;
import pl.edu.zut.wi.vsl.app.utils.FileUtil;
import pl.edu.zut.wi.vsl.app.utils.VslUtil;

/**
 * Panel for specifying cover objects (input image(s)).
 * 
 * @author Michal Wegrzyn
 */
public class InputPanel extends javax.swing.JPanel {

    /** Title for <code>JFileChooser</code> opened during 
     * choosing input images */
    public static final String PREFERRED_TITLE = "VSL - choose input " +
                                                        "file or directory";
    private final static Logger logger = Logger.getLogger(InputPanel.class);
    /** List model controlling behaviour of the list of the selected files */
    private DefaultListModel listModel;
    /** ArrayList of files currently choosen */
    private ArrayList<File> files;

    /**
     * Creates new form InputPanel.
     * @param fileList - files that will be added to list 
     * or null if list should be blank.
     */
    public InputPanel(ArrayList<File> fileList) {
        files = new ArrayList<File>();
        if (fileList != null && !fileList.isEmpty()) {
            files.addAll(fileList);
            addToFileList(fileList);
        }
        initComponents();
        KeyStroke deleteKeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_DELETE, 
                                                                    0, false);
        Action deleteAction = new AbstractAction() {
            //delete removes selected files
            public void actionPerformed(ActionEvent e) {
                removeSelected();
            }
        };
        getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(deleteKeyStroke, 
                                                                    "DELETE");
        getActionMap().put("DELETE", deleteAction);
        KeyStroke addKeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_INSERT, 
                                                                    0, false);
        Action addAction = new AbstractAction() {
            //insert opens file chooser
            public void actionPerformed(ActionEvent e) {
                addFiles();
            }
        };
        getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(addKeyStroke, 
                                                                    "INSERT");
        getActionMap().put("INSERT", addAction);
    }

    /**
     * Adds given files to the imageList.
     * @param files - files that should be added
     */
    private void addToFileList(ArrayList<File> files) {
        if (listModel == null) {
            listModel = new DefaultListModel();
        }
        for (File f : files) {
            listModel.addElement(f.getAbsolutePath());
        }
        if (imageList != null) {
            imageList.setModel(listModel);
        }
    }

    /**
     * Getter for set list of image files.
     * @return ArrayList - list of input image files set by user.
     */
    public ArrayList<File> getFiles() {
        return files;
    }

    /**
     * Handles adding new files to list.
     */
    private void addFiles() {
        try {
            JFileChooser fileChooser = new JFileChooser();
            fileChooser.setFileSelectionMode(
                                            JFileChooser.FILES_AND_DIRECTORIES);
            fileChooser.setDialogTitle(PREFERRED_TITLE);
            fileChooser.setFileHidingEnabled(false);
            fileChooser.setMultiSelectionEnabled(true);
            int returnValue = fileChooser.showDialog(getTopLevelAncestor(), 
                                                                    "Select");
            if (returnValue == JFileChooser.APPROVE_OPTION) {
                File[] fileList = fileChooser.getSelectedFiles();

                ArrayList<File> res = new ArrayList<File>();
                for (File f : fileList) {
                    if (f.isDirectory()) {
                        res.addAll(FileUtil.listOfImageFiles(f, true));
                    } else if (FileUtil.checkIsFormatHandled(f.getName())) {
                        res.add(f);
                    }
                }
                if (res.isEmpty()) {
                    String msg = "Could not find any image " +
                                            "in specified location.";
                    logger.warn(msg);
                    VslUtil.showWarn(getTopLevelAncestor(), msg);
                } else {
                    files.addAll(res);
                    logger.info("Added " + res.size() + " files to list");
                    addToFileList(res);
                }
            }
        } catch (Exception e) {
            String msg = "Error occured while adding file(s) to list.";
            logger.error(msg, e);
            VslUtil.showError(getTopLevelAncestor(), msg, e);
        } catch (OutOfMemoryError e) {
            String msg = VslUtil.OUT_OF_MEMORY_MSG;
            logger.error(msg, e);
            VslUtil.showError(getTopLevelAncestor(), "Out of memory. " +
                    "Please try to start VSL with -Xmx switch.", e);
        }
    }

    /**
     * Removes selected by user files from list.
     */
    public void removeSelected() {
        if (listModel != null) {
            int[] toRemove = imageList.getSelectedIndices();
            if (toRemove.length > 0) {
                listModel.removeRange(toRemove[0], toRemove[toRemove.length-1]);
                for (int i = toRemove.length - 1; i >= 0; i--) {
                    files.remove(toRemove[i]);
                }
                logger.info("Removed " + toRemove.length + " files from list.");
            }
        }
    }

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        addButton = new javax.swing.JButton();
        listScrollPane = new javax.swing.JScrollPane();
        if (listModel != null) {
            imageList = new javax.swing.JList(listModel);
        } else {
            imageList = new javax.swing.JList();
        }
        removeButton = new javax.swing.JButton();

        addButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pl/edu/zut/wi/vsl/app/gui/icons/list-add16x16.png"))); // NOI18N
        addButton.setToolTipText("Choose file or directory with images to add to input list (Ins)");
        addButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addButtonActionPerformed(evt);
            }
        });

        imageList.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_INTERVAL_SELECTION);
        imageList.setToolTipText("List of image files which will be used as cover objects for hidden message");
        listScrollPane.setViewportView(imageList);

        removeButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pl/edu/zut/wi/vsl/app/gui/icons/list-remove16x16.png"))); // NOI18N
        removeButton.setToolTipText("Removes selected files from input list (Del)");
        removeButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                removeButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(listScrollPane, javax.swing.GroupLayout.DEFAULT_SIZE, 498, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(addButton)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(removeButton)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(listScrollPane, javax.swing.GroupLayout.DEFAULT_SIZE, 192, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(removeButton)
                    .addComponent(addButton))
                .addContainerGap())
        );
    }// </editor-fold>//GEN-END:initComponents

private void addButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addButtonActionPerformed
    addFiles();
}//GEN-LAST:event_addButtonActionPerformed

private void removeButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_removeButtonActionPerformed
    removeSelected();
}//GEN-LAST:event_removeButtonActionPerformed
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addButton;
    private javax.swing.JList imageList;
    private javax.swing.JScrollPane listScrollPane;
    private javax.swing.JButton removeButton;
    // End of variables declaration//GEN-END:variables
}
