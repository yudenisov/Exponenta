/*
 *    Virtual Steganographic Laboratory (VSL)
 *    Copyright (C) 2008-2011  M. Wegrzyn <bend-up@users.sourceforge.net>

 *    This file is part of Virtual Steganographic Laboratory (VSL).

 *    VSL is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.

 *    VSL is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.

 *    You should have received a copy of the GNU General Public License
 *    along with VSL.  If not, see <http://www.gnu.org/licenses/>.
 */
package pl.edu.zut.wi.vsl.app.modules;

import java.io.Serializable;
import java.util.LinkedHashMap;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import pl.edu.zut.wi.vsl.app.VslException;
import pl.edu.zut.wi.vsl.commons.StegoPackage;

/**
 * Class handling logic of every module. 
 * 
 * @see pl.edu.zut.wi.vsl.client.gui.DeskItem
 * @author Michal Wegrzyn
 */
public abstract class VslModule implements Module, Serializable {

    /** Enumeration with representations of <code>VslModule</code> types */
    public static enum ModuleType {
        SteganographicEncoder,
        SteganographicDecoder,
        Steganalytic,
        Input,
        Output,
        Report,
        Display,
        Distortion,
        Other
    }

    /** Connection between this <code>VslModule</code> and
     * <code>VslModule</code> placed in flow before this <code>VslModule</code>.
     */
    protected ModuleConnection in;
    /** Connection between this <code>VslModule</code> and
     * <code>VslModule</code> placed in flow after this <code>VslModule</code>.
     */
    protected ModuleConnection out;
    /** Loop connection between this <code>VslModule</code> and
     * <code>VslModule</code> placed in flow after this <code>VslModule</code>.
     * <p>Loop connection is type of connection that connects module A
     * with another one module B which is already in flow before module A.
     */
    protected ModuleConnection loopIn;
    /** Loop connection between this <code>VslModule</code> and
     * <code>VslModule</code> placed in flow before this <code>VslModule</code>.
     * <p>Loop connection is type of connection that connects module A
     * with another one module B which is already in flow before module A.
     */
    protected ModuleConnection loopOut;
    /** Type of module */
    protected ModuleType type;
    /** For serialization */
    private static final long serialVersionUID = -4997850719830315486L;
    private final static Logger logger = Logger.getLogger(VslModule.class);
    /** Name of this <code>VslModule</code> */
    private String moduleName;
    /** Description of this <code>VslModule</code> */
    private String description;
    /** Class needed to execute this module's operations */
    private String moduleClass;
    /** Parameters of this module along with current values */
    private ArrayList<ArrayList<ModuleParameter>> parameters;      

    /**
     * Hide default constructor.
     */
    private VslModule() {
    }

    /**
     * Constructs new <code>VslModule</code> with given parameters.
     * <p>There are no arguments for parameters and its descriptions
     * because not every module has parameters.
     * @param name Displayed text by <code>DeskItem</code> representing
     * this <code>VslModule</code>
     * @param desc Description of this module, showed with tool tip.
     * @param mtype ModuleType for this module.
     * @see #setParameters(java.util.ArrayList)
     * @see #setDefaultParameters(java.util.LinkedHashMap)
     * @see #setParamsDescriptions(java.util.LinkedHashMap)
     * @see pl.edu.zut.wi.vsl.app.modules.VslModule.ModuleType
     */
    public VslModule(String name, String desc, ModuleType mtype) {
        this(name, desc, null, mtype);
    }

    /**
     * Constructs new <code>VslModule</code> with given parameters.
     * <p>There are no arguments for parameters and its descriptions
     * because not every module has parameters.
     * @param name Displayed text by <code>DeskItem</code> representing 
     * this <code>VslModule</code>
     * @param desc Description of this module, showed with tool tip.
     * @param clazz Name of the class that performs operations described by 
     * this module.
     * @param mtype ModuleType for this module.
     * @see #setParameters(java.util.ArrayList)
     * @see #setDefaultParameters(java.util.LinkedHashMap) 
     * @see #setParamsDescriptions(java.util.LinkedHashMap) 
     * @see pl.edu.zut.wi.vsl.app.modules.VslModule.ModuleType
     */
    public VslModule(String name, String desc, String clazz, ModuleType mtype) {
        moduleName = name;
        description = desc;
        moduleClass = clazz;
        type = mtype;
    }

    /**
     * Makes this VslModule a copy of given v module.
     * @param v Module to copy
     */
    public VslModule(VslModule v) {

        moduleName = v.getName() == null ? "" : v.getName();
        description = v.getDescription() == null ? "" : v.getDescription();
        moduleClass = v.getModuleClass() == null ? "" : v.getModuleClass();
        parameters = new ArrayList<ArrayList<ModuleParameter>>();

        if (v.getParameters() != null && !v.getParameters().isEmpty()) {
            for (ArrayList<ModuleParameter> list : v.getParameters()) {
                parameters.add((ArrayList<ModuleParameter>) cloneParameterList(list));
            }
        }
        type = v.getModuleType() == null ? ModuleType.Other : v.getModuleType();
        in = v.getInput();
        out = v.getOutput();
        loopIn = v.getLoopInput();
        loopOut = v.getLoopOutput();
    }

     public VslModule deepCopy() {
         logger.trace("Copying " + getName());
         
         if (this instanceof InputModule) {
             return new InputModule((InputModule)this);
         } else if (this instanceof OutputModule) {
             return new OutputModule((OutputModule)this);
         } else if (this instanceof SteganalyticModule) {
             return new SteganalyticModule((SteganalyticModule)this);
         } else if (this instanceof EncoderModule) {
             return new EncoderModule((EncoderModule)this);
         } else if (this instanceof DecoderModule) {
             return new DecoderModule((DecoderModule)this);
         } else if (this instanceof ReportModule) {
             return new ReportModule((ReportModule)this);
         } else if (this instanceof DisplayModule) {
             return new DisplayModule((DisplayModule)this);
         } else if (this instanceof DistortionModule) {
             return new DistortionModule((DistortionModule)this);
         }

         throw new Error("Unknown type of module");
     }



    /** 
     * {@inheritDoc}
     */
    @Override
    public abstract StegoPackage execute(StegoPackage cp) throws VslException;


    /**
     * Fits number of parameters to given number of iterations.
     * <p>If module is in loop and user change number of iteration
     * or remove loop then application must change number of parameters
     * to appropriate number.
     * @param iterationsNumber Number of iteration to which 
     * number of parameters must be fit.
     */
    public void fitParameters(int iterationsNumber) {
        logger.trace("Fitting parameters for " + getName() + " to: " 
                                                + iterationsNumber);
        int diff = iterationsNumber + 1 - parameters.size();
        if (diff == 0) {
            return;
        } else if (diff > 0) {
            // too little parameters, add list(s) to ArrayList
            for (int i = 0; i < diff; i++) {
                List<ModuleParameter> n = getDefaultParameterList();
                parameters.add((ArrayList<ModuleParameter>) n);
            }
        } else {
            // too many parameters, remove excessive ones
            int size = parameters.size();
            for (int i = size - 1; i > size + diff - 1; i--) {
                parameters.remove(i);
            }
        }
    }


    
    /**
     * Resets all loop counters. Used to prepare module to next set of 
     * iterations.
     */
    public void resetLoopCounters() {
        VslModule m = this;
        if (m.isLoopOutputConnected()) {
            m.getLoopOutput().setCurrentLoopCounter(0);
        }
        while(m.hasPreviousStraightModule()) {
            m = m.getPreviousStraightModule();
            if (m.isLoopOutputConnected()) {
                m.getLoopOutput().setCurrentLoopCounter(0);
            }
        }
        m = this;
        while(m.hasNextStraightModule()) {
            m = m.getNextStraightModule();
            if (m.isLoopOutputConnected()) {
                m.getLoopOutput().setCurrentLoopCounter(0);
            }
        }
    }    

    /**
     * Gets loop source of the most inner loop in which this module is.
     * Loop source is module that has loop output connection.
     * <p>
     * If this <code>VslModule</code> is not in loop then <code>null</code>
     * is returned.
     * @return module that is the last module in loop in which this module 
     * is placed
     * @see #loopOut
     * @see pl.edu.zut.wi.vsl.app.modules.ModuleConnection#source
     */
    public VslModule getInternalLoopSource() {
        if (isLoopOutputConnected()) {
            return this;
        }
        if (isLoopInputConnected() && getLoopInput().getSource() != null) {
            return getLoopInput().getSource();
        }
        VslModule m = this;
        int i = 0;
        while (m.hasPreviousStraightModule()) {
            m = m.getPreviousStraightModule();
            if (m.isLoopInputConnected()) {
                if (i == 0) {
                    if (m.getLoopInput().getSource() != null) {
                        return m.getLoopInput().getSource();
                    }
                } else {
                    i++;
                }
            } else if (m.isLoopOutputConnected()) {
                i--;
            }
        }
        return null;
    }
    
    /**
     * Gets most outer loop source of this <code>VslModule</code>.
     * <p>
     * If this module is not in loop, <code>null</code>
     * is returned.
     * @return Module that is loop source of the most outer loop that 
     * contains this module. 
     */
    public VslModule getLoopSource() {
        
        VslModule m = this;
        while (m.hasNextStraightModule()) {
            m = m.getNextStraightModule();
        }
        
        while (m != null) {
            if (m.isLoopOutputConnected()) {
                if (m.getLoopOutput().getTarget().
                                    hasStraightForwardConnection(this)
                                    && this.hasStraightForwardConnection(m)) {
                    return m;
                }
            }
            m = m.getPreviousStraightModule();
        }
        return null;
    }    

    /**
     * Returns current loop number of the loop in which this module is placed.
     * If module is not in loop 0 is returned.
     * @return Number of passed iterations of loop in which this module is
     * placed
     * @see #loopOut
     * @see pl.edu.zut.wi.vsl.app.modules.ModuleConnection#getCurrentLoopCounter()
     */
    protected int getLoopNumber() {
        VslModule ls = getInternalLoopSource();
        if (ls != null ) {
            logger.debug("Loop source of " + getName() + ": " + ls.toString());
            return ls.getLoopOutput().getCurrentLoopCounter();
        } else {
            return 0;            
        }
    }

    /**
     * Cleans up module after execution.
     */
    public void cleanUpModule() {};
        
    /**
     * Returns next module that will be executed.
     * @param changeLoopCounter tells whether change loop counter. If we
     * only want to check next in order module this param should be false. In 
     * other case, if we are getting this module as new currently processed, 
     * this param should be true.
     * @return module that should be processed after this module.
     * @see #out
     * @see #loopOut
     * @see pl.edu.zut.wi.vsl.app.modules.ModuleConnection#getCurrentLoopCounter()
     * @see #hasNextModule() 
     */
    public VslModule getNextModule(boolean changeLoopCounter) {
        if (loopOut != null) {
            if (loopOut.getCurrentLoopCounter() < loopOut.getNumberOfLoops()) {
                if (changeLoopCounter) {
                    loopOut.setCurrentLoopCounter(loopOut.getCurrentLoopCounter() + 1);
                }
                return loopOut.getTarget();
            } else {
                if (changeLoopCounter) {
                    loopOut.setCurrentLoopCounter(0);
                }
            }
        }
        return getOutput().getTarget();
    }
    
    /**
     * Delivers connection that will be used to get next module in flow.
     * @return Module connection that connects this module with next module 
     * in flow.
     * @see pl.edu.zut.wi.vsl.app.modules.ModuleConnection#getCurrentLoopCounter()
     */
    public ModuleConnection getNextConnection() {
        if (loopOut != null) {
            if (loopOut.getCurrentLoopCounter() <= loopOut.getNumberOfLoops()) {
                return loopOut;
            }
        }
        return getOutput();
        
    }
    
    /**
     * Tests whether this <code>VslModule</code> can be connected with given
     * <code>VslModule</code>.
     * @param s <code>VslModule</code> from which user is trying to connect
     * to this module
     * @return <code>true</code> if this module can be connected to a given
     * module, otherwise <code>false</code>
     */
    public boolean canConnect(VslModule s) {

        if ((isInputConnected() || getModuleType() == ModuleType.Input)
                && isLoopInputConnected()) {
            return false;
        }
        if (s.isOutputConnected() && s.isLoopOutputConnected()) {
            return false;
        }
        if (s.isOutputConnected()) {
            if (!s.isLoopOutputConnected() && !isLoopInputConnected()) {
                /* we are doing loop connect
                 * check if module is in list of previous modules */
                 return hasStraightForwardConnection(s);                            
            } else {
                return false;
            }
        } else {
            if (isInputConnected()) {
                if (!s.isLoopOutputConnected() && !isLoopInputConnected()) {
                    /* we are doing loop connect
                     * check if module is in list of previous modules */
                    return hasStraightForwardConnection(s);
                } else {
                    return false;
                }
            } else {
                if (getModuleType() != ModuleType.Input) {
                    return !hasStraightForwardConnection(s);
                } else {
                    return hasStraightForwardConnection(s);
                }
            }
        }
    }

    /**
     * Checks if this VslModule has on its future path given module.
     * @param s module to check if exists on connection path
     * @return <code>true</code> if module is on future path, otherwise 
     * <code>false</code>
     */
    public boolean hasStraightForwardConnection(VslModule s) {
        boolean found = false;
        VslModule cur = this;
        while (cur != null) {
            if (cur.equals(s)) {
                found = true;
                break;
            } else {
                if (cur.hasNextStraightModule()) {
                    cur = cur.getNextStraightModule();
                } else {
                    cur = null;
                }
            }

        }
        return found;
    }
    
    /**
     * Checks if this module has any parameters.
     * @return <code>true</code> if this module has parameters, otherwise
     * <code>false</code>
     * @see #parameters
     */
    public boolean hasParameters() {
        if (parameters != null) {
            return !parameters.isEmpty();
        }
        return false;
    }

    /**
     * Checks if given module is in flow after this module.
     * @param s <code>VslModule</code> to check
     * @return <code>true</code> if given module is in flow with this module
     * and it is after this module, otherwse <code>false</code>.
     * @see pl.edu.zut.wi.vsl.app.modules.ModuleConnection
     */
    public boolean hasForwardConnection(VslModule s) {
        boolean found = false;
        VslModule cur = this;
        while (cur!= null) {
            if (cur.equals(s)) {
                found = true;
                break;
            } else {
                if (cur.isLoopOutputConnected()) {
                    if (cur.getLoopOutput().getTarget().equals(s)) {
                        found = true;
                        break;
                    }
                }
                if (cur.hasNextStraightModule()) {
                    cur = cur.getNextStraightModule();
                } else {
                    cur = null;
                }
            }
        }
        return found;
    }
    
    /**
     * Chcecks if this module is connected by <code>out</code> or 
     * <code>loopOut</code> with another module.
     * @return <code>true</code> is this module has output (or loop output)
     * connection with another module, otherwise <code>false</code>
     * @see #out
     * @see #loopOut
     * @see #getNextModule(boolean) 
     */
    public boolean hasNextModule() {
        if (loopOut != null) {
            logger.debug("Loop counter: " + loopOut.getCurrentLoopCounter() 
                                + ", target: "+ loopOut.getTarget().toString());
        }
        return (out != null && out.getTarget() != null) ||
                    (loopOut != null
                        && loopOut.getTarget() != null 
                        && loopOut.getCurrentLoopCounter() < 
                                                loopOut.getNumberOfLoops());
    }

    /**
     * Checks if this module has connection with module by <code>out</code>.
     * @return <code>true</code> if this module is connected with some next
     * module (and this connection is not a loop connection)
     * @see #out
     * @see #loopOut
     * @see #getNextStraightModule() n
     */
    public boolean hasNextStraightModule() {
        return out != null && out.getTarget() != null;
    }

    /**
     * Checks if this module is connected by <code>in</code> or 
     * <code>loopIn</code> with another module.
     * @return <code>true</code> is this module has input (or loop input)
     * connection with another module, otherwise <code>false</code>
     * @see #in
     * @see #loopIn 
     */
    public boolean hasPreviousModule() {
        if ((in != null && in.getSource() != null) ||
            (loopIn != null && loopIn.getSource() != null)) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Checks if this module has connection with module by <code>in</code>.
     * @return <code>true</code> if this module is connected with some previous
     * module (and this connection is not a loop connection)
     * @see #in
     * @see #loopIn
     * @see #getNextStraightModule() 
     */    
    public boolean hasPreviousStraightModule() {
        return in != null && in.getSource() != null;
    }
    
    /**
     * Checks if this module is in loop (which begins and ends at loop source).
     * @param loopSource <code>VslModule</code> which is source of loop.
     * @return <code>true</code> if this module is in loop otherwise 
     * <code>false</code>
     */
    public boolean isInLoop(VslModule loopSource) {
        if (loopSource.equals(this)) {
            return true;
        }
        VslModule current = loopSource.getLoopOutput().getTarget();
        while (!current.equals(loopSource)) {
            if (current.equals(this)) {
                return true;
            } else {
                if (current.isLoopOutputConnected()) {
                    if (current.getLoopOutput().getTarget().equals(loopSource)) {
                        //end of loop that we are checking
                        break;
                    }
                }
                current = current.getNextStraightModule();
            }
        }
        return false;
    }

    /**
     * Returns straight next module - module that is connected with
     * this module by input-output, not loopInput-loopOutput.
     * @return module that is connected with this module by output 
     * @see #hasNextStraightModule() 
     */
    public VslModule getNextStraightModule() {
        if (getOutput() != null) {
            return getOutput().getTarget();
        } else {
            return null;
        }
    }

    /**
     * Returns straight prevoius module - module that is connected with
     * this module by input-output, not loopInput-loopOutput.
     * @return module that is connected with this module by input 
     * @see #hasPreviousStraightModule() 
     */
    public VslModule getPreviousStraightModule() {
        if (getInput() != null) {
            return getInput().getSource();
        } else {
            return null;
        }
    }

    /**
     * Resets state of module's parameters (assigns default values).
     */
    public void resetParameters() {
        for (int i = 0; i < parameters.size(); i++) {
            ArrayList<ModuleParameter> params = parameters.get(i);

            for (int j = 0; j < params.size(); ++j) {
                params.get(j).reset();
            }
        }
    }

    /**
     * Returns single parameter list with default values.
     * @return
     */
    public List<ModuleParameter> getDefaultParameterList() {
        List<ModuleParameter> p;

        if (parameters != null && !parameters.isEmpty()) {
            p = cloneParameterList(parameters.get(0));

            for (int i = 0; i < p.size(); ++i) {
                p.get(i).reset();
            }

            return p;
        } else {
            return null;
        }
    }

    private List<ModuleParameter> cloneParameterList(List<ModuleParameter> list) {
        List<ModuleParameter> clonedList =
                new ArrayList<ModuleParameter>(list.size());
        for (ModuleParameter param : list) {
            clonedList.add(new ModuleParameter(param));
        }
        return clonedList;

    }

    /**
     * Checks whether this module is connected with another module by input.
     * @return <code>true</code> if this module's input is connected with
     * output of another module, otherwise <code>false</code>
     */
    public boolean isInputConnected() {
        return in != null;
    }

    /**
     * Checks whether this module is connected with another module by output.
     * @return <code>true</code> if this module's output is connected with
     * output of another module, otherwise <code>false</code>
     */
    public boolean isOutputConnected() {
        return out != null;
    }

    /**
     * Checks whether this module is connected with another module by loop
     * input.
     * @return <code>true</code> if this module's loop output is connected with
     * loop input of another module, otherwise <code>false</code>
     */
    public boolean isLoopInputConnected() {
        return loopIn != null;
    }

    /**
     * Checks whether this module is connected with another module by loop
     * output.
     * @return <code>true</code> if this module's loop input is connected with
     * loop output of another module, otherwise <code>false</code>
     */
    public boolean isLoopOutputConnected() {
        return loopOut != null;
    }

    /**
     * Removes input connection of this module.
     */
    public void removeInput() {
        in = null;
    }

    /**
     * Removes output connection of this module.
     */
    public void removeOutput() {
        out = null;
    }

    /**
     * Removes loop input connection of this module.
     */
    public void removeLoopInput() {
        loopIn = null;
    }

    /**
     * Removes loop output connection of this module.
     */
    public void removeLoopOutput() {
        loopOut = null;
    }

    /**
     * Returns name of this module.
     * @return Text representing this module.
     */
    public String getName() {
        return moduleName;
    }

    /**
     * Returns class used by this module to execute operations.
     * @return Name of class used to perform operations described by
     * this module.
     */
    public String getModuleClass() {
        return moduleClass;
    }

    /**
     * Returns parameters of this module.
     * @return set of parameters
     */
    public ArrayList<ArrayList<ModuleParameter>> getParameters() {
        return parameters;
    }

    /**
     * Sets parameters of this module to given ArrayList
     * @param params new parameters 
     */
    public void setParameters(ArrayList<ArrayList<ModuleParameter>> params) {
        parameters = params;
    }

    /**
     * Returns single parameter list converted to <code>LinkedHashMap</code>
     * @param index Index of the list with items which should be obtained
     * @return Map with parameter name/value structure
     */
    public LinkedHashMap<String, String> getParameterMap(int index) {
        if (parameters == null || parameters.isEmpty()) {
            throw new IllegalStateException("Empty parameters");
        }

        LinkedHashMap<String, String> map = new LinkedHashMap<String, String>();
        ArrayList<ModuleParameter> p = parameters.get(index);

        for (int i = 0; i < p.size(); ++i) {
            ModuleParameter mp = p.get(i);
            map.put(mp.getName(), mp.getValue());
        }

        return map;
    }

    /**
     * Returns description of this module.
     * @return Text description of this module used in text tool tips.
     */
    public String getDescription() {
        return description;
    }

    /**
     * Returns input of this module.
     * @return <code>ModuleConnection</code> instance responsible for 
     * connection between this and previous in flow module.
     * @see #hasPreviousModule() 
     * @see #isLoopInputConnected() 
     */
    public ModuleConnection getInput() {
        return in;
    }

    /**
     * Sets input of this module.
     * @param input <code>ModuleConnection</code> instance that will be
     * responsible for connection between this and previous in flow module.
     */
    public void setInput(ModuleConnection input) {
        in = input;
    }
    
    /**
     * Returns loop input of this module.
     * @return <code>ModuleConnection</code> instance responsible for loop
     * connection between this and previous in flow module.
     * @see #isLoopInputConnected()
     */
    public ModuleConnection getLoopInput() {
        return loopIn;
    }

    /**
     * Sets loop input of this module.
     * @param input <code>ModuleConnection</code> instance responsible for loop
     * connection between this and previous in flow module.
     */
    public void setLoopInput(ModuleConnection input) {
        loopIn = input;
    }
    
    /**
     * Returns output of this module.
     * @return <code>ModuleConnection</code> instance responsible for 
     * connection between this and next in flow module.
     * @see #hasNextModule() 
     * @see #isOutputConnected() 
     */
    public ModuleConnection getOutput() {
        return out;
    }
    
    /**
     * Sets output of this module.
     * @param input <code>ModuleConnection</code> instance that will be
     * responsible for connection between this and next in flow module.
     */    
    public void setOutput(ModuleConnection output) {
        out = output;
    }

    /**
     * Returns loop output of this module.
     * @return <code>ModuleConnection</code> instance responsible for loop
     * connection between this and next in flow module.
     * @see #isLoopOutputConnected()
     */
    public ModuleConnection getLoopOutput() {
        return loopOut;
    }

    /**
     * Sets loop output of this module.
     * @param output <code>ModuleConnection</code> instance responsible for loop
     * connection between this and next in flow module.
     */    
    public void setLoopOutput(ModuleConnection output) {
        loopOut = output;
    }

    /**
     * Gets module type.
     * @return Type of this module
     * @see pl.edu.zut.wi.vsl.app.modules.VslModule.ModuleType
     */
    public ModuleType getModuleType() {
        return type;
    }

    @Override
    public String toString() {
        return moduleName;
    }
}