/*
 *    Virtual Steganographic Laboratory (VSL)
 *    Copyright (C) 2008-2011  M. Wegrzyn <bend-up@users.sourceforge.net>

 *    This file is part of Virtual Steganographic Laboratory (VSL).

 *    VSL is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.

 *    VSL is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.

 *    You should have received a copy of the GNU General Public License
 *    along with VSL.  If not, see <http://www.gnu.org/licenses/>.
 */
package pl.edu.zut.wi.vsl.app.modules;

import java.awt.Color;
import java.io.Serializable;
import java.util.ArrayList;
import org.apache.log4j.Logger;
import pl.edu.zut.wi.vsl.app.Main;
import pl.edu.zut.wi.vsl.app.gui.DeskItem;
import pl.edu.zut.wi.vsl.app.utils.FileUtil;

/**
 * Connection between two modules. 
 * Contains also a list of all connections.
 *
 * @author Michal Wegrzyn
 */
public class ModuleConnection implements Serializable {

    /** For serialization */
    private static final long serialVersionUID = -4321948927502330219L;
    
    private final static Logger logger = Logger.getLogger(
            ModuleConnection.class);
    /** Color for connection when it is active */
    public static final Color COLOR_ACTIVE;
    /** Color for connection when it is inactive */
    public static final Color COLOR_INACTIVE;
    /** Color for text displayed above connection */
    public static final Color COLOR_TEXT;
    /** Source of this <code>ModuleConnction</code> */
    private VslModule source;
    /** Target of this <code>ModuleConnction</code> */
    private VslModule target;
    /** Source desk representation of this <code>ModuleConnction</code> */
    private DeskItem sourceItem;
    /** Target desk representation of this <code>ModuleConnction</code> */
    private DeskItem targetItem;
    /** Number of iterations for loop connections */
    private int numberOfLoops;
    /** Current value of loopCounter. It is decremented after every iteration */
    private int currentLoopCounter;
    /** Variable indicating whether this <code>ModuleConnection</code> 
     * is active
     */
    private boolean active;
    /* Reads colors from properties */
    

    static {
        Color ac = FileUtil.colorFromCsv(
                Main.getProperty("vsl.connections.color.active", "240, 185, 170"));
        COLOR_ACTIVE = ac == null ? new Color(240, 185, 170) : ac;
        Color ic = FileUtil.colorFromCsv(
                Main.getProperty("vsl.connections.color.inactive",
                "128, 128, 128"));
        COLOR_INACTIVE = ic == null ? Color.GRAY : ic;
        Color t = FileUtil.colorFromCsv(
                Main.getProperty("vsl.connections.color.text", "0, 0, 0"));
        COLOR_TEXT = t == null ? Color.BLACK : t;
    }

    /**
     * Creates a new <code>ModuleConnection</code> instance.
     * @param source the source <code>VslModule</code>
     * @param target the target <code>VslModule</code>
     */
    public ModuleConnection(DeskItem source, DeskItem target) {
        this.sourceItem = source;
        this.targetItem = target;
        this.source = source.getModuleInstance();
        this.target = target.getModuleInstance();
        this.active = false;
        this.numberOfLoops = -1;
    }

    /**
     * Creates a new <code>ModuleConnection</code> instance with given 
     * number of loops.
     * @param source the source <code>VslModule</code>
     * @param target the target <code>VslModule</code>
     * @param loops number of iterations that will be done with loops.
     */
    public ModuleConnection(DeskItem source, DeskItem target, int loops) {
        this(source, target);
        numberOfLoops = loops;
        currentLoopCounter = 0;
        VslModule current = this.target;
        while (current != this.source) {
            /* If current module in flow has parameters
             * and is in loop which source is VslModule source
             * then change number of its parameters */
            if (current.hasParameters()) {
                current.fitParameters(numberOfLoops);
            }
            current = current.getNextStraightModule();
        }
        if (current.hasParameters()) {
            current.fitParameters(numberOfLoops);
        }
    }

    /**
     * Updates parameters of modules within loop. For example if we 
     * remove some loop or if we change number of iterations 
     * then we must fit number of parameters for every module in 
     * loop to appropriate number.
     * @see pl.edu.zut.wi.vsl.client.modules.VslModule#parameters
     */
    public void uptadeModulesWithParams() {
        
        VslModule current = target;
        while (current != source) {
            /* If current module in flow has parameters
             * and is in loop which source is VslModule source
             * then change number of its parameters */
            if (current.hasParameters() &&
                    (current.getInternalLoopSource() == null ||
                    current.getInternalLoopSource().equals(source))) {
                current.fitParameters(numberOfLoops);
            }
            current = current.getNextStraightModule();
        }
        if (current.hasParameters() &&
                (current.getInternalLoopSource() == null ||
                current.getInternalLoopSource().equals(source))) {
            current.fitParameters(numberOfLoops);
        }
    }

    /**
     * Removes immediately (does not search for
     * loops and does not fits parameters) this connection.
     */
    public void removeImmediately() {
        logger.trace("Removing ModuleConnection " + source.getName() +
                "->" + target.getName());
        if (isLoopConnection()) {
            numberOfLoops = 0;
            source.removeLoopOutput();
            target.removeLoopInput();
        } else {
            source.removeOutput();
            target.removeInput();
        }
        sourceItem.removeConnection(this);
    }

    /**
     * Removes this connection
     */
    public void remove() {
        // check if this connection is in loop
        VslModule tLoopSrc = target.getLoopSource();
        
        /* if this connection is in loop, then
         * remove all loops associated with this connection
         * (if we remove connection and it is part of loop/loops,
         * we have to remove it/them) */
        if (tLoopSrc != null) {
            logger.debug("removing connection in loop, loop source:" +
                    tLoopSrc.getName());
            
            ArrayList<ModuleConnection> connectionsInLoop =
                    getAllConnectionsInLoop(tLoopSrc);
            ArrayList<VslModule> modulesInLoop =
                    getAllModulesInLoop(tLoopSrc);
            for (int i = 0; i < connectionsInLoop.size(); i++) {
                connectionsInLoop.get(i).removeImmediately();
            }
            for (int i = 0; i < modulesInLoop.size(); i++) {
                VslModule inLoop = modulesInLoop.get(i);
                if (inLoop.hasParameters()) {
                    inLoop.fitParameters(0);
                }
            }
        }
        
        removeImmediately();
    }

    /**
     * Checks whether this connection is connected to 
     * given <code>VslModule</code>
     * @param m <code>VslModule</code> to check if it is connected with 
     * this connection
     * @return <code>true</code> if this <code>ModuleConnection</code>
     * connects given <code>VslModule</code>
     */
    public boolean isConnectedTo(VslModule m) {
        if (m.isInputConnected()) {
            if (m.getInput().equals(this)) {
                return true;
            }
        }
        if (m.isLoopInputConnected()) {
            if (m.getLoopInput().equals(this)) {
                return true;
            }
        }
        if (m.isOutputConnected()) {
            if (m.getOutput().equals(this)) {
                return true;
            }
        }
        if (m.isLoopOutputConnected()) {
            if (m.getLoopOutput().equals(this)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Returns loop source of this connection - <code>VslModule</code>
     * that has loop output and is the source of the most outer loop
     * that contains this <code>ModuleConnection</code>
     * @return Loop source of this connection
     * @see pl.edu.zut.wi.vsl.client.modules.VslModule#loopOut
     */
    public VslModule getConnectionLoopSource() {
        VslModule m = target;
        while (m.hasNextStraightModule()) {
            m = m.getNextStraightModule();
        }
        if (m.isLoopOutputConnected()) {
            if (m.getLoopOutput().getTarget().
                    hasStraightForwardConnection(source)) {
                return m;
            }
        }
        while (!m.equals(target)) {
            if (m.isLoopOutputConnected()) {
                if (m.getLoopOutput().getTarget().
                        hasStraightForwardConnection(source)) {
                    return m;
                }
            }
            m = m.getPreviousStraightModule();
        }
        return source.getInternalLoopSource();
    }

    /**
     * returns the source VslModule for this connection
     * @return a <code>VslModule</code> value
     */
    public VslModule getSource() {
        return source;
    }

    /**
     * Returns the target VslModule for this connection
     * @return a <code>VslModule</code> value
     */
    public VslModule getTarget() {
        return target;
    }

    /**
     * Returns number of iterations if this connection is loop output 
     * of some <code>VslModule</code>
     * @return number of iterations 
     * @see #setNumberOfLoops(int) 
     * @see pl.edu.zut.wi.vsl.client.modules.VslModule#loopOut
     */
    public int getNumberOfLoops() {
        return numberOfLoops;
    }

    /**
     * Sets number of iterations if this connection is loop output 
     * of some <code>VslModule</code>
     * @param newVal
     * @see #getNumberOfLoops() 
     * @see pl.edu.zut.wi.vsl.client.modules.VslModule#loopOut
     */
    public void setNumberOfLoops(int newVal) {
        numberOfLoops = newVal;
    }

    /**
     * Tells whether this connection is loop connection.
     * @return <code>true</code> if this is loop connection
     * otherwise <code>false</code>.
     */
    public boolean isLoopConnection() {
        return numberOfLoops >= 0;
    }
    /**
     * Returns current value of loopCounter.
     * @return Number indicating how many iterations is left.
     * @see #setNumberOfLoops(int) 
     */
    public int getCurrentLoopCounter() {
        return currentLoopCounter;
    }

    /**
     * Sets current value of loopCounter.
     * @param newVal Number indicating how many iterations is left.
     * @see #getCurrentLoopCounter() 
     */
    public void setCurrentLoopCounter(int newVal) {
        currentLoopCounter = newVal;
    }

    /**
     * Gets all module connections within loop which given module 
     * is its source.
     * @param tLoopSrc Source of loop which module connections 
     * should be obtained.
     * @return <code>ArrayList</code> with module connections that
     * are in loop which source is given loop source module.
     */
    private ArrayList<ModuleConnection> getAllConnectionsInLoop(
                                                        VslModule tLoopSrc) {
        ArrayList<ModuleConnection> toRemove = new ArrayList<ModuleConnection>();
        VslModule current = tLoopSrc.getLoopOutput().getTarget();

        toRemove.add(tLoopSrc.getLoopOutput());
        while (!current.equals(tLoopSrc)) {
            toRemove.add(current.getOutput());
            if (current.isLoopOutputConnected()) {
                toRemove.add(current.getLoopOutput());
            }
            current = current.getNextStraightModule();
        }

        return toRemove;
    }

    /**
     * Gets all modules within loop which given module is its source.
     * @param tLoopSrc Source of loop which modules should be obtained.
     * @return <code>ArrayList</code> with modules that are in loop which source
     * is given loop source module.
     */    
    private ArrayList<VslModule> getAllModulesInLoop(VslModule tLoopSrc) {
        ArrayList<VslModule> toFit = new ArrayList<VslModule>();
        VslModule current = tLoopSrc.getLoopOutput().getTarget();

        toFit.add(tLoopSrc);
        while (!current.equals(tLoopSrc)) {
            toFit.add(current);
            current = current.getNextStraightModule();
        }

        return toFit;
    }

    /**
     * Tells whether state of this connection is active or inactive.
     * @return <code>true</code> if state is active, 
     * otherwise <code>false</code>
     * @see #setActive(boolean)
     */
    public boolean isActive() {
        return active;
    }

    /** 
     * Sets this connection to active or inactive state.
     * The differences of both states are in display color.
     * @param setActive if <code>true</code> this <code>ModuleConnection</code>
     * will be set to active state, otherwise if setActive is <code>false</code>
     * state will be set to inactive.
     * @see #isActive()
     */
    public void setActive(boolean setActive) {
        active = setActive;
    }

    /**
     * Returns the desk representation of this connection source
     * @return Source desk item
     */
    public DeskItem getSourceItem() {
        return sourceItem;
    }

    /**
     * Returns the desk representation of this connection target
     * @return Target desk item
     */
    public DeskItem getTargetItem() {
        return targetItem;
    }

}
