/*
 *    Virtual Steganographic Laboratory (VSL)
 *    Copyright (C) 2008-2011  M. Wegrzyn <bend-up@users.sourceforge.net>

 *    This file is part of Virtual Steganographic Laboratory (VSL).

 *    VSL is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.

 *    VSL is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.

 *    You should have received a copy of the GNU General Public License
 *    along with VSL.  If not, see <http://www.gnu.org/licenses/>.
 */
package pl.edu.zut.wi.vsl.app.gui.panels;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import pl.edu.zut.wi.vsl.app.MainWindow;
import pl.edu.zut.wi.vsl.app.modules.ModuleParameter;
import pl.edu.zut.wi.vsl.app.utils.VslUtil;

/**
 * Window for adjusting modules parameters.
 * 
 * @author Michal Wegrzyn
 */
public class ParametersWindow extends JDialog {

    /** Horizontal gap used between few components */
    private static final int PANEL_HORIZONTAL_GAP = 23;
    /** Vertical gap used between few components */
    private static final int PANEL_VERTICAL_GAP = 23;
    /** ArrayList with all parameters values that are presented by this dialog */
    private ArrayList<ArrayList<ModuleParameter>> params;
    /** Panel which holds all labels and fields of parameters */
    private JPanel parametersPanel;
    /** Panel which holds Default, OK and Cancel buttons */
    private JPanel buttonPanel;
    /** Container for <code>parametersPanel</code> & <code>buttonPanel</code>*/
    private JPanel mainPanel;
    /** <code>JScrollPane</code> for <code>mainPanel</code> */
    private JScrollPane scroller;
    /** Flag indicating whether user changed parameters in any way */
    private boolean changedParameters;

    /**
     * Creates new <code>ParametersWindow</code> instance.
     * @param parameters ArrayList with parameters to adjust.
     * @param defaultParameters ArrayList with default values of the adjusted
     * parameters.
     * @param descriptions ArrayList with descriptions of the adjusted parameters.
     * @param modName Name of the module which parameters are adjusted.
     */
    public ParametersWindow(ArrayList<ArrayList<ModuleParameter>> parameters,
            String modName) {
        changedParameters = false;
        params = parameters;
        
        // create panel with labels and fields for parameters
        parametersPanel = new JPanel();
        parametersPanel.setLayout(new ParametersLayout(
                params.size() * params.get(0).size(), 2, 1, 1,
                PANEL_HORIZONTAL_GAP, PANEL_VERTICAL_GAP));
        
        /* Go over all iterations */
        for (int i = 0; i < parameters.size(); i++) {
            ArrayList<ModuleParameter> paramsList = parameters.get(i);
            String no = i == 0 ? "" : " " + (i + 1);

            /* and within iterations over all parameters */
            for (int j = 0; j < paramsList.size(); ++j) {
                ModuleParameter parameter = paramsList.get(j);
                
                JLabel l = new JLabel(parameter.getName() + no);
                parametersPanel.add(l);
                JTextField t = new JTextField(10);
                addPopup(t);
                l.setLabelFor(t);
                t.setText(parameter.getValue());
                t.setName(parameter.getName());
                parametersPanel.add(t);
                l.setToolTipText(parameter.getDescription());
                t.setToolTipText("Set " + parameter.getName() +
                        " for iteration number " + (i + 1));
            }
        }
        
        // create buttons and panel for them
        JButton resetButton = new JButton("Defaults");
        resetButton.addActionListener(new java.awt.event.ActionListener() {

            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetToDefaultsAction();
            }
        });
        JButton okButton = new JButton("   OK   ");
        okButton.addActionListener(new java.awt.event.ActionListener() {

            public void actionPerformed(java.awt.event.ActionEvent evt) {
                confirmAction();
            }
        });
        JButton cancelButton = new JButton(" Cancel ");
        cancelButton.addActionListener(new java.awt.event.ActionListener() {

            public void actionPerformed(java.awt.event.ActionEvent evt) {
                closeWindow();
            }
        });
        KeyStroke escapeKeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE,
                0, false);
        Action escapeAction = new AbstractAction() {
            
            // close the frame when the user presses escape
            public void actionPerformed(ActionEvent e) {
                closeWindow();
            }
        };
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(
                escapeKeyStroke, "ESCAPE");
        getRootPane().getActionMap().put("ESCAPE", escapeAction);
        buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.TRAILING, 
                                             PANEL_VERTICAL_GAP, 5));
        buttonPanel.add(resetButton);
        buttonPanel.add(okButton);
        buttonPanel.add(cancelButton);

        // add panel with buttons and panel with labels and fields to main panel
        mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.add(new JLabel(), BorderLayout.NORTH);
        mainPanel.add(parametersPanel, BorderLayout.CENTER);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        // create scroll pane for main panel
        scroller = new JScrollPane(mainPanel);
        scroller.getVerticalScrollBar().setUnitIncrement(
                MainWindow.getDefaultScrollIncrement());

        setModalityType(JDialog.DEFAULT_MODALITY_TYPE);
        setLayout(new BorderLayout());
        setTitle("VSL - Parameters for " + modName);
        addWindowListener(new WindowAdapter() {

            @Override
            public void windowClosing(WindowEvent e) {
                closeWindow();
            }
        });
        add(scroller, BorderLayout.CENTER);
        setIconImage(VslUtil.LOGO_ICON.getImage());
        pack();
    }

    /**
     * Performs confirm action (user approved changes with OK button).
     * Replace all stored parameters with values from dialog's fields and
     * set <code>changedParameters</code> flag to <code>true</code>.
     */
    private void confirmAction() {
        changedParameters = true;
        Component[] components = parametersPanel.getComponents();

        for (int j = 0; j < params.size(); j++) {
            ArrayList<ModuleParameter> p = new ArrayList<ModuleParameter>();
            for (int i = 0; i < components.length / params.size(); i += 2) {
                JTextField t = (JTextField) components[j * (params.get(0).size()*2)
                                                       + i + 1 ];
                String paramVal = t.getText();

                params.get(j).get(i/2).setValue(paramVal);
            }
        }

        setVisible(false);
    }

    /**
     * Fill all fields with default parameters values.
     */
    private void resetToDefaultsAction() {
        changedParameters = true;
        Component[] components = parametersPanel.getComponents();
        ArrayList<ModuleParameter> p =
                    new ArrayList<ModuleParameter>(params.get(0));
        
        for (int j = 0; j < params.size(); j++) {

            for (int i = 0; i < components.length / params.size(); i += 2) {
                JTextField t = (JTextField) components[j * (params.get(0).size()*2)
                                                       + i + 1];
                String defVal = p.get(i/2).getDefaultValue();
                t.setText(defVal);
            }
        }
    }

    private void closeWindow() {
        setVisible(false);
    }

    /**
     * Shows this dialog in relative position to given Component.
     * If user changed parameters, returns <code>true</code>
     * @param c Component to which this dialog should be located relative
     * @return      <code>true</code> if user changed parameter(s); 
     *              <code>false</code> otherwise.
     */
    public boolean show(Component c) {
        changedParameters = false;
        setLocationRelativeTo(c);
        setVisible(true);

        return changedParameters;
    }

    /**
     * Returns parameters stored in this <code>object</code>. 
     * @return ArrayList of all parameters
     */
    public ArrayList<ArrayList<ModuleParameter>> getParams() {
        return params;
    }
    
    /**
     * Add a popup menu for changing set of parameters and all parameters 
     * to value present in given field.
     */ 
    private void addPopup(final JTextField t) {
        t.addMouseListener(new MouseAdapter() {

            @Override
            public void mouseClicked(MouseEvent e) {
                if (((e.getModifiers() & 
                        InputEvent.BUTTON1_MASK) != InputEvent.BUTTON1_MASK) || 
                                                                e.isAltDown()) {
                    JPopupMenu clearMenu = new JPopupMenu();
                    JMenuItem relatedItem = new JMenuItem("Apply to all related");
                    relatedItem.setToolTipText("Applies value of current field " +
                                              "to all parameters of this type");
                    relatedItem.addActionListener(new ActionListener() {

                        public void actionPerformed(ActionEvent ee) {
                            String value = t.getText();
                            String nameTemplate = null;
                            Component[] components = parametersPanel.getComponents();  
                            nameTemplate = getNameTemplate(t);
                            
                            for (int j = 0; j < params.size(); j++) {
                                for (int i = 0; i < components.length / params.size(); i += 2) {
                                    int idx = j * (params.get(0).size()*2) + i + 1;
                                    JTextField tmp = (JTextField) components[idx];
                                    String name = tmp.getName();
                                    if (name.startsWith(nameTemplate)) {
                                        tmp.setText(value);
                                    }
                                }
                            }
                        }

                        
                    });
                    clearMenu.add(relatedItem);
                    JMenuItem allItem = new JMenuItem("Apply to all");
                    allItem.setToolTipText("Applies value of current field " +
                                                "to all parameters");
                    allItem.addActionListener(new ActionListener() {

                        public void actionPerformed(ActionEvent ee) {
                            String value = t.getText();
                            Component[] components = parametersPanel.getComponents();  
                            
                            for (int j = 0; j < params.size(); j++) {
                                for (int i = 0; i < components.length / params.size(); i += 2) {
                                    int idx = j * (params.get(0).size()*2) + i + 1;
                                    JTextField tmp = (JTextField) components[idx];
                                    tmp.setText(value);
                                }
                            }
                        }
                    });
                    clearMenu.add(allItem);
                    clearMenu.show(ParametersWindow.this, e.getX(), e.getY());
                }
            }
        });
    }
    
    
    private String getNameTemplate(JTextField t) {
        Component[] components = parametersPanel.getComponents();
        String nameTemplate = null;
        // get beginning part of the parameter name
        for (int j = 0; j < params.size(); j++) {
            for (int i = 0; i < components.length / params.size(); i += 2) {
                int idx = j * (params.get(0).size()*2) + i + 1;
                JTextField tmp = (JTextField) components[idx];

                if (tmp.equals(t)) {
                    String name = t.getName();
                    if (i < params.get(0).size() * params.size() * 2) {
                        nameTemplate = name;
                    } else {
                        int spaceIdx = name.lastIndexOf(" ");
                        nameTemplate = name.substring(0, spaceIdx);   
                    }
                    break;
                }
            }
        }
        
        
        return nameTemplate;
    }
    
    
}
