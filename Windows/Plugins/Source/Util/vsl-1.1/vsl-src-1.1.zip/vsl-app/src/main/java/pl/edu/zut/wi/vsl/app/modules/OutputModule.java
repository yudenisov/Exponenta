/*
 *    Virtual Steganographic Laboratory (VSL)
 *    Copyright (C) 2008-2011  M. Wegrzyn <bend-up@users.sourceforge.net>

 *    This file is part of Virtual Steganographic Laboratory (VSL).

 *    VSL is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.

 *    VSL is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.

 *    You should have received a copy of the GNU General Public License
 *    along with VSL.  If not, see <http://www.gnu.org/licenses/>.
 */
package pl.edu.zut.wi.vsl.app.modules;

import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import pl.edu.zut.wi.vsl.app.Main;
import pl.edu.zut.wi.vsl.app.VslException;
import pl.edu.zut.wi.vsl.app.utils.FileUtil;
import pl.edu.zut.wi.vsl.commons.StegoPackage;

/**
 * Module for output utilities.
 *
 * @author Michal Wegrzyn
 */
public class OutputModule extends VslModule implements Serializable {

    /** For serialization. */
    private static final long serialVersionUID = 628258823208059509L;
    private static final String DESC = "Output for images - provides saving "
            + "images and obtained files";
    /** Output directory */
    private File outputDirectory;
    /** Output subdirectory */
    private String outputSubdirectory;
    /** Pattern for output results */
    private String outputNamePattern;
    /** Format for output results */
    private String outputNameFormat;
    /** Number of saved files so far */
    private int savedCounter;

    public OutputModule() {
        super("Output", DESC, ModuleType.Output);
        outputDirectory = new File(FileUtil.getOutputDirectory());
        outputNamePattern = Main.getProperty("vsl.output.filename",
                                                                    "result");
        outputNameFormat = Main.getProperty("vsl.output.customImageExtension",
                                                                    "png");
        savedCounter = 0;
    }

    public OutputModule(OutputModule v) {
        super(v);

        savedCounter = v.getSavedCounter();
        
        if (v.getOutputDirectory() != null) {
            outputDirectory = new File(
                            v.getOutputDirectory().getAbsolutePath());
        }
        if (v.getOutputSubdirectory() != null) {
            outputSubdirectory = v.getOutputSubdirectory();
        }
        if (v.getOutputPattern() != null) {
            outputNamePattern = v.getOutputPattern();
        }
        if (v.getOutputNameFormat() != null) {
            outputNameFormat = v.getOutputNameFormat();
        }
    }



    /**
     * Returns pattern for output files. 
     * @return Pattern used by this module while saving files.
     * @see #outputNamePattern
     * @see #execute(pl.edu.zut.wi.vsl.commons.StegoPackage)
     */
    public String getOutputPattern() {
        return outputNamePattern;
    }

    /**
     * Sets pattern for output files.
     * @param pattern Pattern used by this module while saving files.
     * @see #outputNamePattern
     * @see #execute(pl.edu.zut.wi.vsl.commons.StegoPackage)
     */
    public void setOutputPattern(String pattern) {
        outputNamePattern = pattern;
    }

    /**
     * Returns format for output files.
     * @return Format used by this module while saving files.
     * @see #outputNameFormat
     * @see #execute(pl.edu.zut.wi.vsl.commons.StegoPackage)
     */
    public String getOutputNameFormat() {
        return outputNameFormat;
    }

    /**
     * Sets format for output files.
     * @param format Format used by this module while saving files.
     * @see #execute(pl.edu.zut.wi.vsl.commons.StegoPackage)
     */
    public void setOutputNameFormat(String format) {
        this.outputNameFormat = format;
    }

    /**
     * Gets path to main output directory in which output files will be saved.
     * @return filepath to current experiment output directory.
     * @see #getOutputSubdirectory()
     */
    public File getOutputDirectory() {
        return outputDirectory;
    }

    /**
     * Sets path to main output directory in which output files will be saved.
     * @param dir filepath to current experiment output directory.
     * @see #setOutputSubdirectory()
     */
    public void setOutputDirectory(File dir) {
        outputDirectory = dir;
    }

    /**
     * Gets path to output subdirectory in which output files will be saved.
     * @return filepath to one of the Input modules output subdirectory
     * @see #getOutputDirectory()
     */
    public String getOutputSubdirectory() {
        return outputSubdirectory;
    }

    /**
     * Sets path to output subdirectory in which output files will be saved.
     * @param dir filepath to one of the Input modules output subdirectory
     * @see #setOutputDirectory()
     */
    public void setOutputSubdirectory(String dir) {
        outputSubdirectory = dir;
    }

    /**
     * Returns number of saved files by this module so far.
     * @return amount of saved output files
     */
    public int getSavedCounter() {
        return savedCounter;
    }

    /**
     * Sets number of saved files by this module.
     * @param cnt amount of saved output files
     */
    public void setSavedCounter(int cnt) {
        savedCounter = cnt;
    }

    @Override
    public StegoPackage execute(StegoPackage cp) throws VslException {
        outputSubdirectory = cp.getOutputSubdirectory();
        int paramIndex = getLoopNumber();

        try {
            outputNamePattern = outputNamePattern == null
                                                ? "null"
                                                : outputNamePattern;
            if (in.getSource().getModuleType() ==
                                        ModuleType.SteganographicDecoder) {
                File outputDir = new File(
                                    outputDirectory.getAbsolutePath()
                                    + File.separator + outputSubdirectory);
                FileUtil.writeMessage(cp.getMessage(),
                                        outputDir,
                                        outputNamePattern,
                                        getSavedCounter());
                savedCounter++;
            } else {
                File outputDir = new File(outputDirectory.getAbsolutePath()
                                    + File.separator
                                    + outputSubdirectory);
                FileUtil.writeImage(cp.getImage(),
                                        outputDir,
                                        outputNamePattern,
                                        outputNameFormat,
                                        getSavedCounter());
                savedCounter++;
            }
        } catch (IOException e) {
            throw new VslException("Exception during execution", e);
        }

        return cp;
    }

    @Override
    public void cleanUpModule() {
        setSavedCounter(0);
    }


}
