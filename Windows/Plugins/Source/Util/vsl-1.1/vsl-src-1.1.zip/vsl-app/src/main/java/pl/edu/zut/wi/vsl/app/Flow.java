/*
 *    Virtual Steganographic Laboratory (VSL)
 *    Copyright (C) 2008-2011  M. Wegrzyn <bend-up@users.sourceforge.net>

 *    This file is part of Virtual Steganographic Laboratory (VSL).

 *    VSL is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.

 *    VSL is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.

 *    You should have received a copy of the GNU General Public License
 *    along with VSL.  If not, see <http://www.gnu.org/licenses/>.
 */
package pl.edu.zut.wi.vsl.app;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import org.apache.log4j.Logger;
import pl.edu.zut.wi.vsl.app.modules.InputModule;
import pl.edu.zut.wi.vsl.app.modules.ReportModule;
import pl.edu.zut.wi.vsl.app.modules.VslModule;
import pl.edu.zut.wi.vsl.app.modules.VslModule.ModuleType;
import pl.edu.zut.wi.vsl.app.utils.VslUtil;
import pl.edu.zut.wi.vsl.commons.StegoImage;
import pl.edu.zut.wi.vsl.commons.StegoPackage;

/**
 * Thread for handling processing for one Input module in VSL.
 * <p>
 * One processing (flow) is set of all operations performed by modules which
 * as source have the same Input module (in other words - they are directly
 * or indirectly connected with the same Input module).
 * 
 * @author Michal Wegrzyn
 */
public class Flow extends Thread {

    private final static Logger logger = Logger.getLogger(Flow.class);
    /** Input module handled by this <code>Flow */
    private final InputModule in;
    /** Output directory for this thread */
    private final String directory;
    /** Monitor of this experiment */
    private final FlowMonitor monitor;
    /** Number of this thread */
    private final int threadNumber;
    /** Report modules present in flow handled by 
     * this <code>Flow</code> */
    private final ReportModule[] reports;
    /** Boolean indicating whether this <code>Flow</code>
     * has to handle any report modules */
    private final boolean doReport;
    /** Variable indicating whether this thread is still running */
    private transient boolean running;
    /** Variable indicating whether this should run */
    private transient boolean run;

    
    /**
     * Creates Flow for given input module
     * @param input - start module for process
     */
    public Flow(FlowMonitor monitor, InputModule input, int experimentNumber) {

        setDaemon(true);
        this.monitor = monitor;
        in = input;
        run = true;
        running = true;
        directory = getBaseDirectory() + File.separator + "input" +
                VslUtil.prependZeros(experimentNumber, 3);
        threadNumber = experimentNumber;
        reports = getReportModules();
        doReport = (reports != null) ? true : false;
    }

    @Override
    public void run() {
        ArrayList<File> inputFiles = new ArrayList<File>();
        StegoPackage pack;                                  // current package
        StegoPackage oldPack;                               // temporary package
        String msg;
        VslModule current;
        VslModule next;

        if (in.getInputFiles() == null) {
            msg = "Input does not have any input files.";
            logger.info(msg);
            VslUtil.showWarn(getWindow(), msg);
            log(msg);
            stopProcess();
            return;
        }

        if (!in.hasNextModule()) {
            msg = "Input is not connected to any module.";
            logger.info(msg);
            VslUtil.showWarn(getWindow(), msg);
            log(msg);
            stopProcess();
            return;
        }

        inputFiles.addAll(in.getInputFiles());
        //loop over all files given in Input Module
        logger.info("Input " + threadNumber + " starting its " +
                inputFiles.size() + " iterations.");
        FLOW:for (int i = 0; i < inputFiles.size(); i++) {

            current = in.deepCopy();

            File img = ((InputModule)current).getInputFiles().get(i);

            pack = new StegoPackage();
            oldPack = new StegoPackage();
            

            int iterationNumber = 0;
            current.resetLoopCounters();

            while (current.hasNextModule()) {
                // check if user stoped executions
                if (!run || isInterrupted()) {
                    break FLOW;
                }

                if (current.getModuleType() == ModuleType.Input) {
                    try {
                        pack = createNewPackage(img);
                        logger.debug("Creating new image: "
                                + "type: " + pack.getImage().getType()
                                + ", isAlphaPremultiplied: " +
                                    pack.getImage().isAlphaPremultiplied()
                                + ", path: " + pack.getImage().getPath()
                                );
                    } catch (IOException e) {
                        msg = "Could not create new package";
                        logger.error(msg, e);
                        VslUtil.showError(getWindow(), msg, e);
                        break;
                    }
                }
                pack.setOutputSubdirectory(directory);
                // mark active connection
                current.getNextConnection().setActive(true);
                repaintDesktop();

                // get next module
                next = current.getNextModule(true);
                // log starting iteration
                msg = "Starting " + iterationNumber + " iteration, " +
                        current.getName() + " -> " + next.getName();
                log(msg);
                logger.info(msg);
                pack.setInfo(null);
                
                // execute next module
                try {

                    oldPack = new StegoPackage(pack);
                    pack = next.execute(pack);
                    if (doReport) {
                        handleReport(oldPack, pack, current, next, iterationNumber);
                    }
                } catch (Exception e) {
                    msg = "Error during execution.";
                    logger.error(msg, e);
                    log("ERROR: " + VslUtil.getErrorTrace(e));
                    VslUtil.showError(getWindow(), msg, e);
                    break;
                } catch (OutOfMemoryError e) {
                    msg = VslUtil.OUT_OF_MEMORY_MSG;
                    logger.error(msg, e);
                    log("ERROR: " + VslUtil.getErrorTrace(e));
                    VslUtil.showError(getWindow(), "Out of memory. Please try to " +
                            "start VSL with -Xmx switch.", e);
                    break;
                }
                iterationNumber++;
                incrementExecuted();

                // change connection color to normal and repaint desktop
                current.getNextConnection().setActive(false);
                repaintDesktop();

                // process next module
                current = next;
            }
        }
        endProcess();
    }

    /**
     * Counts number of executions for this thread (it's input)
     * @return - number of executions that will be performed by this thread
     * in whole experiment
     */
    public int countExecutions() {
        int counter = 0;

        VslModule current = in.deepCopy();
        current.resetLoopCounters();

        while (current.hasNextModule()) {
            current = current.getNextModule(true);
            counter++;
        }
        in.resetLoopCounters();
        return counter * in.getInputFiles().size();
    }

    /**
     * Indicated whether this thread is still running.
     * @return <code>true</code> if thread still runs, otherwise 
     * <code>false</code>
     */
    public boolean isRunning() {
        return running;
    }

    /**
     * Stops this process.
     */
    public void stopProcess() {
        run = false;
    }

    /** 
     * Ends this thread.
     */
    private void endProcess() {
        String msg = "Input number " + threadNumber + " stopped.";
        logger.debug(msg);
        MainWindow.getLogger().log(msg);
        monitor.countDown();
        running = false;
    }

    private StegoPackage createNewPackage(File img) throws IOException {

        String msg;
        try {
            return new StegoPackage(new StegoImage(img));
            
        } catch (IOException e) {
            msg = "Could not create image from file:\n\n" +
                    img.getAbsolutePath() + "\n\n";
            logger.error(msg, e);
            VslUtil.showError(getWindow(), msg, e);
            log("Could not create image from file" +
                    img.getAbsolutePath() + ". Reason: " + e.getMessage());
            throw new IOException(e);
        } catch (OutOfMemoryError oe) {
            msg = VslUtil.OUT_OF_MEMORY_MSG;
            logger.error(msg, oe);
            log("ERROR: " + VslUtil.getErrorTrace(oe));
            VslUtil.showError(getWindow(), "Out of memory. Please try to " +
                    "start VSL with -Xmx switch.", oe);
            throw new IOException(oe);
        }
    }

    /**
     * Gets all report modules within flow managed by this thread.
     * @return Array with report modules present in flow of this thread.
     */
    private ReportModule[] getReportModules() {
        ArrayList<ReportModule> rm = new ArrayList<ReportModule>();

        VslModule next;
        VslModule current = in.deepCopy();
        while (current.hasNextStraightModule()) {
            next = current.getNextStraightModule();
            if (next.getModuleType() == ModuleType.Report) {
                rm.add((ReportModule) next);
            }
            current = next;
        }
        if (!rm.isEmpty()) {
            return rm.toArray(new ReportModule[rm.size()]);
        } else {
            return new ReportModule[0];
        }
    }

    /**
     * Handles reporting for this flow.
     * @param pp Package from previous execution
     * @param cp Package from current execution
     * @param previous Module executed just before examined module
     * @param processed Examined module
     * @param iteration Number of iteration
     */
    private void handleReport(StegoPackage pp, StegoPackage cp,
            VslModule previous, VslModule processed, int iteration) {
        for (int i = 0; i < reports.length; i++) {
            reports[i].report(pp, cp, previous, processed, iteration,
                    threadNumber);
        }
    }

    private void incrementExecuted() {
        monitor.incrementExecuted();
    }

    /**
     * Logs message to applications log from this input thread
     * @param msg - String to log
     */
    private void log(String msg) {
        MainWindow.getLogger().logMessage("Input number " + threadNumber +
                ": " + msg);
    }

    private MainWindow getWindow() {
        return monitor.getWindow();
    }

    private String getBaseDirectory() {
        return monitor.getBaseDirectory();
    }

    private void repaintDesktop() {
        monitor.repaintDesktop();
    }

}
