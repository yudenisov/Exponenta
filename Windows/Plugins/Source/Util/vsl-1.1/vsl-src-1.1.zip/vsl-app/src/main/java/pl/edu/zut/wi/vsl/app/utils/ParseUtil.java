/*
 *    Virtual Steganographic Laboratory (VSL)
 *    Copyright (C) 2008-2011  M. Wegrzyn <bend-up@users.sourceforge.net>

 *    This file is part of Virtual Steganographic Laboratory (VSL).

 *    VSL is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.

 *    VSL is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.

 *    You should have received a copy of the GNU General Public License
 *    along with VSL.  If not, see <http://www.gnu.org/licenses/>.
 */
package pl.edu.zut.wi.vsl.app.utils;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.dom.DOMSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;
import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
import pl.edu.zut.wi.vsl.app.Main;
import pl.edu.zut.wi.vsl.app.MainWindow;
import pl.edu.zut.wi.vsl.app.gui.TransferableTreeNode;
import pl.edu.zut.wi.vsl.app.modules.DecoderModule;
import pl.edu.zut.wi.vsl.app.modules.DistortionModule;
import pl.edu.zut.wi.vsl.app.modules.EncoderModule;
import pl.edu.zut.wi.vsl.app.modules.ModuleParameter;
import pl.edu.zut.wi.vsl.app.modules.SteganalyticModule;
import pl.edu.zut.wi.vsl.app.modules.VslModule;
import pl.edu.zut.wi.vsl.app.modules.VslModule.ModuleType;

/**
 * Utility for performing all parsing related operations.
 *
 * @author Michal Wegrzyn
 */
public class ParseUtil {

    private static volatile ParseUtil INSTANCE;
    /** Log4J Logger */
    private static final Logger logger = Logger.getLogger(MainWindow.class);
    private static final String RESOUCE_PATH = FileUtil.getCurrentDir()
                                                        + File.separator
                                                        + "etc"
                                                        + File.separator;
    private static final String XML_CONFIGURATION = "modules.xml";
    private static final String SCHEMA_FILE = "modules.xsd";

    protected ParseUtil() { }

    private static synchronized ParseUtil tryCreateInstance() {
        if (INSTANCE == null) {
            INSTANCE = new ParseUtil();
        }
        return INSTANCE;
    }

    public static ParseUtil getInstance() {
        // use local variable, don't issue 2 reads (memory fences) to 'INSTANCE'
        ParseUtil s = INSTANCE;
        if (s == null) {
            /* check under lock;
             * move creation logic to a separate method to allow
             * inlining of getInstance() */
            s = tryCreateInstance();
        }
        return s;
    }

    /**
     * Creates modules list from configuration file.
     * @param treeRootNode Root node of the list.
     */
    public void createModuleListNodes(DefaultMutableTreeNode treeRootNode)
            throws ParserConfigurationException, SAXException, IOException {

        logger.debug("Creating modules list");
        DefaultMutableTreeNode category = null;
        DefaultMutableTreeNode module = null;
        String defaultPath = RESOUCE_PATH + XML_CONFIGURATION;
        String filepath = Main.getProperty("vsl.modules.configurationFile",
                                                            defaultPath);
        // getting the default implementation of DOM builder
        DocumentBuilderFactory factory =
                                    DocumentBuilderFactory.newInstance();
        factory.setNamespaceAware(true);
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document document = null;
        Validator validator = getSchema().newValidator();

        try {
            logger.trace("Parsing modules.xml file: " + filepath);
            document = builder.parse(filepath);
            // validate xml config file against schema
            validator.validate(new DOMSource(document));
        } catch (IOException e) {
            String msg = "Exception occured during parsing modules file." +
                    " Application will try to parse file from default path.";
            logger.error(msg, e);

            try {
                logger.trace("Could not load modules.xml from given" +
                        " path, trying default: " + defaultPath);
                document = builder.parse(defaultPath);
                validator.validate(new DOMSource(document));
            } catch (SAXException ex) {
                msg = "Could not load modules.xml from given and default" +
                        " path. Please check your configuration.";
                logger.error(msg, ex);
                throw new SAXException(msg, ex);
            } catch (IOException ex) {
                msg = "Could not load modules.xml from given and default" +
                        " path. Please check your configuration.";
                logger.error(msg, ex);
                throw new IOException(msg, ex);
            }
        }

        NodeList nodes_i = document.getDocumentElement().getChildNodes();

        for (int i = 0; i < nodes_i.getLength(); i++) {
            Node node_i = nodes_i.item(i);
            // searching for categories
            if (node_i.getNodeName().equals("category")) {
                NamedNodeMap atr = node_i.getAttributes();
                final String categoryName = atr.getNamedItem("name").
                                                    getNodeValue();
                category = new DefaultMutableTreeNode(categoryName);
                ModuleType mtype;

                treeRootNode.add(category);
                NodeList nodes_j = node_i.getChildNodes();
                // searching for modules within category
                for (int j = 0; j < nodes_j.getLength(); j++) {
                    Node node_j = nodes_j.item(j);
                    if (node_j.getNodeName().equals("module")) {
                        NodeList nodes_k = node_j.getChildNodes();
                        String name = null;
                        String desc = null;
                        String clazz = null;
                        List<ModuleParameter> p = null;
                        for (int k = 0; k < nodes_k.getLength(); k++) {
                            Node node_k = nodes_k.item(k);
                            if (node_k.getNodeName().equals("name")) {
                                name = node_k.getTextContent();
                            } else if (node_k.getNodeName().equals("description")) {
                                desc = node_k.getTextContent();
                            } else if (node_k.getNodeName().equals("class")) {
                                clazz = node_k.getTextContent();
                            } else if (node_k.getNodeName().equals("parameters")) {
                                NodeList nodes_l = node_k.getChildNodes();
                                p = new ArrayList<ModuleParameter>();
                                for (int l = 0; l < nodes_l.getLength(); l++) {
                                    Node node_l = nodes_l.item(l);
                                    if (node_l.getNodeName().equals("parameter")) {
                                        NodeList nodes_m = node_l.getChildNodes();
                                        String pname = null;
                                        String pdesc = null;
                                        String pdef = null;
                                        for (int m = 0; m < nodes_m.getLength(); m++) {
                                            Node node_m = nodes_m.item(m);
                                            if (node_m.getNodeName().equals("name")) {
                                                pname = node_m.getTextContent();
                                            } else if (node_m.getNodeName().equals("description")) {
                                                pdesc = node_m.getTextContent();
                                            } else if (node_m.getNodeName().equals("default")) {
                                                pdef = node_m.getTextContent();
                                            }
                                        }
                                        if (pname != null) {
                                            ModuleParameter param =
                                                    new ModuleParameter(pname, pdef, pdesc);
                                            p.add(param);
                                        }
                                    }
                                }
                            }
                        }
                        if (name == null || clazz == null) {
                            String msg = "Name or class of one of the " +
                                    "modules is null:\nname: " + name +
                                    "\nclass:" + clazz;
                            throw new IllegalArgumentException(msg);
                        }
                        // adding module to list
                        VslModule v = null;

                        if ("Encoders".equals(categoryName)) {
                            v = new EncoderModule(name, desc, clazz);
                        } else if ("Decoders".equals(categoryName)) {
                            v = new DecoderModule(name, desc, clazz);
                        } else if ("Analysers".equals(categoryName)) {
                            v = new SteganalyticModule(name, desc, clazz);
                        } else if ("Distortions".equals(categoryName)) {
                            v = new DistortionModule(name, desc, clazz);
                        } 
                        logger.trace("Adding module to list. Name: " +
                                name + ", class: " + clazz + ", type: " +
                                v.getModuleType());
                        
                        if (p != null && !p.isEmpty()) {
                            ArrayList<ArrayList<ModuleParameter>> params =
                                    new ArrayList<ArrayList<ModuleParameter>>();
                            params.add((ArrayList) p);
                            v.setParameters(params);
                        }
                        module = new TransferableTreeNode(v);
                        category.add(module);
                    }
                }
            }
        }

    }


    /**
     * Gets the compiled schema for the modules configuration file.
     *
     * @return The compiled schema.
     */
    private static Schema getSchema()
            throws SAXException {

        Schema schema = null;
        SchemaFactory schemaFactory = SchemaFactory.newInstance(
                XMLConstants.W3C_XML_SCHEMA_NS_URI);

        File schemaFile = new File(RESOUCE_PATH + SCHEMA_FILE);
        if (schemaFile == null)
            schema = schemaFactory.newSchema();
        else {
            schema = schemaFactory.newSchema(schemaFile);
        }

        return schema;
    }



}
