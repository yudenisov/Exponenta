/*
 *    Virtual Steganographic Laboratory (VSL)
 *    Copyright (C) 2008-2011  M. Wegrzyn <bend-up@users.sourceforge.net>

 *    This file is part of Virtual Steganographic Laboratory (VSL).

 *    VSL is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.

 *    VSL is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.

 *    You should have received a copy of the GNU General Public License
 *    along with VSL.  If not, see <http://www.gnu.org/licenses/>.
 */
package pl.edu.zut.wi.vsl.app;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Enumeration;
import java.util.Properties;
import javax.imageio.ImageIO;
import javax.swing.UIManager;
import org.apache.log4j.Logger;
import pl.edu.zut.wi.vsl.app.utils.FileUtil;
import pl.edu.zut.wi.vsl.app.utils.VslUtil;

/**
 * Main class of client application.
 * 
 * @author Michal Wegrzyn
 */
public class Main {
    
    private static volatile Main INSTANCE;
    private final static Logger logger = Logger.getLogger(Main.class);
    /**
     * Name of the property file for the Virtual Steganographic Laboratory
     */
    private final static String PROPERTY_FILE = "vsl.properties";
    /** Contains the editor properties */
    private static Properties properties;
    /** Handled output files */
    private static String[] imgWriteSuffixes;

    protected Main() { }

    private static synchronized Main tryCreateInstance() {
        if (INSTANCE == null) {
            INSTANCE = new Main();
        }
        return INSTANCE;
    }

    public static Main getInstance() {
        // use local variable, don't issue 2 reads (memory fences) to 'INSTANCE'
        Main s = INSTANCE;
        if (s == null) {
            /* check under lock; 
             * move creation logic to a separate method to allow 
             * inlining of getInstance() */
            s = tryCreateInstance();
        }
        return s;
    }

    
    /**
     * Ensure that copyright notes are displayed and properties file
     * loaded before any processing begins */
    static{ 
        /* display copyright notes */
        System.out.println(
            "Virtual Steganographic Laboratory (VSL)");
        System.out.println(
            "Copyright (C) 2008-2011 M. Wegrzyn");
        System.out.println(    
            "This program comes with ABSOLUTELY NO WARRANTY.\n" +
            "This is free software, and you are welcome to redistribute it\n" +
            "under certain conditions; see license for details.");
        String startDir = System.getProperty("user.dir");
        /* set current working dir to jar location
         * NOTE: disable mounting in NB */
        try {
            FileUtil.mountCurrentDir();
        } catch (Exception e) {
            String msg = "Could not determine main jar location.";
            logger.error(msg, e);
            VslUtil.showError(null, msg, e);
        }
        loadProperties();
        properties.setProperty("startdir", startDir);
    }    

    public static void main(String[] args) throws FileNotFoundException {
        
        /* display Java info */
        String[] imgReadSuffixes = ImageIO.getReaderFileSuffixes();
        imgWriteSuffixes = ImageIO.getWriterFileSuffixes();
        StringBuilder sbr = new StringBuilder();
        StringBuilder sbw = new StringBuilder();
        for (String suffix : imgReadSuffixes) {
            sbr.append(suffix);
            sbr.append("; ");
        }
        for (String suffix : imgWriteSuffixes) {
            sbw.append(suffix);
            sbw.append("; ");
        }
        Properties sysProps = System.getProperties();
        for (Enumeration e = sysProps.propertyNames(); e.hasMoreElements(); ) {
            String key = (String) e.nextElement();
            if (key.startsWith("java")) {
                String value = sysProps.getProperty(key);
                logger.info(key + "=" + value);
            }
        }
        logger.info("Handled Java Reader file suffixes: "+sbr);
        logger.info("Handled Java Writer file suffixes: "+sbw);
        
        /* set output directory */
        boolean useDefOut = VslUtil.toBoolean(getProperty(
                "vsl.useDefaultOutputDirectory", "true").trim());
        String defaultOutputDir = FileUtil.getCurrentDir() +
                    File.separator + "results";
        if (useDefOut) {
            FileUtil.setOutputDirectory(defaultOutputDir);
        } else {
            FileUtil.setOutputDirectory(getProperty("vsl.customOutputDir", 
                    defaultOutputDir).trim());
        }
        
        /* set UI/Look And Feel */
        boolean systemLnf = VslUtil.toBoolean(getProperty(
                "vsl.useSystemLookAndFeel", "false").trim());
        if (systemLnf == true) {
            try {
                UIManager.setLookAndFeel(
                        UIManager.getSystemLookAndFeelClassName());
            } catch (Exception e) {
                logger.error("Could not set Look and Feel", e);
                VslUtil.showError(null, "Could not set LNF", e);
            }
        } else {
            try {
                UIManager.setLookAndFeel(
                        UIManager.getCrossPlatformLookAndFeelClassName());
            } catch (Exception e) {
                logger.error("Could not set Look and Feel", e);
                VslUtil.showError(null, "Could not set LNF", e);
            }
        }

        /* show Main Window */
        java.awt.EventQueue.invokeLater(new Runnable() {

            public void run() {
                new MainWindow().setVisible(true);
            }
        });

    }

    /**
     * Searches for a property with a specified propertyName. 
     * If property is not found in the list, default value is 
     * returned.
     * @param propertyName - key of the value
     * @param defaultValue - a default value
     * @return the value from the VSL properties with a specified key
     */
    public static String getProperty(String propertyName, String defaultValue) {
        return properties.getProperty(propertyName, defaultValue);
    }

    public static String[] getSupportedOutputFormats() {
        return imgWriteSuffixes;
    }

    /**
     * Loads properties 
     */
    private static void loadProperties() {

        try {
            String propertiesPath = FileUtil.getCurrentDir() +
                    File.separator + "etc" + File.separator + PROPERTY_FILE;
            properties = FileUtil.readProperties(propertiesPath);
            java.util.Enumeration keys =
                    (java.util.Enumeration) properties.propertyNames();

            if (!keys.hasMoreElements()) {
                throw new Exception("Could not read a configuration file.\n" +
                        "This file should be named \"" + PROPERTY_FILE +
                        "\" and should be placed in: \n" + 
                        "1) \"" + FileUtil.getCurrentDir() + File.separator + 
                        "etc" + File.separator + "\", or\n" + 
                        "2) your user home, which is set to \n" + "\"" + 
                        System.getProperties().getProperty("user.home") + 
                        "\", or\n" + 
                        "3) the directory that java was started from\n");
            }
        } catch (Exception e) {
            logger.warn("Could not read configuration file", e);
            VslUtil.showWarn(null, e.getMessage());
        }
    }
}