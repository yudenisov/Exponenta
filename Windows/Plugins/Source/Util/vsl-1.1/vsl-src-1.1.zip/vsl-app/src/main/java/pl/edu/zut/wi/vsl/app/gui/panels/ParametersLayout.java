/*
 *    Virtual Steganographic Laboratory (VSL)
 *    Copyright (C) 2008-2011  M. Wegrzyn <bend-up@users.sourceforge.net>

 *    This file is part of Virtual Steganographic Laboratory (VSL).

 *    VSL is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.

 *    VSL is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.

 *    You should have received a copy of the GNU General Public License
 *    along with VSL.  If not, see <http://www.gnu.org/licenses/>.
 */
package pl.edu.zut.wi.vsl.app.gui.panels;

import java.awt.Container;
import java.awt.GridLayout;
import java.awt.Insets;

/**
 * Class responsible for layout of the <code>ParametersWindow</code>.
 * 
 * @author Michal Wegrzyn
 */
public class ParametersLayout extends GridLayout {
    private boolean initializePhase;
    private int preferredHeight;
    private int panelVgap;
    private int panelHgap;
    
    /**
     * Creates a parameters layout with a default of one column per component,
     * in a single row and without gaps.
     */
    public ParametersLayout() {
	this(1, 0, 0, 0, 0, 0);
    }

    /**
     * Creates a parameters layout with the specified number of rows and 
     * columns. All components in the layout are given equal size. 
     * <p>
     * One, but not both, of <code>rows</code> and <code>cols</code> can 
     * be zero, which means that any number of objects can be placed in a 
     * row or in a column. 
     * @param     rows   the rows, with the value zero meaning 
     *                   any number of rows.
     * @param     cols   the columns, with the value zero meaning 
     *                   any number of columns.
     */
    public ParametersLayout(int rows, int cols) {
	this(rows, cols, 0, 0, 0, 0);
    }

    /**
     * Creates a parameters layout with the specified number of rows and 
     * columns. All components in the layout are given equal size. 
     * <p>
     * In addition, the horizontal and vertical gaps are set to the 
     * specified values. Horizontal gaps are placed between each
     * of the columns. Vertical gaps are placed between each of
     * the rows. 
     * <p>
     * Also gaps between objects and border are set. Phgap is gap 
     * between objects and top border and pvgap is distance between
     * objects and left/right border of container.
     * <p>
     * One, but not both, of <code>rows</code> and <code>cols</code> can 
     * be zero, which means that any number of objects can be placed in a 
     * row or in a column. 
     * <p>
     * All <code>parametersLayout</code> constructors defer to this one.
     * @param     rows   the rows, with the value zero meaning 
     *                   any number of rows
     * @param     cols   the columns, with the value zero meaning 
     *                   any number of columns
     * @param     hgap   the horizontal gap
     * @param     vgap   the vertical gap
     * @param     phgap  the horizontal gap between objects and border
     * @param     pvgap  the vertical gap between objects and border    
     * @exception   IllegalArgumentException  if the value of both
     *			<code>rows</code> and <code>cols</code> is 
     *			set to zero
     */
    public ParametersLayout(int rows, int cols, int hgap, int vgap, 
                                                int phgap, int pvgap) {
	super(rows, cols, hgap, vgap);
        initializePhase = true;
        panelHgap = phgap;
        panelVgap = pvgap;
    }
    
    
    /** 
     * Lays out the specified container using this layout. 
     * <p>
     * This method reshapes the components in the specified target 
     * container in order to satisfy the constraints of the 
     * <code>ParametersLayout</code> object. 
     * <p>
     * The parameters layout manager determines the size of individual 
     * components by dividing the free space in the container into 
     * equal-sized portions according to the number of rows and columns 
     * in the layout. The container's free space equals the container's 
     * size minus any insets and any specified horizontal or vertical 
     * gap. All components in a grid layout are given the same size. 
     *  
     * @param      parent   the container in which to do the layout
     * @see        java.awt.Container
     * @see        java.awt.Container#doLayout
     */
    @Override
    public void layoutContainer(Container parent) {
      synchronized (parent.getTreeLock()) {
	Insets insets = parent.getInsets();
	int ncomponents = parent.getComponentCount();
	int nrows = getRows();
	int ncols = getColumns();
	boolean ltr = parent.getComponentOrientation().isLeftToRight();

	if (ncomponents == 0) {
	    return;
	}
	if (nrows > 0) {
	    ncols = (ncomponents + nrows - 1) / nrows;
	} else {
	    nrows = (ncomponents + ncols - 1) / ncols;
	}
	int w = parent.getWidth() - (insets.left + insets.right + 2*panelHgap);
	int h = parent.getHeight();
	w = (w - (ncols - 1) * getHgap()) / ncols;
	h = (h - (nrows - 1) * getVgap()) / nrows;

        if (initializePhase) {
            preferredHeight = h;
            initializePhase = false;
        } else {
            h = preferredHeight;
        }
        
	if (ltr) {
	    for (int c = 0, x = insets.left + panelHgap; c < ncols ; c++, x += w + getHgap()) {
		for (int r = 0, y = insets.top ; r < nrows ; r++, y += h + getVgap()) {
		    int i = r * ncols + c;
		    if (i < ncomponents) {
			parent.getComponent(i).setBounds(x, y, w, h);
		    }
		}
	    }
	} else {
	    for (int c = 0, x = parent.getWidth() - insets.right - w - panelHgap; c < ncols ; c++, x -= w + getHgap()) {
		for (int r = 0, y = insets.top + panelVgap; r < nrows ; r++, y += h + getVgap()) {
		    int i = r * ncols + c;
		    if (i < ncomponents) {
			parent.getComponent(i).setBounds(x, y, w, h);
		    }
		}
	    }
	}
      }
    }

}