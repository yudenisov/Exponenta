/*
 *    Virtual Steganographic Laboratory (VSL)
 *    Copyright (C) 2008-2011  M. Wegrzyn <bend-up@users.sourceforge.net>

 *    This file is part of Virtual Steganographic Laboratory (VSL).

 *    VSL is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.

 *    VSL is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.

 *    You should have received a copy of the GNU General Public License
 *    along with VSL.  If not, see <http://www.gnu.org/licenses/>.
 */
package pl.edu.zut.wi.vsl.app.gui;

import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Paint;
import javax.swing.JComponent;
import javax.swing.JLabel;
import pl.edu.zut.wi.vsl.app.Main;
import pl.edu.zut.wi.vsl.app.utils.FileUtil;

/**
 * The UI used to control the drawing of the <code>DeskItem</code> 
 * without having to conditionalize the paint operations.
 * 
 * @author Michal Wegrzyn
 */
public class DeskItemUI extends com.sun.java.swing.plaf.windows.WindowsLabelUI {
    /**
     * The ComponentUI used for normal rendering.
     */
    public static final DeskItemUI UI_NORMAL;
    /**
     * The ComponentUI used for active rendering (hover).
     */
    public static final DeskItemUI UI_ACTIVE;
    /**
     * The ComponentUI used for selected state.
     */
    public static final DeskItemUI UI_SELECTED;
    /**
     * The ComponentUI used for selected and active rendering (hover).
     */
    public static final DeskItemUI UI_SELECTED_ACTIVE;

    public static final DeskItemUI UI_CANNOT_CONNECT;
    /**
     * The color of the background.
     */
    private Color col;

    static {
        Color no = FileUtil.colorFromCsv(
                Main.getProperty("vsl.modules.color.normal", "180, 255, 210"));
        Color normalColor = no == null ? new Color(180, 255, 210) : no;
        Color ac = FileUtil.colorFromCsv(
                Main.getProperty("vsl.modules.color.active", "255, 205, 215"));
        Color activeColor = ac == null ? new Color(255, 205, 215) : ac;
        Color se = FileUtil.colorFromCsv(
                Main.getProperty("vsl.modules.color.selected", "230, 230, 255"));
        Color selectedColor = se == null ? new Color(230, 230, 255) : se;
        Color sa = FileUtil.colorFromCsv(
                Main.getProperty("vsl.modules.color.selectedActive", 
                                                            "180, 180, 255"));
        Color selectedActiveColor = sa == null ? new Color(180, 180, 255) : sa;
        Color cc = FileUtil.colorFromCsv(
                Main.getProperty("vsl.modules.color.cannotConnect", 
                                                            "177, 177, 177"));
        Color cannotConnectColor = cc == null ? new Color(177, 177, 177) : cc;
        
        UI_NORMAL = new DeskItemUI(normalColor);
        UI_ACTIVE = new DeskItemUI(activeColor);
        UI_SELECTED = new DeskItemUI(selectedColor);
        UI_SELECTED_ACTIVE = new DeskItemUI(selectedActiveColor);
        UI_CANNOT_CONNECT = new DeskItemUI(cannotConnectColor);
    }
    
    /**
     * Constructs an instance with the default coloring using 
     * the default background color associated with the look and feel.
     */
    public DeskItemUI() {
        col = new JLabel().getBackground();
    }

    /**
     * Constructs and instance using the passed color for the background.
     * @param c The color to use for the background painting operations.
     */
    public DeskItemUI(final Color c) {
        col = c;
    }

    /**
     * Called to perform the paint operation on the passed component.
     * @param g The graphics context for the paint operation.
     * @param c The component to paint into the graphics environment.
     */
    @Override
    public void update(final Graphics g, final JComponent c) {
        Graphics2D g2 = (Graphics2D) g;
        if (!DeskItem.hasGradients()) {
            super.update(g, c);
            return;
        }
        if (c.isOpaque()) {
            final Paint pt = g2.getPaint();
            g2.setPaint(new GradientPaint(c.getWidth(), 0, col.darker(),
                    c.getWidth(), c.getHeight(), col));
            g.fillRoundRect(0, 0, c.getWidth(), c.getHeight(), 5, 5);
            g2.setPaint(pt);
        }
        super.paint(g, c);
    }
}
