/*
 *    Virtual Steganographic Laboratory (VSL)
 *    Copyright (C) 2008-2011  M. Wegrzyn <bend-up@users.sourceforge.net>

 *    This file is part of Virtual Steganographic Laboratory (VSL).

 *    VSL is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.

 *    VSL is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.

 *    You should have received a copy of the GNU General Public License
 *    along with VSL.  If not, see <http://www.gnu.org/licenses/>.
 */
package pl.edu.zut.wi.vsl.app.gui.panels;

import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileNotFoundException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.JComponent;
import javax.swing.JFileChooser;
import javax.swing.KeyStroke;
import eu.medsea.mimeutil.MimeUtil;
import java.util.Locale;
import org.apache.log4j.Logger;
import pl.edu.zut.wi.vsl.app.utils.VslUtil;
import pl.edu.zut.wi.vsl.commons.Message;

/**
 * Panel for choosing object to hide with steganographic module.
 * 
 * @author Michal Wegrzyn
 */
public class MessagePanel extends javax.swing.JPanel {

    public static final String PREFERRED_TITLE = "VSL - choose object to hide";
    private final static Logger logger = Logger.getLogger(MessagePanel.class);
    private File selectedFile;
    private Message stegoMessage;

    /**
     * Creates new form MessagePanel.
     * @param path Filepath to the file that was choosen before
     * or null if object was not choosen before at all.
     */
    public MessagePanel(String path) {
        initComponents();
        if (path != null) {
            if (selectedFile == null) {
                selectedFile = new File(path);
            }
            initFields(path);
        }
        KeyStroke chooseKeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_INSERT, 
                                                                    0, false);
        Action deleteAction = new AbstractAction() {
            // insert opens file chooser
            public void actionPerformed(ActionEvent e) {
                chooseFile();
            }
        };
        getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(chooseKeyStroke, 
                                                                    "INSERT");
        getActionMap().put("INSERT", deleteAction);
        logger.trace("Message Panel initialized.");
    }

    /**
     * Getter for contained message to hide.
     * @return stego message 
     */
    public Message getMessage() {
        return stegoMessage;
    }

    /**
     * Inits fields of this panel. 
     * @param path Filepath to choosen file
     */
    private void initFields(String path) {
        try {
            stegoMessage = new Message(path);
            long size = stegoMessage.getSize();
            sizeField.setText(String.valueOf((float) 
                                                Math.round(10.0*size/1024)/10) +
                                                " KB (" + size + " bytes)");
            filepathField.setText(path);
            // set MIME type using mime-util (magic numbers)
            mimeField.setText(
                            MimeUtil.getMimeTypes(selectedFile).toString());
            filetypeField.setText(new JFileChooser().getTypeDescription(
                                                                selectedFile));
            String date = new SimpleDateFormat("EEE, d MMM yyyy HH:mm z",
                    Locale.getDefault()).format(
                    new Date(selectedFile.lastModified()));
            modifiedField.setText(date);

        } catch (FileNotFoundException e) {
            String msg = "Could not find choosen file.";
            logger.error(msg, e);
            VslUtil.showError(getTopLevelAncestor(), msg, e);
        } catch (Exception e) {
            String msg = "Error occured during creation of" +
                    " stego-message from a choosen file.";
            logger.error(msg, e);
            VslUtil.showError(getTopLevelAncestor(), msg, e);
        }
    }

    /**
     * Handles choosing file that user wants to hide.
     */
    private void chooseFile() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
        fileChooser.setDialogTitle(PREFERRED_TITLE);
        fileChooser.setFileHidingEnabled(false);
        fileChooser.setMultiSelectionEnabled(false);
        int returnValue = fileChooser.showOpenDialog(getTopLevelAncestor());
        if (returnValue == JFileChooser.APPROVE_OPTION) {
            if (selectedFile != fileChooser.getSelectedFile()) {
                selectedFile = fileChooser.getSelectedFile();
                logger.info("Chosen file: " + selectedFile);
                String path = selectedFile.getAbsolutePath();
                initFields(path);
            }
        }
    }

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        filepathLabel = new javax.swing.JLabel();
        filepathField = new javax.swing.JTextField();
        chooseFileButton = new javax.swing.JButton();
        infoPanel = new javax.swing.JPanel();
        sizeLabel = new javax.swing.JLabel();
        sizeField = new javax.swing.JTextField();
        mimeLabel = new javax.swing.JLabel();
        mimeField = new javax.swing.JTextField();
        filetypeLabel = new javax.swing.JLabel();
        filetypeField = new javax.swing.JTextField();
        modifiedLabel = new javax.swing.JLabel();
        modifiedField = new javax.swing.JTextField();
        infoPanelLabel = new javax.swing.JLabel();

        filepathLabel.setText("Message:");
        filepathLabel.setToolTipText("File that you would like to hide");

        filepathField.setEditable(false);
        filepathField.setToolTipText("Path to the object that you want to hide");

        chooseFileButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pl/edu/zut/wi/vsl/app/gui/icons/fileopen22x22.png"))); // NOI18N
        chooseFileButton.setToolTipText("Choose file to hide (Ins)");
        chooseFileButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chooseFileButtonActionPerformed(evt);
            }
        });

        sizeLabel.setText("Size:");
        sizeLabel.setToolTipText("Size of the selected file");

        sizeField.setEditable(false);
        sizeField.setToolTipText("Size of the choosen file");

        mimeLabel.setText("MIME type:");
        mimeLabel.setToolTipText("MIME type");

        mimeField.setEditable(false);
        mimeField.setToolTipText("MIME type of the selected file");

        filetypeLabel.setText("File type:");
        filetypeLabel.setToolTipText("File type");

        filetypeField.setEditable(false);
        filetypeField.setToolTipText("File type description");

        modifiedLabel.setText("Modified:");
        modifiedLabel.setToolTipText("When file was modified");

        modifiedField.setEditable(false);
        modifiedField.setToolTipText("Date of the last modification");

        javax.swing.GroupLayout infoPanelLayout = new javax.swing.GroupLayout(infoPanel);
        infoPanel.setLayout(infoPanelLayout);
        infoPanelLayout.setHorizontalGroup(
            infoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(infoPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(infoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(mimeLabel)
                    .addComponent(modifiedLabel)
                    .addComponent(filetypeLabel)
                    .addComponent(sizeLabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(infoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(mimeField, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(filetypeField, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 257, Short.MAX_VALUE)
                    .addComponent(sizeField, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(modifiedField, javax.swing.GroupLayout.Alignment.TRAILING))
                .addContainerGap(49, Short.MAX_VALUE))
        );
        infoPanelLayout.setVerticalGroup(
            infoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(infoPanelLayout.createSequentialGroup()
                .addGroup(infoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(sizeLabel)
                    .addComponent(sizeField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(infoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(infoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(filetypeField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(filetypeLabel))
                    .addGroup(infoPanelLayout.createSequentialGroup()
                        .addGap(31, 31, 31)
                        .addGroup(infoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(mimeLabel)
                            .addComponent(mimeField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(infoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(modifiedLabel)
                    .addComponent(modifiedField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        infoPanelLabel.setText("Properties:");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(infoPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(filepathLabel)
                            .addComponent(infoPanelLabel))
                        .addGap(18, 18, 18)
                        .addComponent(filepathField, javax.swing.GroupLayout.DEFAULT_SIZE, 260, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(chooseFileButton)
                        .addGap(6, 6, 6)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(filepathLabel)
                            .addComponent(filepathField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(infoPanelLabel))
                    .addComponent(chooseFileButton))
                .addGap(15, 15, 15)
                .addComponent(infoPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
    }// </editor-fold>//GEN-END:initComponents

    /**
     * Opens FileChooser to select file to hide.
     * @param evt
     */
private void chooseFileButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chooseFileButtonActionPerformed
    chooseFile();
}//GEN-LAST:event_chooseFileButtonActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton chooseFileButton;
    private javax.swing.JTextField filepathField;
    private javax.swing.JLabel filepathLabel;
    private javax.swing.JTextField filetypeField;
    private javax.swing.JLabel filetypeLabel;
    private javax.swing.JPanel infoPanel;
    private javax.swing.JLabel infoPanelLabel;
    private javax.swing.JTextField mimeField;
    private javax.swing.JLabel mimeLabel;
    private javax.swing.JTextField modifiedField;
    private javax.swing.JLabel modifiedLabel;
    private javax.swing.JTextField sizeField;
    private javax.swing.JLabel sizeLabel;
    // End of variables declaration//GEN-END:variables
}
