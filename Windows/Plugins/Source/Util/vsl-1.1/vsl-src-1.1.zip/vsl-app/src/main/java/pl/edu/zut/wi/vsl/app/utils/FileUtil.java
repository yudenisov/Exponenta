/*
 *    Virtual Steganographic Laboratory (VSL)
 *    Copyright (C) 2008-2011  M. Wegrzyn <bend-up@users.sourceforge.net>

 *    This file is part of Virtual Steganographic Laboratory (VSL).

 *    VSL is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.

 *    VSL is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.

 *    You should have received a copy of the GNU General Public License
 *    along with VSL.  If not, see <http://www.gnu.org/licenses/>.
 */
package pl.edu.zut.wi.vsl.app.utils;

import au.com.bytecode.opencsv.CSVWriter;
import java.awt.Color;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URISyntaxException;
import java.util.Arrays;
import java.util.Collection;
import java.util.Properties;
import java.util.StringTokenizer;
import java.util.ArrayList;
import javax.imageio.ImageIO;
import org.apache.log4j.Logger;
import pl.edu.zut.wi.vsl.app.Main;
import pl.edu.zut.wi.vsl.commons.Message;
import pl.edu.zut.wi.vsl.commons.StegoImage;

/**
 * Utility for performing all file related operations.
 * 
 * @author Michal Wegrzyn
 */
public class FileUtil {

    private static volatile FileUtil INSTANCE;
    
    private final static Logger logger = Logger.getLogger(FileUtil.class);
    /* Application's output results directory. */
    private static String outputDirectory;

    protected FileUtil() { }
    
     private static synchronized FileUtil tryCreateInstance() {
     if (INSTANCE == null) {
       INSTANCE = new FileUtil();
     }
     return INSTANCE;
   }
 
   public static FileUtil getInstance() {
      // use local variable, don't issue 2 reads (memory fences) to 'INSTANCE'
      FileUtil s = INSTANCE;
      if (s == null) {
        /* check under lock; 
         * move creation logic to a separate method to allow 
         * inlining of getInstance() */
        s = tryCreateInstance();
      }
      return s;
   }

    /**
     * Checks if file can be loaded as an image.
     * 
     * @param filename
     * @return boolean true - file can be loaded<br/>
     * false - file can not be loaded
     */
    public static boolean checkIsFormatHandled(String filename) {
        String format = getFileFormat(filename);
        if (format == null) {
            return false;
        }
        String[] imageSuffixes = ImageIO.getReaderFileSuffixes();
        for (String suffix : imageSuffixes) {
            if (suffix.equals(format.toLowerCase())) {
                return true;
            }
        }
        return false;
    }
    
    /**
     * Checks if directory exist and if not - creates it along with 
     * subdirectories.
     * @param destDir Directory to check
     * @return <code>true</code> if directory exists or was successfully 
     * created, otherwise <code>false</code>
     */
    public static boolean createOutputDir(File destDir) {
        boolean created = false;
        if (!destDir.exists()) {
            if (!destDir.mkdirs()) {
                destDir = new File(getOutputDirectory());
                if (!destDir.exists()) {
                    created = destDir.mkdirs();
                }
            } else {
                created = true;
            }
        } else {
            created = true;
        }
        
        return created;
    }

    /**
     * Returns directory of the given file.
     * @param filename Name of file which directory should be returned
     * @return String representation of path to directory which contains 
     * given file.
     */
    public static String getDirectory(String filename) {
        if (filename == null) {
            return null;
        }
        if (new File(filename).isDirectory()) {
            return filename;
        }
        
        int endIndex = filename.lastIndexOf(File.separatorChar);

        if (endIndex > 0) {
            return filename.substring(0, endIndex);
        } else {
            return "";
        }
    }

    /**
     * Return format of given file
     * @param filename 
     * @return format of given file. <br/>
     *         null if file does not have specified format
     */
    public static String getFileFormat(String filename) {
        if (filename == null) {
            return null;
        }
        String format = null;
        int beginIndex = filename.lastIndexOf('.');
        if (beginIndex > 0) {
            format = filename.substring(beginIndex + 1, filename.length());
        }
        return format;
    }

    /**
     * Return full format of given file.
     * @param filename 
     * @return format of given file. <br/>
     *         null if file does not have specified format
     */
    public static String getFullFileFormat(String filename) {
        if (filename == null) {
            return null;
        }
        String format = null;
        int beginIndex = filename.indexOf('.');
        if (beginIndex > 0) {
            format = filename.substring(beginIndex + 1, filename.length());
        }
        return format;
    }
   
    /**
     * Gives name of file without its format.
     * @param name - Name of the file
     * @return name without file format
     */
    public static String getFileNameWithoutFormat(String name) {
        int idx = name.lastIndexOf(".");
        if (idx < 0) {
            return name;
        } else {
            return name.substring(0, idx);
        }
    }
    
    /**
     * Returns unique filename for a file based on given filename. 
     * If file with such filepath exists already, then filepath with similar 
     * filename (with appriopriate number) is returned.
     * @param filepath Absolute filepath to a file that needs to be saved.
     * @return filepath with filename that does not exist in destination
     * directory
     */
    public static String getUniqueFilename(String filepath) {
        String outDirectory = getDirectory(filepath);
        String name = getFileName(filepath);
        String outputName = getFileNameWithoutFormat(name);
        String format = getFileFormat(name);
        
        File tmp = "".equals(outDirectory) 
                    ? new File (name) 
                    : new File(outDirectory + File.separator + name);
        // make sure that file with the same name does not exists
        int i = 1;
        while (tmp.exists()) {
            tmp =  "".equals(outDirectory) 
                    ? new File (outputName + "_("+i+")" + 
                                    (format == null ? "" : "." + format)) 
                    : new File(outDirectory + File.separator + outputName +
                        "_(" + i + ")" + (format == null ? "" : "." + format));
            i++;
        }
        
        return tmp.getAbsolutePath();
    }    

    /**
     * Return path to current directory.
     * @return String with working directory.
     */
    public static String getCurrentDir() {
        return System.getProperty("user.dir");
    }

    /**
     * Mounts current working directory to path where is application located.
     * <p>
     * It is needed in case when user starts application simply clicking 
     * on it (not from the console) - in some systems Java'as system 
     * property can be different from current jar path.
     * @throws java.net.URISyntaxException
     */
    public static void mountCurrentDir() throws URISyntaxException {
        File jarFile = new File(
                pl.edu.zut.wi.vsl.app.Main.class.getProtectionDomain().
                getCodeSource().getLocation().toURI());
        String jarDir = FileUtil.getDirectory(jarFile.getAbsolutePath());
        logger.debug("mounting user.dir to: " + jarDir);
        System.getProperties().setProperty("user.dir", jarDir);
    }

    /**
     * Reads properties from three locations:
     * 1) given path
     * 2) user.home
     * 3) current directory
     * Every existing next property file overides previous ones.
     * @param resourceName the location of the resource that should be
     * loaded. 
     * @return the Properties
     * @exception Exception if no default properties are defined, or if
     * an error occurs reading the properties files.  
     */
    public static Properties readProperties(String resourceName) throws 
            FileNotFoundException, IOException {

        Properties defaultProps = new Properties();
        try {
            FileInputStream is = new FileInputStream(resourceName);
            defaultProps.load(is);
            is.close();
        } catch (IOException e) {
            String msg = "Error during loading properties file: " + 
                    resourceName;
            logger.warn(msg, e);
            VslUtil.showWarn(null, msg);
        }
        
        /* if variable is directory, get file name */
        resourceName = getFileName(resourceName);
        /* if properties exists in home directory, 
         * they will override given properties */
        Properties userProps = new Properties(defaultProps);
        File propFile = new File(System.getProperties().getProperty("user.home")
                + File.separatorChar + resourceName);
        if (propFile.exists()) {
                FileInputStream is = new FileInputStream(propFile);
                userProps.load(is);
                is.close();
        }

        /* if properties exists in the current directory 
         * they will override last properties */
        final Properties localProps = new Properties(userProps);
        propFile = new File(resourceName);
        if (propFile.exists()) {
                localProps.load(new FileInputStream(propFile));
        }
        return localProps;
    }

    /**
     * Returns file name from given path.
     * @param path - path to the filename
     * @return - filename
     */
    public static String getFileName(String path) {
        int slInd = path.lastIndexOf(File.separator);
        if (slInd != -1) {
            return path.substring(slInd + 1);
        } else {
            return path;
        }
    }

    /**
     * Sets given directory as VSL's output directory.
     * @param defaultOutputDir Filepath to 
     */
    public static void setOutputDirectory(String defaultOutputDir) {
        outputDirectory = defaultOutputDir;
    }
    
    /**
     * Returns String representation of the application's output
     * results directory.
     * @return String with filepath to results directory.
     */
    public static String getOutputDirectory() {
        return outputDirectory;
    }
    
    /**
     * Marks all files (besides *.jar and *.*log*) in given directory 
     * that has been created between time1 and time2 as temporary files.
     * @param srcDir Directory in which files should be marked as temporary
     * @param time1 Time above which should be modification time of files
     * that will be marked
     * @param time2 Time below which should be modofication time of files
     * that will be marked
     */
    public static synchronized void markNewFilesAsTemp(File srcDir, long time1, 
            long time2) {
        if (!srcDir.isDirectory()) {
            throw new IllegalArgumentException("Given file should be a proper " +
                    "directory: " +
                    srcDir.getAbsolutePath());
        }

        File[] srcFiles = srcDir.listFiles();

        boolean allRenamed = true;
        for (int i = 0; i < srcFiles.length; i++) {

            // File (or directory) to be renamed
            File file = srcFiles[i];
            if (!file.isDirectory() &&
                    file.lastModified() + 1000 >= time1 &&
                    file.lastModified() <= time2) {

                String format = getFullFileFormat(file.getAbsolutePath());

                if (format == null ||
                        (!format.equals("jar") && !format.contains("log")
                            && !format.contains("tmp"))) {
                    String filename = 
                            getUniqueFilename(file.getAbsolutePath() + ".tmp");
                    File tmp = new File(filename);
                    
                    if (file.exists()) {
                        boolean success = file.renameTo(new File(srcDir,
                                                        tmp.getName()));
                        if (!success) {
                            allRenamed = false;
                        }
                    }
                }
            }
        }

        if (!allRenamed) {
            VslUtil.showWarn(null, "Some files created by module were not " +
                    "renamed to *.tmp.\nPlease check java output directory:\n" +
                    srcDir.getAbsolutePath());
        }
        
    }
    
    /**
     * Moves all temporary files from source to destination directory.
     * @param srcDir Source directory with files to move
     * @param destDir Destination directory. Place where files from source
     * directory should be moved.
     */
    public static void moveResultFiles(long startTime, long endTime, 
                                            File srcDir, File destDir) {

        File[] srcFiles = srcDir.listFiles();
        boolean toMovePresent = false;
        for (int i = 0; i < srcFiles.length; i++) {
            
            File f = srcFiles[i];
            if (f.isFile()) {
                long modTime = f.lastModified();
                String format = getFullFileFormat(f.getAbsolutePath());
                if (modTime > startTime - 999 && modTime < endTime + 999
                        && (format == null || !format.contains("log"))) {
                    toMovePresent = true;
                }
            }
        }
        
        if (!toMovePresent) {
            return;
        }
        
        if (!createOutputDir(destDir)) {
            VslUtil.showError(null, "Could not create destination " +
                                    "directory");
            return;
        }
       
        if (!srcDir.isDirectory() || !destDir.isDirectory()) {
            throw new IllegalArgumentException("Given files should be proper " +
                    "directories" +
                    srcDir.getAbsolutePath() + ", " +
                    destDir.getAbsolutePath());
        }
        
        
        boolean allMoved = true;
        for (int i = 0; i < srcFiles.length; i++) {

            // File (or directory) to be moved
            File file = srcFiles[i];
            if (!file.isDirectory()) {

                String format = getFullFileFormat(file.getAbsolutePath());

                long modTime = file.lastModified();
                if (modTime > startTime - 999 && modTime < endTime + 999
                        && (format == null || !format.contains("log"))) {

                    
                    String outputName = FileUtil.getFileNameWithoutFormat(
                            file.getName());
                    format = getFileFormat(file.getName());
                    outputName = FileUtil.getFileNameWithoutFormat(
                            outputName);
                    
                    String name = format == null 
                            ? outputName 
                            : outputName + "." + format;
                    String filename = 
                            getUniqueFilename(destDir + File.separator + name);
                    // make sure that file with the same name does not exists
                    File tmp = new File(filename);
                    
                    // Move file to new directory
                    final boolean success = file.renameTo(new File(destDir,
                                                    tmp.getName()));
                    if (!success) {
                        allMoved = false;
                    }
                }
            }
        }

        if (!allMoved) {
            VslUtil.showWarn(null, "Some files created by module were not " +
                    "moved to result " +
                    "directory.\nPlease check java output directory:\n" +
                    srcDir.getAbsolutePath());
        }
    }

    /**
     * Reads color from comma separated RGB values.
     * @param col - Color in CSV format e.g. "255,0,0"
     * @return color variable
     */
    public static Color colorFromCsv(String col) {
        int[] c;
        StringTokenizer st = new StringTokenizer(col, ",");
        if (st.countTokens() != 3) {
            return null;
        } else {
            c = new int[3];
            for (int i = 0; i < 3; i++) {
                int tmp;
                String token = st.nextToken().trim();
                try {
                    tmp = Integer.parseInt(token);
                } catch (NumberFormatException e) {
                    logger.warn("Could not parse component value: " + token, e);
                    tmp = 255;
                }
                tmp = tmp > 255 ? 255 : (tmp < 0 ? 0 : tmp);
                c[i] = tmp;
            }
        }
        return new Color(c[0], c[1], c[2]);
    }


    /**
     * Gets all handled image files from directory as array.
     * @param directory - directory to search
     * @param recurse - search withing subdirectories?
     * @return File[] - array with handled image files
     */
    public static File[] listOfImageFilesAsArray(File directory,
            boolean recurse) {
        Collection<File> files = listOfImageFiles(directory, recurse);

        File[] arr = new File[files.size()];
        return files.toArray(arr);
    }

    /**
     * Gets all hadled image files from directory.
     * @param directory - directory to search
     * @param recurse - search withing subdirectories?
     * @return Collection - handled image files
     */
    public static Collection<File> listOfImageFiles(File directory,
            boolean recurse) {
        // List of files / directories
        ArrayList<File> files = new ArrayList<File>();
        // Get files / directories in the directory
        ArrayList<File> list = new ArrayList<File>();
        list.add(directory);
        while (!list.isEmpty()) {
            File f = list.remove(0);
            if (f != null && f.isDirectory()) {
                File[] filelist = f.listFiles();
                if (filelist != null && filelist.length > 0) {
                    list.addAll(Arrays.asList(filelist));
                }
            } else if (FileUtil.checkIsFormatHandled(f.getName())) {
                files.add(f);
            }
        }
        return files;
    }

    /**
     * Writes message to HDD with given directory and name pattern.
     * @param message - message to write
     * @param outputDirectory - directory in which message should be saved
     * @param outputNamePattern - pattern for filename
     * @param number Number for filename (represents order of saving)
     * @throws java.io.IOException 
     */
    public static void writeMessage(Message message, File outputDirectory,
            String outputNamePattern, int number) throws IOException {
        
        if (!createOutputDir(outputDirectory)) {
            VslUtil.showError(null, "Could not create destination " +
                                    "directory");
            return;
        }

        String format = FileUtil.getFileFormat(outputNamePattern);
        String outputName;

        if (format != null) {
            String cleanName = 
                    FileUtil.getFileNameWithoutFormat(outputNamePattern);
            outputName = cleanName + VslUtil.prependZeros(number, 5) +
                    "." + format;
        } else {
            outputName = outputNamePattern +
                    VslUtil.prependZeros(number, 5);
        }

        String name = outputDirectory + File.separator + outputName;

        String filename = getUniqueFilename(name);
        File tmp = new File(filename);
        
        message.writeBytesToFile(tmp.getAbsolutePath());
    }

    /**
     * Writes image to HDD with given directory and name pattern.
     * @param image - image to write
     * @param outputDirectory - directory in which message should be saved
     * @param outputNamePattern - pattern for filename
     * @param number Number for filename (represents order of saving)
     * @throws java.lang.IllegalArgumentException
     * @throws java.io.IOException
     */
    public static void writeImage(StegoImage image, File outputDirectory,
            String outputName, String format, int number)
            throws IllegalArgumentException,
            IOException {
        
        if (!createOutputDir(outputDirectory)) {
            VslUtil.showError(null, "Could not create destination " +
                                    "directory");
            return;
        }

        outputName = outputName + VslUtil.prependZeros(number, 5);
        String name = outputName + (format == null ? "" : "." + format);

        String filename = 
                getUniqueFilename(outputDirectory + File.separator + name);
        File tmp = new File(filename);
        
        image.write(tmp.getAbsolutePath());
    }

    /**
     * Writes report to HDD with given directory and name pattern.
     * @param content Content of the report to write
     * @param outputDirectory directory in which report should be saved
     * @param outputNamePattern pattern for filename
     * @param number Number for filename (represents order of saving)
     * @throws java.lang.IllegalArgumentException
     * @throws java.io.IOException
     */
    public static void writeReport(ArrayList<String[]> content, File outputDirectory,
            String outputName, int number) throws IllegalArgumentException,
            IOException {
        if (!createOutputDir(outputDirectory)) {
            VslUtil.showError(null, "Could not create destination " +
                                    "directory");
            return;
        }
                
        outputName = outputName + VslUtil.prependZeros(number, 5);
        String format = Main.getProperty("vsl.report.extension", "csv");
        String separator = Main.getProperty("vsl.report.separator",
                String.valueOf(
                CSVWriter.DEFAULT_SEPARATOR));
        String name = outputName + (format == null ? "" : "." + format);
        String filename = 
                getUniqueFilename(outputDirectory + File.separator + name);
        File tmp = new File(filename);
        
        CSVWriter writer = new CSVWriter(new FileWriter(tmp),
                separator.charAt(0));
        for (int it = 0; it < content.size(); it++) {
            writer.writeNext(content.get(it));
        }
        writer.close();
    }
}
