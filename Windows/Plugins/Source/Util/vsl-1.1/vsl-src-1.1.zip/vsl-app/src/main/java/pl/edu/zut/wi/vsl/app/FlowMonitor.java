/*
 *    Virtual Steganographic Laboratory (VSL)
 *    Copyright (C) 2008-2011  M. Wegrzyn <bend-up@users.sourceforge.net>

 *    This file is part of Virtual Steganographic Laboratory (VSL).

 *    VSL is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.

 *    VSL is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.

 *    You should have received a copy of the GNU General Public License
 *    along with VSL.  If not, see <http://www.gnu.org/licenses/>.
 */
package pl.edu.zut.wi.vsl.app;

import java.util.ArrayList;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.apache.log4j.Logger;

/**
 * Thread waiting until all instances of <code>Flow</code>
 * perform their operations.
 * <p>
 * When their are done, executes function in <code>MainWindow</code> 
 * that finishes execution.
 * 
 * @author Michal Wegrzyn
 */
public class FlowMonitor extends Thread {

    private final static Logger logger = Logger.getLogger(
                                                FlowMonitor.class);
    private final CountDownLatch cdl;
    /** ArrayList with threads for every Input */
    private final ArrayList<Flow> flows;
    /** Thread pool */
    private final ExecutorService pool;
    /** Object for locking */
    private final Object lock = new Object();
    /** Reference to main window */
    private final MainWindow window;
    /** Base subdirectory of experiment that consists of among others this
     * <code>Flow</code> */
    private final String baseDirectory;
    /** Total number of executions from all instances of
     * <code>Flow</code> in current experiment.
     */
    private int executionsTotalNumber;
    /** Number of all execution finished so far within all instances
     * of <code>Flow</code>.
     */
    private int executedNumber;
    /** Start time of the experiment */
    private long startTime;
    
    /**
     * Creates FlowMonitor instance.
     * @param parentWindow - reference to MainWindow
     * @param poolSize - number of ProcessThreads to monitor
     */
    public FlowMonitor(MainWindow window, int poolSize, String baseDirectory) {
        setDaemon(true);
        this.window = window;
        this.baseDirectory = baseDirectory;
        
        cdl = new CountDownLatch(poolSize);
        pool = Executors.newFixedThreadPool(poolSize);
        flows = new ArrayList<Flow>();

        executedNumber = 0;
        executionsTotalNumber = 0;
        startTime = System.currentTimeMillis();
    }

    @Override
    public void run() {
        try {
            cdl.await();
        } catch (InterruptedException e) {
            logger.info("Requested experiment stop");
        }
        logger.info("Stopping all threads, ending experiment");

        stopThreads();
        window.endExperiment();
    }
    
    /**
     * Returns CountDownLatch for monitor ProcessThreads.
     * @return CountDownLatch
     */
    public CountDownLatch getCountDownLatch() {
        return cdl;
    }

    public void startThreads() {
        for (int i =0; i < flows.size(); ++i) {
            pool.submit(flows.get(i));
        }
        start();
    }
    
    private void stopThreads() {
        
        for (int i =0; i < flows.size(); ++i) {
            flows.get(i).stopProcess();
        }
        //wait for threads
        try {
            cdl.await();
        } catch (InterruptedException e) {
            logger.info("Interrupted waiting for threads, exiting");
        }
    }

    public void add(Flow flow) {
        executionsTotalNumber += flow.countExecutions();
        flows.add(flow);
    }

    public MainWindow getWindow() {
        return window;
    }

    public void countDown() {
        cdl.countDown();
    }

    /**
     * Returns main subdirectory of all <code>Flow</code> instances.
     * @return Main output directory for all threads.
     */
    public String getBaseDirectory() {
        return baseDirectory;
    }

    public int getTotalExecutions() {
        return executionsTotalNumber;
    }

    /**
     * Increments number of executions and updates progress bar.
     * @return number of executions performed so far
     */
    public void incrementExecuted() {
        synchronized (lock) {
            ++executedNumber;
        }
        // update progress bar
        float progress = 100 * ((float) executedNumber) / getTotalExecutions();
        window.getProgressBar().setValue((int) progress);
        window.getProgressBar().setToolTipText(executedNumber +
                " / " + getTotalExecutions());
    }

    /**
     * Gets start time of an experiment.
     * @return Long value representing start time of an experiment.
     */
    public long getStartTime() {
        return startTime;
    }

    public void repaintDesktop() {
        window.repaintDesktop();
    }

}
