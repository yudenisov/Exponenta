/*
 *    Virtual Steganographic Laboratory (VSL)
 *    Copyright (C) 2008-2011  M. Wegrzyn <bend-up@users.sourceforge.net>

 *    This file is part of Virtual Steganographic Laboratory (VSL).

 *    VSL is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.

 *    VSL is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.

 *    You should have received a copy of the GNU General Public License
 *    along with VSL.  If not, see <http://www.gnu.org/licenses/>.
 */
package pl.edu.zut.wi.vsl.app.gui.panels;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.ArrayList;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import org.apache.log4j.Logger;
import pl.edu.zut.wi.vsl.app.Main;
import pl.edu.zut.wi.vsl.app.MainWindow;
import pl.edu.zut.wi.vsl.app.utils.VslUtil;
import pl.edu.zut.wi.vsl.commons.StegoImage;

/**
 * Tool for displaying images captured in specific place of the experiment flow.
 * 
 * @author Michal Wegrzyn
 */
public class DisplayWindow extends JFrame implements KeyListener,
                                                     MouseListener {

    private final static Logger logger = Logger.getLogger(DisplayWindow.class);
    /** Panel responsible for displaying content */
    private ImagePanel ip;
    /** Index of currently displayed image */
    private int current;
    /** ArrayList with images that this window should be able to display */
    private final ArrayList<StegoImage> images;
    /** Title for <code>JFileChooser</code> while saving */
    private static final String SAVE_TITLE = "VSL - save image...";
    /** Title for dialog with question for replacing file */
    private static final String REPLACE_TITLE = "VSL - replace file";
    /** Factor by which images are scaled */
    private final float zoomFactor;
    /** Screen size */
    private static Dimension screenSize;

    /**
     * Creates new form DisplayWindow.
     * @param imgs Images that will be displayed by this window.
     */
    public DisplayWindow(ArrayList<StegoImage> imgs) {
        initComponents();
        float zoom = 10;
        try {
            zoom = Float.parseFloat(Main.getProperty("vsl.display.zoom", "10"));
        } catch (NumberFormatException e) {
            logger.error("Could not set zoom factor", e);
            zoom = 10;
        }
        screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        zoomFactor = zoom;
        current = 0;
        images = new ArrayList<StegoImage>();
        images.addAll(imgs);
        changeImage();
        setVisible(true);
        addWindowListener(new WindowAdapter() {

            @Override
            public void windowClosing(WindowEvent e) {
                closeWindow();
            }
        });
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        addKeyListener(this);
        displayScrollPane.addMouseListener(this);
        requestFocus();
        setTitle("VSL - Display");
    }

    private void changeImage() {
        BufferedImage i = images.get(current).getImage();
        ip = new ImagePanel(i);
        Dimension newSize = new Dimension(i.getWidth(), i.getHeight());
        displayScrollPane.setViewportView(ip);
        displayScrollPane.revalidate();
        changeWindowSize(newSize.width, newSize.height);
        numberTextField.setText((current + 1) + "/" + images.size());
    }

    private void closeWindow() {
        dispose();
    }

    private void changeWindowSize(int w, int h) {
        int newWidth = w +
                    displayScrollPane.getInsets().left +
                    displayScrollPane.getInsets().right;
        int newHeight = h +
                    displayToolbar.getHeight() +
                    displayToolbar.getInsets().bottom +
                    displayToolbar.getInsets().top +
                    1 + // gap
                    displayScrollPane.getInsets().top +
                    displayScrollPane.getInsets().bottom;

        Dimension newSize = new Dimension(Math.min(newWidth, screenSize.width),
                                        Math.min(newHeight, screenSize.height));
        getContentPane().setPreferredSize(newSize);
        pack();
        
    }

    /**
     * Switches display to next image.
     */
    private void next() {
        current++;
        if (current > images.size() - 1) {
            current = 0;
        }
        changeImage();
    }

    /**
     * Switches display to previous image.
     */
    private void previous() {
        current--;
        if (current < 0) {
            current = images.size() - 1;
        }
        changeImage();
    }

    /**
     * Enlarges current image.
     */
    private void zoomIn() {
        ip.zoomIn();
    }
    
    /**
     * Minimizes current image.
     */
    private void zoomOut() {
        ip.zoomOut();
    }

    /**
     * Displays informations about current image.
     */
    private void info() {
        StegoImage i = images.get(current);
        JOptionPane.showConfirmDialog(this,
                "Image info:\n\n" +
                "source: " + i.getPath() + "\n" +
                "width: " + i.getWidth() + "\n" +
                "height: " + i.getHeight() + "\n" +
                "number of bands: " + i.getSampleModel().getNumBands() + "\n" +
                "has alpha: " + i.getColorModel().hasAlpha() + "\n",
                "VSL - image info", JOptionPane.DEFAULT_OPTION,
                JOptionPane.INFORMATION_MESSAGE, VslUtil.INFO_ICON);
    }

    /**
     * Saves current image.
     */
    private void save() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
        fileChooser.setDialogTitle(SAVE_TITLE);
        fileChooser.setFileHidingEnabled(false);
        fileChooser.setMultiSelectionEnabled(false);
        fileChooser.setAcceptAllFileFilterUsed(false);
        fileChooser.addChoosableFileFilter(new DisplayImageFilter());
        int returnValue = fileChooser.showSaveDialog(this);
        if (returnValue == JFileChooser.APPROVE_OPTION) {
            File f = fileChooser.getSelectedFile();
            if (f.exists()) {
                int decision = JOptionPane.showConfirmDialog(this,
                        "Do you want to  replace existing file?",
                        REPLACE_TITLE, JOptionPane.YES_NO_OPTION,
                        JOptionPane.QUESTION_MESSAGE, VslUtil.QUESTION_ICON);
                if (decision == JOptionPane.NO_OPTION) {
                    return;
                }
            }
            String path = f.getAbsolutePath();
            try {
                images.get(current).write(path);
            } catch (Exception e) {
                VslUtil.showError(this, "Could not save file.", e);
            }
        }
    }
    
    /**
     * Switches display to image which number was 
     * entered in <code>TextField</code> by user.
     * @param location String value of location <code>TextField</code>
     */
    private void gotoImage(String location) {
        String[] s = location.split("/");
        try {
            int idx = Integer.valueOf(s[0]);
            if (idx < 1 || idx > images.size()) {
                numberTextField.setText((current + 1) + "/" + images.size());
                return;
            }
            current = idx - 1;
            changeImage();
        } catch (NumberFormatException e) {
            logger.warn("Could not parse image number", e);
            numberTextField.setText((current + 1) + "/" + images.size());
        }
    }

    /**
     * Key handling.
     * @param e
     */
    public void keyPressed(KeyEvent e) {
        if (e.getComponent() != numberTextField) {
            switch (e.getKeyCode()) {
                case KeyEvent.VK_SPACE:
                    next();
                    break;
                case KeyEvent.VK_BACK_SPACE:
                    previous();
                    break;
                case KeyEvent.VK_S:
                    if (e.isControlDown()) {
                        save();
                    }
                    break;
                case KeyEvent.VK_PAGE_UP:
                    zoomIn();
                    break;
                case KeyEvent.VK_PAGE_DOWN:
                    zoomOut();
                    break;
                case KeyEvent.VK_I:
                    info();
                    break;
                case KeyEvent.VK_ESCAPE:
                    closeWindow();
                    break;
                case KeyEvent.VK_W:
                    if (e.isControlDown()) {
                        closeWindow();
                    }
                    break;
                default:
                    break;
            }
        } else {
            if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                gotoImage(numberTextField.getText());
            }
        }
    }
    
    public void keyTyped(KeyEvent e) {
    }
    
    public void keyReleased(KeyEvent e) {
    }
    
    public void mouseEntered(MouseEvent e) {
        requestFocus();
    }

    public void mouseClicked(MouseEvent e) {
    }

    public void mousePressed(MouseEvent e) {
    }

    public void mouseReleased(MouseEvent e) {
    }

    public void mouseExited(MouseEvent e) {
    }

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setIconImage(VslUtil.LOGO_ICON.getImage());
        displayScrollPane = new javax.swing.JScrollPane();
        displayScrollPane.getVerticalScrollBar().setUnitIncrement(MainWindow.getDefaultScrollIncrement());
        displayToolbar = new javax.swing.JToolBar();
        jSeparator1 = new javax.swing.JToolBar.Separator();
        saveAsButton = new javax.swing.JButton();
        jSeparator2 = new javax.swing.JToolBar.Separator();
        infoButton = new javax.swing.JButton();
        jSeparator3 = new javax.swing.JToolBar.Separator();
        zoomInButton = new javax.swing.JButton();
        zoomOutButton = new javax.swing.JButton();
        jSeparator4 = new javax.swing.JToolBar.Separator();
        previousButton = new javax.swing.JButton();
        nextButton = new javax.swing.JButton();
        jSeparator5 = new javax.swing.JToolBar.Separator();
        numberTextField = new javax.swing.JTextField();
        numberTextField.addKeyListener(this);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(300, 90));

        displayScrollPane.setBorder(null);
        displayScrollPane.setFocusCycleRoot(true);

        displayToolbar.setBorder(javax.swing.BorderFactory.createEmptyBorder(4, 1, 1, 1));
        displayToolbar.setFloatable(false);
        displayToolbar.setRollover(true);
        displayToolbar.setBorderPainted(false);
        displayToolbar.setMaximumSize(new java.awt.Dimension(32767, 25));
        displayToolbar.setMinimumSize(new java.awt.Dimension(110, 25));
        displayToolbar.add(jSeparator1);

        saveAsButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pl/edu/zut/wi/vsl/app/gui/icons/document-save-as16x16.png"))); // NOI18N
        saveAsButton.setToolTipText("Save As... (CTRL+S)");
        saveAsButton.setFocusable(false);
        saveAsButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        saveAsButton.setPreferredSize(new java.awt.Dimension(29, 29));
        saveAsButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        saveAsButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveAsButtonActionPerformed(evt);
            }
        });
        displayToolbar.add(saveAsButton);
        displayToolbar.add(jSeparator2);

        infoButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pl/edu/zut/wi/vsl/app/gui/icons/info16x16.png"))); // NOI18N
        infoButton.setToolTipText("Image info (I)");
        infoButton.setFocusable(false);
        infoButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        infoButton.setPreferredSize(new java.awt.Dimension(29, 29));
        infoButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        infoButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                infoButtonActionPerformed(evt);
            }
        });
        displayToolbar.add(infoButton);
        displayToolbar.add(jSeparator3);

        zoomInButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pl/edu/zut/wi/vsl/app/gui/icons/zoom-in16x16.png"))); // NOI18N
        zoomInButton.setToolTipText("Zoom In (Page Up)");
        zoomInButton.setFocusable(false);
        zoomInButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        zoomInButton.setPreferredSize(new java.awt.Dimension(29, 29));
        zoomInButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        zoomInButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                zoomInButtonActionPerformed(evt);
            }
        });
        displayToolbar.add(zoomInButton);

        zoomOutButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pl/edu/zut/wi/vsl/app/gui/icons/zoom-out16x16.png"))); // NOI18N
        zoomOutButton.setToolTipText("Zoom Out (Page Down)");
        zoomOutButton.setFocusable(false);
        zoomOutButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        zoomOutButton.setPreferredSize(new java.awt.Dimension(29, 29));
        zoomOutButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        zoomOutButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                zoomOutButtonActionPerformed(evt);
            }
        });
        displayToolbar.add(zoomOutButton);
        displayToolbar.add(jSeparator4);

        previousButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pl/edu/zut/wi/vsl/app/gui/icons/go-previous16x16.png"))); // NOI18N
        previousButton.setToolTipText("Previous (Backspace)");
        previousButton.setFocusable(false);
        previousButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        previousButton.setPreferredSize(new java.awt.Dimension(29, 29));
        previousButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        previousButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                previousButtonActionPerformed(evt);
            }
        });
        displayToolbar.add(previousButton);

        nextButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pl/edu/zut/wi/vsl/app/gui/icons/go-next16x16.png"))); // NOI18N
        nextButton.setToolTipText("Next (Space)");
        nextButton.setFocusable(false);
        nextButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        nextButton.setPreferredSize(new java.awt.Dimension(29, 29));
        nextButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        nextButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nextButtonActionPerformed(evt);
            }
        });
        displayToolbar.add(nextButton);
        displayToolbar.add(jSeparator5);

        numberTextField.setToolTipText("current/total");
        numberTextField.setMaximumSize(new java.awt.Dimension(90, 27));
        numberTextField.setMinimumSize(new java.awt.Dimension(0, 0));
        numberTextField.setPreferredSize(new java.awt.Dimension(90, 27));
        displayToolbar.add(numberTextField);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(displayToolbar, javax.swing.GroupLayout.DEFAULT_SIZE, 462, Short.MAX_VALUE)
            .addComponent(displayScrollPane, javax.swing.GroupLayout.DEFAULT_SIZE, 462, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(displayToolbar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(displayScrollPane, javax.swing.GroupLayout.DEFAULT_SIZE, 274, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

private void nextButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nextButtonActionPerformed
    next();
}//GEN-LAST:event_nextButtonActionPerformed

private void previousButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_previousButtonActionPerformed
    previous();
}//GEN-LAST:event_previousButtonActionPerformed

private void zoomInButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_zoomInButtonActionPerformed
    zoomIn();
}//GEN-LAST:event_zoomInButtonActionPerformed

private void zoomOutButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_zoomOutButtonActionPerformed
    zoomOut();
}//GEN-LAST:event_zoomOutButtonActionPerformed

private void infoButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_infoButtonActionPerformed
    info();
}//GEN-LAST:event_infoButtonActionPerformed

private void saveAsButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveAsButtonActionPerformed
    save();
}//GEN-LAST:event_saveAsButtonActionPerformed
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JScrollPane displayScrollPane;
    private javax.swing.JToolBar displayToolbar;
    private javax.swing.JButton infoButton;
    private javax.swing.JToolBar.Separator jSeparator1;
    private javax.swing.JToolBar.Separator jSeparator2;
    private javax.swing.JToolBar.Separator jSeparator3;
    private javax.swing.JToolBar.Separator jSeparator4;
    private javax.swing.JToolBar.Separator jSeparator5;
    private javax.swing.JButton nextButton;
    private javax.swing.JTextField numberTextField;
    private javax.swing.JButton previousButton;
    private javax.swing.JButton saveAsButton;
    private javax.swing.JButton zoomInButton;
    private javax.swing.JButton zoomOutButton;
    // End of variables declaration//GEN-END:variables
    
    
    /**
     * Class responsible for displaying images.
     */
    private class ImagePanel extends JPanel {

        private BufferedImage displayed;
        private int w;
        private int h;
        private float scaleFactor;

        public ImagePanel(BufferedImage image) {
            displayed = image;
            scaleFactor = zoomFactor;
            w = image.getWidth();
            h = image.getHeight();
            setPreferredSize(new Dimension(w,h));
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g;
            super.paintComponent(g2);
            if (displayed != null) {
                g2.drawImage(displayed, 0, 0, w, h, null);
            }
        }

        public void zoomIn() {
            scaleFactor = scaleFactor > 0 ? scaleFactor : -scaleFactor;
            scale();
        }

        public void zoomOut() {
            if (w < 30 || h < 30) {
                return;
            }
            scaleFactor = scaleFactor < 0 ? scaleFactor : -scaleFactor;
            scale();
        }

        private void scale() {
            int newWidth = w + (int) (scaleFactor / 100 * w);
            int newHeight = h + (int) (scaleFactor / 100 * h);
            w = newWidth;
            h = newHeight;
            setPreferredSize(new Dimension(newWidth, newHeight));
            revalidate();
            repaint();
            changeWindowSize(newWidth, newHeight);
        }
    }
}
