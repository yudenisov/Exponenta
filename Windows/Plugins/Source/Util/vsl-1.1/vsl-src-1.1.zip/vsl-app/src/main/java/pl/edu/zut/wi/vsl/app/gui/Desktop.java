/*
 *    Virtual Steganographic Laboratory (VSL)
 *    Copyright (C) 2008-2011  M. Wegrzyn <bend-up@users.sourceforge.net>

 *    This file is part of Virtual Steganographic Laboratory (VSL).

 *    VSL is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.

 *    VSL is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.

 *    You should have received a copy of the GNU General Public License
 *    along with VSL.  If not, see <http://www.gnu.org/licenses/>.
 */
package pl.edu.zut.wi.vsl.app.gui;

import pl.edu.zut.wi.vsl.app.modules.VslModule;
import java.awt.Color;
import java.awt.Component;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Point;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.io.File;
import java.util.List;
import java.util.StringTokenizer;
import java.util.ArrayList;
import javax.swing.JDesktopPane;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;
import javax.swing.SwingConstants;
import javax.swing.TransferHandler;
import org.apache.log4j.Logger;
import pl.edu.zut.wi.vsl.app.Main;
import pl.edu.zut.wi.vsl.app.MainWindow;
import pl.edu.zut.wi.vsl.app.gui.DeskItem.Mode;
import pl.edu.zut.wi.vsl.app.modules.EncoderModule;
import pl.edu.zut.wi.vsl.app.modules.InputModule;
import pl.edu.zut.wi.vsl.app.modules.ModuleConnection;
import pl.edu.zut.wi.vsl.app.modules.VslModule.ModuleType;
import pl.edu.zut.wi.vsl.app.utils.FileUtil;
import pl.edu.zut.wi.vsl.app.utils.VslUtil;

/**
 * Class for arranging experiments. Contains internal frame
 * with list of the modules and all modules dropped from it.
 * 
 * @author Michal Wegrzyn
 */
public class Desktop extends JDesktopPane {

    private static final Logger logger = Logger.getLogger(Desktop.class);
    /** List of all modules representations that are present on the desktop. */
    private ArrayList<DeskItem> deskItems = new ArrayList<DeskItem>();
    /** The list of connections between items */
    private ArrayList<ModuleConnection> connections =
            new ArrayList<ModuleConnection>();
    /** The last DeskItem that was selected. */
    private transient DeskItem lastItem;
    /** Location of currently manipulated module. */
    private Point current;
    /** Color of the desktop */
    private final Color col;

    public Desktop() {
        setTransferHandler(new DropHandler(this));
        setOpaque(true);
        current = new Point(0, 0);
        Color dc = FileUtil.colorFromCsv(
                Main.getProperty("vsl.desktop.color", "200, 235, 210"));
        col = dc == null ? new Color(200, 235, 210) : dc;
        addMouseMotionListener(new MyMouseMotionListener());
        addMouseListener(new DesktopMouseAdapter(this));
    }

    /**
     * Adds given module to the desktop.
     * @param name Name of the module which has to be added.
     * @param x X position of the module which has to be added.
     * @param y Y position of the module which has to be added.
     * @param module <code>VslModule</code> instance which has to be added.
     */
    public void addItem(final String name, final int x, final int y, 
            final VslModule module) {
        DeskItem item = new DeskItem(this, name, x, y, module);
        add(item);
        deskItems.add(item);
        setLayer(item, JLayeredPane.DEFAULT_LAYER.intValue());
    }

    /**
     * Returns <code>DeskItem</code> that is present on the desktop
     * with specified <code>Mode</code>.
     * @param mode Mode which returned desk item should have.
     * @return DeskItem with specified mode.
     */
    private DeskItem getItem(final Mode mode) {
        DeskItem item = null;

        for (int i = 0; i < deskItems.size(); ++i) {
            DeskItem it = deskItems.get(i);
            if (it.getMode() == mode) {
                item = it;
                break;
            }
        }

        return item;
    }

    @Override
    public void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g;
        Paint pt = g2.getPaint();
        int w = getSize().width;
        int h = getSize().height;
        g2.setPaint(new GradientPaint(w / 4, h / 2, col.brighter(),
                w, h, col.darker()));
        g2.fillRect(0, 0, w, h);
        g2.setPaint(pt);
        paintConnections(g2);
        DeskItem i = getItem(Mode.Connecting);
        if (i != null) {
            Point p1 = i.getClosestConnectorPoint(current);
            g2.drawLine(current.x, current.y,
                    p1.x, p1.y);
        }

    }
    
    /**
     * Returns ArrayList will instances of all modules present on the desktop.
     * @return <code>ArrayList</code> with <code>DeskItem</code> instances.
     */
    public ArrayList<DeskItem> getModuleInstances() {
        return deskItems;
    }

    /**
     * Returns all Vsl Modules that are Input modules.
     * @return ArrayList - list of Input modules
     */
    public ArrayList<InputModule> getInputs() {
        final ArrayList<InputModule> inputs = new ArrayList<InputModule>();
        for (int i = 0; i < deskItems.size(); i++) {
            final VslModule v = deskItems.get(i).getModuleInstance();
            if (v.getModuleType() == ModuleType.Input) {
                inputs.add((InputModule) v);
            }
        }
        return inputs;
    }

    /**
     * Returns all Vsl Modules that are Steganographic modules switched 
     * to Encoding.
     * @return ArrayList - list of steganographic encoders
     */
    public ArrayList<EncoderModule> getEncoders() {
        ArrayList<EncoderModule> encoders = new ArrayList<EncoderModule>();
        for (int i = 0; i < deskItems.size(); i++) {
            final VslModule v = deskItems.get(i).getModuleInstance();
            if (v.getModuleType() == ModuleType.SteganographicEncoder) {
                encoders.add((EncoderModule) v);
            }
        }
        return encoders;
    }

    /**
     * Removes all <code>Deskitem</code> instances along with their connections.
     */
    public void clear() {
        deskItems = new ArrayList<DeskItem>();
        connections = new ArrayList<ModuleConnection>();
        
        final Component[] comps = getComponents();
        for (Component c : comps) {
            if (c.getClass().equals(DeskItem.class)) {
                remove(c);
            }
        }
        repaint();
    }

    /**
     * Cleans modules from data. Used before execution.
     */
    public void cleanUpModules() {
        logger.trace("Cleaning up modules.");
        for (int i = 0; i < deskItems.size(); i++) {
            final VslModule v = deskItems.get(i).getModuleInstance();
            v.cleanUpModule();
        }
    }
    
    /**
     * Block modules that user cannot change them during experiment 
     * or unblocks them. Note that also user cannot add new modules during
     * experiment.
     * @param boolean - determines whether modules can be accessed 
     */
    public void blockModules(final boolean block) {
        if (block) {
            DeskItem.setGlobalMode(Mode.Executing);
        } else {
            DeskItem.setGlobalMode(Mode.None);
        }
    }
    
    /**
     * Checks VslModules before execution if they are properly configured
     * to perform experiment.
     * @return <code>true</code> if modules are properly configured, 
     * otherwise - <code>false<code>
     */
    public boolean checkModules() {
        final ArrayList<InputModule> inputs = getInputs();
        if (inputs.isEmpty()) {
            final String msg = "Cannot find any Input module";
            logger.warn(msg);
            VslUtil.showWarn(getTopLevelAncestor(), msg);
            return false;
        }
        for (InputModule in : inputs) {
            if (in.getInputFiles().isEmpty()) {
                String msg = "You must specify input " +
                        "file(s) for every Input module.";
                logger.warn(msg);
                VslUtil.showWarn(getTopLevelAncestor(), msg);
                return false;
            }
        }
        ArrayList<EncoderModule> encoders = getEncoders();
        for (EncoderModule v : encoders) {
            if (v.getInitMessage() == null) {
                String msg = "You must specify message " +
                        "for every steganographic encoder.";
                logger.warn(msg);
                VslUtil.showWarn(getTopLevelAncestor(), msg);
                return false;
            }
        }
        return true;
    }

    /**
     * Loads workspace from given ArrayLists.
     * @param items - saved DeskItems
     * @param connections - saved ModuleConnections
     */
    public void loadWorkspace(final List<DeskItem> items, 
            final List<ModuleConnection> connections) {
        clear();

        this.deskItems.addAll(items);
        for (int i = 0; i < deskItems.size(); i++) {
            DeskItem di = items.get(i);
            di.setUI(DeskItemUI.UI_NORMAL);
            add(di);
            di.setParentPane(this);
        }
        this.connections = (ArrayList<ModuleConnection>) connections;
        repaint();
    }

    /**
     * Removes this item from Desktop.
     */
    public void removeItem(DeskItem item) {
        removeConnections(item.getModuleInstance());
        deskItems.remove(item);
        remove(item);
        repaint();
    }

    /**
     * Marks items to which we cannot connect.
     */
    public void markUnconnectableItems(DeskItem connecting) {
        for (DeskItem i : deskItems) {
            if (i == connecting
                    || i == null
                    || !i.getModuleInstance().canConnect(connecting.getModuleInstance())) {
                i.setUI(DeskItemUI.UI_CANNOT_CONNECT);
            }
        }
    }

    /**
     * Unmarks items to which we could not connect after exiting connecting mode.
     */
    public void unmarkUnconnectableItems(DeskItem source) {
        for (DeskItem i : deskItems) {
            if (i != source) {
                i.setUI(DeskItemUI.UI_NORMAL);
            }
        }
    }

    /**
     * Gets item that was selected earlier.
     * @return <code>DeskItem</code> that was previously selected.
     */
    public DeskItem getLastItem() {
        return lastItem;
    }

    /**
     * Sets last item
     * @param item Item, which should be kept as last selected
     */
    public void setLastItem(DeskItem item) {
        lastItem = item;
    }

    /**
     * Return a list of connections within some delta of a point
     * @param pt the <code>Point</code> at which to look for connections
     * @param delta connections have to be within this delta of the point
     * @return a list of the closest connections
     */
    public ArrayList getClosestConnections(Point pt, int delta) {
        ArrayList closestConnections = new ArrayList();

        for (int i = 0; i < connections.size(); i++) {
            ModuleConnection bc = (ModuleConnection) connections.get(i);
            DeskItem source = bc.getSourceItem();
            DeskItem target = bc.getTargetItem();
            Point bestSourcePt =
                    source.getClosestConnectorPoint(
                    new Point((target.getX() + (target.getWidth() / 2)),
                    (target.getY() + (target.getHeight() / 2))));
            Point bestTargetPt =
                    target.getClosestConnectorPoint(
                    new Point((source.getX() + (source.getWidth() / 2)),
                    (source.getY() + (source.getHeight() / 2))));

            int minx = (int) Math.min(bestSourcePt.getX(), bestTargetPt.getX());
            int maxx = (int) Math.max(bestSourcePt.getX(), bestTargetPt.getX());
            int miny = (int) Math.min(bestSourcePt.getY(), bestTargetPt.getY());
            int maxy = (int) Math.max(bestSourcePt.getY(), bestTargetPt.getY());
            // check to see if supplied pt is inside bounding box
            if (pt.getX() >= minx - delta && pt.getX() <= maxx + delta &&
                    pt.getY() >= miny - delta && pt.getY() <= maxy + delta) {
                // now see if the point is within delta of the line
                // formulate ax + by + c = 0
                double a = bestSourcePt.getY() - bestTargetPt.getY();
                double b = bestTargetPt.getX() - bestSourcePt.getX();
                double c = (bestSourcePt.getX() * bestTargetPt.getY()) -
                        (bestTargetPt.getX() * bestSourcePt.getY());

                double distance = Math.abs((a * pt.getX()) + (b * pt.getY()) + c);
                distance /= Math.abs(Math.sqrt((a * a) + (b * b)));

                if (distance <= delta) {
                    closestConnections.add(bc);
                }
            }
        }
        return closestConnections;
    }

    /**
     * Remove all connections for a given Module. 
     * @param instance the Module to remove connections to/from
     * @see #remove()
     */
    public void removeConnections(VslModule instance) {

        ArrayList instancesToRemoveFor = new ArrayList();
        instancesToRemoveFor.add(instance);
        ArrayList<ModuleConnection> removeArrayList = new ArrayList<ModuleConnection>();
        for (int j = 0; j < instancesToRemoveFor.size(); j++) {
            VslModule tempInstance =
                    (VslModule) instancesToRemoveFor.get(j);
            for (int i = 0; i < connections.size(); i++) {
                /* In cases where this instance is the target, deregister it
                 * as a listener for the source */
                ModuleConnection bc = (ModuleConnection) connections.get(i);
                VslModule tempTarget = bc.getTarget();
                VslModule tempSource = bc.getSource();
                if (tempInstance == tempTarget || tempInstance == tempSource) {
                    removeArrayList.add(bc);
                }
            }
        }
        // remove first loop connections (must fit parameters)
        for (int i = 0; i < removeArrayList.size(); i++) {
            ModuleConnection toRemove = removeArrayList.get(i);
            if (toRemove.isLoopConnection()) {
                toRemove.remove();
                removeArrayList.remove(i);
            }
        }
        // remove remaining connections
        for (int i = 0; i < removeArrayList.size(); i++) {
            removeArrayList.get(i).remove();
        }
    }

    /**
     * Returns the list of connections
     * @return the list of connections
     */
    public ArrayList<ModuleConnection> getConnections() {
        return connections;
    }

    /**
     * Sets state of all <code>ModuleConnection</code> instances to inactive.
     * @see pl.edu.zut.wi.vsl.client.modules.ModuleConnection#setActive(boolean)
     */
    public void setAllConnectionsInactive() {
        for (int i = 0; i < connections.size(); i++) {
            ModuleConnection bc = (ModuleConnection) connections.get(i);
            bc.setActive(false);
        }
    }

    /**
     * Renders the connections and their names on the supplied graphics
     * context
     * @param gx a <code>Graphics</code> value
     */
    public void paintConnections(Graphics gx) {
        for (int i = 0; i < connections.size(); i++) {
            ModuleConnection bc = (ModuleConnection) connections.get(i);
            DeskItem sourceItem = bc.getSourceItem();
            DeskItem targetItem = bc.getTargetItem();
            Point bestSourcePt =
                    sourceItem.getClosestConnectorPoint(
                    new Point((targetItem.getX() + (targetItem.getWidth() / 2)),
                    (targetItem.getY() + (targetItem.getHeight() / 2))));
            Point bestTargetPt =
                    targetItem.getClosestConnectorPoint(
                    new Point((sourceItem.getX() + (sourceItem.getWidth() / 2)),
                    (sourceItem.getY() + (sourceItem.getHeight() / 2))));
            if (bc.isActive()) {
                gx.setColor(ModuleConnection.COLOR_ACTIVE);
            } else {
                gx.setColor(ModuleConnection.COLOR_INACTIVE);
            }
            gx.drawLine((int) bestSourcePt.getX(), (int) bestSourcePt.getY(),
                    (int) bestTargetPt.getX(), (int) bestTargetPt.getY());

            // paint an arrow head
            double angle;
            try {
                double a =
                        (double) (bestSourcePt.getY() -
                        bestTargetPt.getY()) /
                        (double) (bestSourcePt.getX() - bestTargetPt.getX());
                angle = Math.atan(a);
            } catch (Exception e) {
                angle = Math.PI / 2;
            }
            //Point arrowstart = new Point((p1.x + p2.x) / 2, (p1.y + p2.y) / 2);
            Point arrowstart = new Point(bestTargetPt.x,
                    bestTargetPt.y);
            Point arrowoffset = new Point((int) (12 * Math.cos(angle)),
                    (int) (12 * Math.sin(angle)));
            Point arrowend;
            if (bestSourcePt.getX() >= bestTargetPt.getX()) {

                arrowend = new Point(arrowstart.x + arrowoffset.x,
                        arrowstart.y + arrowoffset.y);
            } else {
                arrowend = new Point(arrowstart.x - arrowoffset.x,
                        arrowstart.y - arrowoffset.y);
            }
            int xs[] = {arrowstart.x,
                arrowend.x + (int) (5 * Math.cos(angle + (Math.PI / 2))),
                arrowend.x + (int) (5 * Math.cos(angle - (Math.PI / 2))) };
            int ys[] = {arrowstart.y,
                arrowend.y + (int) (5 * Math.sin(angle + (Math.PI / 2))),
                arrowend.y + (int) (5 * Math.sin(angle - (Math.PI / 2)))
            };
            gx.fillPolygon(xs, ys, 3);

            int numOfLoops = bc.getNumberOfLoops();
            if (numOfLoops > 1) {
                // paint number of loops
                int midx = (int) bestSourcePt.getX();
                midx += (int) ((bestTargetPt.getX() - bestSourcePt.getX()) / 2);
                int midy = (int) bestSourcePt.getY();
                midy += (int) ((bestTargetPt.getY() - bestSourcePt.getY()) / 2) - 2;

                gx.setColor(ModuleConnection.COLOR_TEXT);
                if (previousLink(bc.getSource(), bc.getTarget(), i)) {
                    midy -= 15;
                }
                gx.drawString(String.valueOf(numOfLoops), midx, midy);
            }
        }
    }

    /**
     * Returns true if there is a link between the supplied source and
     * target VslModules at an earlier index than the supplied index
     *
     * @param source the source <code>VslModule</code>
     * @param target the target <code>VslModule</code>
     * @param index the index to compare to
     * @return <code>true if there is already a link at an earlier index,
     * otherwise <code>false<code>
     */
    private boolean previousLink(VslModule source, VslModule target,
            int index) {
        for (int i = 0; i < connections.size(); i++) {
            ModuleConnection bc = (ModuleConnection) connections.get(i);
            VslModule compSource = bc.getSource();
            VslModule compTarget = bc.getTarget();

            if (compSource == source && compTarget == target && index < i) {
                return true;
            }
        }
        return false;
    }

    public void addConnection(ModuleConnection connection) {
        connections.add(connection);
    }

    public void removeConnection(ModuleConnection connection) {
        connections.remove(connection);
    }

    /**
     * The MouseAdapter that handles click events.
     */
    private class DesktopMouseAdapter extends MouseAdapter {

        private final Desktop parent;
        
        public DesktopMouseAdapter(Desktop p) {
            parent = p;
        }

        /**
         * Called when the user clicks on the DeskItem.
         * @param ev The event associated with the click operation.
         */
        @Override
        public void mouseClicked(MouseEvent ev) {
        }

        /**
         * Called when the mouse is pressed down.
         * @param ev The associated event.
         */
        @Override
        public void mousePressed(MouseEvent ev) {
            switch (DeskItem.getGlobalMode()) {
                case None:
                    if (ev.isPopupTrigger() || 
                            ev.isControlDown() ||
                            (ev.getClickCount() == 2 
                                && ev.getButton() == MouseEvent.BUTTON1)) {
                        int delta = 10;
                        Point offset = MainWindow.getWindowScrollOffset();
                        Point visibleLoc = new Point(current.x - offset.x, 
                                                        current.y - offset.y);
                        connectionPopup(getClosestConnections(
                                                            current, delta),
                                                            visibleLoc.x, 
                                                            visibleLoc.y);
                    }
                    break;
                case Connecting:
                    lastItem.exit();
                    DeskItem.setGlobalMode(Mode.None);
                    DeskItem i = getItem(Mode.Connecting);
                    i.setMode(Mode.None);
                    i.unmarkUnconnectableItems();
                    i.setUI(DeskItemUI.UI_NORMAL);
                    repaint();
                    break;
                default:
                    break;
            }
        }

        /**
         * Called when the mouse button is released.
         * @param ev The associated event.
         */
        @Override
        public void mouseReleased(MouseEvent ev) {

            switch (DeskItem.getGlobalMode()) {
                case None:
                case Moving:
                    break;
                default:
                    break;
            }
        }

        @Override
        public void mouseEntered(MouseEvent ev) {
        }

        @Override
        public void mouseExited(MouseEvent ev) {
        }

        private void connectionPopup(ArrayList closestConnections, int x, int y) {
            logger.info("Creating connection popup");
            if (!closestConnections.isEmpty()) {
                JPopupMenu connectionMenu = new JPopupMenu();

                for (int i = 0; i < closestConnections.size(); i++) {
                    final ModuleConnection bc =
                            (ModuleConnection) closestConnections.get(i);
                    String connName = bc.getSource().getName() + " -> " + 
                                                    bc.getTarget().getName();
                    connectionMenu.add(new JLabel(connName,
                        SwingConstants.CENTER));
                    JMenuItem deleteItem = new JMenuItem("Delete");
                    deleteItem.setMnemonic(KeyEvent.VK_D);
                    deleteItem.addActionListener(new ActionListener() {

                        public void actionPerformed(ActionEvent e) {
                            bc.remove();
                            getParent().repaint();
                        }
                    });
                    connectionMenu.add(deleteItem);
                    final int numOfLoops = bc.getNumberOfLoops();
                    if(numOfLoops > 0) {
                        JMenuItem loopItem = new JMenuItem("Loops: " + 
                                                            numOfLoops);
                        loopItem.setMnemonic(KeyEvent.VK_L);
                        loopItem.addActionListener(new ActionListener() {

                        public void actionPerformed(ActionEvent e) {
                            int newVal = -1;
                            try {
                                String sNewVal = (String) JOptionPane.
                                        showInputDialog(
                                            parent.getTopLevelAncestor(),
                                            "Please specify number of loops.", 
                                            "VSL - number of loops",
                                            JOptionPane.QUESTION_MESSAGE,
                                            VslUtil.QUESTION_ICON,
                                            null,
                                            String.valueOf(numOfLoops));                       
                            
                                newVal = Integer.parseInt(sNewVal);
                            } catch (NumberFormatException ex) {
                                String msg = "Not a valid Integer passed " +
                                        "during specifying number of loops";
                                logger.warn(msg, ex);
                                VslUtil.showWarn(parent.getTopLevelAncestor(), 
                                                                        msg);
                                return;
                            } catch (ClassCastException ex) {
                                String msg = "Not a valid Integer passed " +
                                        "during specifying number of loops";
                                logger.warn(msg, ex);
                                VslUtil.showWarn(parent.getTopLevelAncestor(), 
                                                                        msg);
                                return;
                            } catch (Exception ex) {
                                String msg = "Exception occured " +
                                        "during specifying number of loops";
                                logger.warn(msg, ex);
                                VslUtil.showWarn(parent.getTopLevelAncestor(), 
                                                                        msg);
                                return;
                            }
                            if (newVal < 1) {
                                return;
                            }
                            
                            bc.setNumberOfLoops(newVal);
                            bc.uptadeModulesWithParams();
                            getParent().repaint();
                        }
                    });
                    connectionMenu.add(loopItem);
                    }
                }
                connectionMenu.show(getParent(), x, y);
            }
        }
    }

    /**
     * The MouseMotionAdapter used to track motion operations.
     */
    private class MyMouseMotionListener extends MouseMotionAdapter {

        /**
         * Called when the mouse is moved without a button down.
         * @param ev The associated event for this operation.
         */
        @Override
        public void mouseMoved(MouseEvent ev) {
            repaint();
            current = new Point(ev.getX(), ev.getY());
        }

        /**
         * Called when the mouse is moved with button one down.
         * @param ev The associated mouse event.
         */
        @Override
        public void mouseDragged(MouseEvent ev) {
        }
    }
}

/**
 * Desktop's class for Drag'n'Drop support.
 */
class DropHandler extends TransferHandler {

    private static final Logger logger = Logger.getLogger(DropHandler.class);
    private final Desktop desk;
    
    public DropHandler(Desktop parent) {
        desk = parent;
    }

    private Desktop getParent() {
        return desk;
    }

    @Override
    public boolean canImport(TransferSupport supp) {
        //TODO add support for ctrl+c ctrl+v

        /* for the demo, we'll only support drops (not clipboard paste) */
        if (!supp.isDrop()) {
            return false;
        }

        /* check to see if the source actions (a bitwise-OR of supported
         * actions) contains the COPY action
         */
        boolean copySupported = (COPY & supp.getSourceDropActions()) == COPY;

        /* if COPY is supported, choose COPY and accept the transfer */
        if (copySupported) {
            supp.setDropAction(COPY);
            return true;
        }

        /* COPY isn't supported, so reject the transfer.
         *
         * Note: To accept the transfer with the default
         *       action anyway, could instead return true.
         */
        return false;
    }

    @Override
    public boolean importData(TransferSupport supp) {

        if (!canImport(supp)) {
            return false;
        }
        
        if (DeskItem.getGlobalMode() == Mode.Executing) {
            VslUtil.showWarn(getParent().getTopLevelAncestor(),
                                "You cannot add modules during experiment.");
            /*JOptionPane.showConfirmDialog(getParent().getTopLevelAncestor(),                                                  
                "You cannot add modules during execution.",
                "VSL - Warning", JOptionPane.DEFAULT_OPTION,
                JOptionPane.WARNING_MESSAGE, VslUtil.WARN_ICON);*/
            return false;
        }
        
        if (supp.isDrop()) {
            /* fetch the Transferable */
            Transferable t = supp.getTransferable();
            Point dropPoint = supp.getDropLocation().getDropPoint();

            /* handling for outside application drop */
            try {
                DataFlavor listOfUriFlavor = new DataFlavor(
                                    "text/uri-list;class=java.lang.String");
                DataFlavor moduleFlavor = new DataFlavor(
                        "application/x-java-jvm-local-objectref;class=" +
                        "pl.edu.zut.wi.vsl.app.modules.VslModule");
                // the list contains java.io.File(s)
                List<File> files = null;
                if (t.isDataFlavorSupported(DataFlavor.javaFileListFlavor)) {
                    logger.info("Dropped list of files");
                    files = (java.util.List) t.getTransferData(
                                                DataFlavor.javaFileListFlavor);
                } else if (t.isDataFlavorSupported(listOfUriFlavor)) {
                    String data = (String) t.getTransferData(listOfUriFlavor);
                    files = textURIListToFileList(data);
                } else if (t.isDataFlavorSupported(moduleFlavor)) {
                    VslModule droppedModule = (VslModule) 
                                                t.getTransferData(moduleFlavor);
                    VslModule newModule = droppedModule.deepCopy();
                    getParent().addItem(newModule.getName(), dropPoint.x, 
                                                    dropPoint.y, newModule);
                    logger.info("Dropped " + newModule.getName());
                } else {
                    String msg = "Unsupported data flavor while handling drop";
                    logger.warn(msg);
                    VslUtil.showWarn(getParent().getTopLevelAncestor(), msg);
                    
                    // debug trace
                    if (logger.isDebugEnabled()) {
                        DataFlavor[] dfs = t.getTransferDataFlavors();
                        for (DataFlavor d : dfs) {
                            logger.debug(d.getMimeType());
                        }
                    }
                }

                if (files != null) {
                    ArrayList<File> iv = new ArrayList<File>();
                    List<File> dirFiles = new ArrayList<File>();
                    for (File file : files) {
                        if (file.isDirectory()) {
                            dirFiles.addAll(FileUtil.listOfImageFiles(file, true));
                        } else if (FileUtil.checkIsFormatHandled(file.getName())) {
                            iv.add(file);
                        }
                    }
                    
                    if (!dirFiles.isEmpty()) {
                        for (File file : dirFiles) {
                            if (FileUtil.checkIsFormatHandled(file.getName())) {
                                iv.add(file);
                            }
                        }   
                    }
                    
                    if (!iv.isEmpty()) {
                        InputModule input = new InputModule(iv);
                        getParent().addItem("Input", dropPoint.x, 
                                                    dropPoint.y, input);
                        logger.info("Dropped Input from outside");
                    } else {
                        String msg = "Could not find image(s) " +
                                     "handled by VSL. " +
                                     "Please check dropped objects.";
                        logger.warn(msg);
                        VslUtil.showWarn(getParent().getTopLevelAncestor(),
                                                                        msg);
                    }
                }
            } catch (Exception e) {
                String msg = "Exception during handling drop.";
                logger.error(msg, e);
                VslUtil.showError(getParent().getTopLevelAncestor(), msg, e);
            }
            return true;
        }
        return true;
    }

    /**
     * Workaround function for d'n'd support in Gnome - import file(s) 
     * to application (transforms String to the List of files - in Gnome 
     * there is List of URI instead of List of files).
     * @param data String with URIs of files
     * @return List of files
     */
    private static java.util.List textURIListToFileList(String data) {
        java.util.List list = new java.util.ArrayList(1);
        for (StringTokenizer st = new StringTokenizer(data, "\r\n");
                st.hasMoreTokens();) {
            String s = st.nextToken();
            if (s.startsWith("#")) {
                // the line is a comment (as per the RFC 2483)
                continue;
            }
            try {
                java.net.URI uri = new java.net.URI(s);
                java.io.File file = new java.io.File(uri);
                list.add(file);
            } catch (java.net.URISyntaxException e) {
                // malformed URI
                String msg = "Malformed URI - exception during transforming " +
                        "String to list of files";
                logger.error(msg, e);
                VslUtil.showError(null, msg, e);
            } catch (IllegalArgumentException e) {
                // the URI is not a valid 'file:' URI
                String msg = "The URI is not a valid 'file:' URI";
                logger.error(msg, e);
                VslUtil.showError(null, msg, e);
            }
        }
        return list;
    }
    
    //
    // rest of code can be used to export data from application with DnD
    //
    private static DataFlavor uriListFlavor;
    
    static {
        try {
            uriListFlavor = new DataFlavor("text/uri-list;class=" +
                                                    "java.lang.String");
        } catch (ClassNotFoundException e) {
            // can't happen
            String msg = "Could not find String class?!?";
            logger.error(msg, e);
            VslUtil.showError(null, msg, e);
        }
    }
    
    private static DataFlavor[] flavours = new DataFlavor[]{
        DataFlavor.javaFileListFlavor, uriListFlavor
    };

    public Object getTransferData(DataFlavor flavor) throws
            UnsupportedFlavorException, java.io.IOException {
        if (flavor.equals(DataFlavor.javaFileListFlavor)) {
            java.util.List data = new java.util.ArrayList();
            java.io.File file = new java.io.File("file.txt");
            data.add(file);
            return data;
        } else if (flavor.equals(uriListFlavor)) {
            java.io.File file = new java.io.File("file.txt");
            // refer to RFC 2483 for the text/uri-list format
            return file.toURI() + "\r\n";
        } else {
            throw new UnsupportedFlavorException(flavor);
        }
    }

    public DataFlavor[] getTransferDataFlavors() {
        return flavours.clone();
    }

    public boolean isDataFlavorSupported(DataFlavor flavor) {
        for (int i = 0; i < flavours.length; i++) {
            if (flavor.equals(flavours[i])) {
                return true;
            }
        }
        return false;
    }
}