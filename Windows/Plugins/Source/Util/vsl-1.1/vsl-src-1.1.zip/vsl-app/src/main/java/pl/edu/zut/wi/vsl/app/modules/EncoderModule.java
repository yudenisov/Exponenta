/*
 *    Virtual Steganographic Laboratory (VSL)
 *    Copyright (C) 2008-2011  M. Wegrzyn <bend-up@users.sourceforge.net>

 *    This file is part of Virtual Steganographic Laboratory (VSL).

 *    VSL is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.

 *    VSL is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.

 *    You should have received a copy of the GNU General Public License
 *    along with VSL.  If not, see <http://www.gnu.org/licenses/>.
 */
package pl.edu.zut.wi.vsl.app.modules;

import java.io.IOException;
import java.io.Serializable;
import pl.edu.zut.wi.vsl.app.VslException;
import pl.edu.zut.wi.vsl.commons.Message;
import pl.edu.zut.wi.vsl.commons.StegoImage;
import pl.edu.zut.wi.vsl.commons.StegoPackage;
import pl.edu.zut.wi.vsl.commons.steganography.EncodingException;
import pl.edu.zut.wi.vsl.commons.steganography.SteganographicTechnique;

/**
 * Module for steganographic encoders.
 *
 * @author Michal Wegrzyn
 */
public class EncoderModule extends VslModule implements Serializable {

    /** For serialization. */
    private static final long serialVersionUID = 4963599763699355579L;
    /** Initial module message */
    private Message initMessage;

    public EncoderModule(String name, String description, String clazz) {
        super(name, description, clazz, ModuleType.SteganographicEncoder);
    }

    public EncoderModule(EncoderModule v) {
        super(v);

        if (v.getInitMessage() != null) {
            initMessage = v.getInitMessage();
        }
    }

    public Message getInitMessage() {
        return initMessage;
    }

    /**
     * Sets stego object to hide (before any execution)
     * @param msg - Message to hide
     */
    public void setInitMessage(String path) throws IOException {
        initMessage = new Message(path);
    }

    @Override
    public StegoPackage execute(StegoPackage cp) throws VslException {
        int paramIndex = getLoopNumber();

        try {
            initMessage.prepareMessage();
            cp.setMessage(initMessage);

            SteganographicTechnique d = (SteganographicTechnique)
                    (Class.forName(getModuleClass()).newInstance());
            StegoImage img = d.encode(cp, getParameterMap(paramIndex));
            img.setPath(cp.getImage().getPath());
            cp.setImage(img);

        } catch (EncodingException e) {
            throw new VslException("Exception during execution", e);
        } catch (ClassNotFoundException e ) {
            throw new VslException("Exception during execution", e);
        } catch (InstantiationException e) {
            throw new VslException("Exception during execution", e);
        } catch ( IllegalAccessException e) {
            throw new VslException("Exception during execution", e);
        }

        return cp;
    }


}
