/*
 *    Virtual Steganographic Laboratory (VSL)
 *    Copyright (C) 2008-2011  M. Wegrzyn <bend-up@users.sourceforge.net>

 *    This file is part of Virtual Steganographic Laboratory (VSL).

 *    VSL is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.

 *    VSL is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.

 *    You should have received a copy of the GNU General Public License
 *    along with VSL.  If not, see <http://www.gnu.org/licenses/>.
 */
package pl.edu.zut.wi.vsl.modules.steganography.klt;

import Jama.Matrix;
import Jama.EigenvalueDecomposition;
import au.com.bytecode.opencsv.CSVReader;
import au.com.bytecode.opencsv.CSVWriter;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import org.apache.log4j.Logger;
import pl.edu.zut.wi.vsl.commons.steganography.DecodingException;
import pl.edu.zut.wi.vsl.commons.StegoImage;
import pl.edu.zut.wi.vsl.commons.StegoPackage;
import pl.edu.zut.wi.vsl.commons.steganography.SteganographicTechnique;
import pl.edu.zut.wi.vsl.commons.steganography.EncodingException;
import pl.edu.zut.wi.vsl.commons.Message;
import pl.edu.zut.wi.vsl.commons.utils.BitUtility;
import pl.edu.zut.wi.vsl.commons.utils.FileUtility;
import pl.edu.zut.wi.vsl.commons.utils.Generator;
import pl.edu.zut.wi.vsl.commons.utils.ImageUtility;

/**
 * Steganographic technique that employs two-dimensional 
 * Karhunen-Loeve Transform - message is embedded into eigenArrayLists of
 * image blocks. It was proposed by Pawel Forczmanski at West Pomeranian
 * University of Technology. You can contact him at 
 * <pforczmanski@wi.zut.edu.pl>.
 * 
 * @author Michal Wegrzyn
 */
public class KltImpl implements SteganographicTechnique {

    private final static Logger logger = Logger.getLogger(KltImpl.class);
    private final int OFFSET = 40;

    public static void main(String[] args) {

        KltImpl k = new KltImpl();

        switch (args.length) {
            // encoding
            case 10:
                LinkedHashMap<String, String> o =
                        new LinkedHashMap<String, String>();
                o.put("eig cols ArrayLists", args[3]);
                o.put("eig rows ArrayLists", args[4]);
                o.put("key", args[5]);
                o.put("mean", args[6]);
                o.put("block size", args[7]);
                o.put("start position", args[8]);
                o.put("end position", args[9]);

                StegoImage si = null;
                Message msg = null;
                try {
                    msg = new Message(args[1]);
                } catch (FileNotFoundException e) {
                    logger.error("Could not find message file.", e);
                    System.exit(1);
                } catch (IOException e) {
                    logger.error("Could not create message object.", e);
                    System.exit(1);

                }
                try {
                    BufferedImage bi = ImageUtility.readImage(args[0]);
                    si = new StegoImage(bi, args[0]);
                } catch (IllegalArgumentException e) {
                    logger.error("Could not create stegoimage.", e);
                    System.exit(1);
                } catch (NullPointerException e) {
                    logger.error("Could not create stegoimage.", e);
                    System.exit(1);
                } catch (IOException e) {
                    logger.error("Could not create stegoimage.", e);
                    System.exit(1);
                }

                StegoPackage p = new StegoPackage(si, msg);
                StegoImage result = null;

                try {
                    result = k.encode(p, o);
                } catch (EncodingException e) {
                    logger.error("Could not encode message.", e);
                    System.exit(1);
                }
                try {
                    result.write(args[2]);
                } catch (IllegalArgumentException e) {
                    logger.error("Could not write result image.", e);
                    System.exit(1);
                } catch (IOException e) {
                    logger.error("Could not write result image.", e);
                    System.exit(1);
                }

                break;
            // decoding   
            case 9:
                LinkedHashMap<String, String> o2 =
                        new LinkedHashMap<String, String>();
                o2.put("eig cols ArrayLists", args[2]);
                o2.put("eig rows ArrayLists", args[3]);
                o2.put("key", args[4]);
                o2.put("mean", args[5]);
                o2.put("block size", args[6]);
                o2.put("start position", args[7]);
                o2.put("end position", args[8]);
                StegoImage si2 = null;
                Message msg2 = null;

                try {
                    BufferedImage bi = ImageUtility.readImage(args[0]);
                    si2 = new StegoImage(bi, args[0]);
                } catch (IllegalArgumentException e) {
                    logger.error("Could not create stegoimage.", e);
                    System.exit(1);
                } catch (NullPointerException e) {
                    logger.error("Could not create stegoimage.", e);
                    System.exit(1);
                } catch (IOException e) {
                    logger.error("Could not create stegoimage.", e);
                    System.exit(1);
                }

                try {
                    msg2 = k.decode(si2, o2);
                } catch (DecodingException e) {
                    logger.error("Could not decode message.", e);
                    System.exit(1);
                }
                try {
                    msg2.writeBytesToFile(args[1]);
                } catch (IllegalArgumentException e) {
                    logger.error("Could not write result image.", e);
                    System.exit(1);
                } catch (IOException e) {
                    logger.error("Could not write result image.", e);
                    System.exit(1);
                }
                break;
            case 1:
                if (args[0].equals("--help") ||
                        args[0].equals("-help") ||
                        args[0].equals("?") ||
                        args[0].equals("/?")) {
                    printUsage();
                }
                break;
            default:
                System.out.println("Unsupported option");
                KltImpl.printUsage();
                break;
        }
    }

    /**
     * Prints usage to console.
     */
    private static void printUsage() {
        System.out.println("Usage: \n" +
"Encoding: \n" +
"vsl-module-steganogrphy klt <path to image> <path to message> \n" +
"                            <path to result image> <eig cols ArrayLists> \n" +
"                            <eig rows ArrayLists> <path to key> <path to mean> \n" +
"                            <block size> <start position> <end position>\n" +
"Decoding: \n" +
"vsl-module-steganography-klt <path to image> <path to result message> \n" +
"                             <eig cols ArrayLists> <eig rows ArrayLists> \n" +
"                             <path to key> <block size> <start position> \n" +
"                             <end position> \n" +
"eig cols ArrayLists - path to the file that holds (decoding) or will hold \n" +
"(encoding) eigenArrayLists calculated between image columns\n" +
"eig rows ArrayLists - path to the file that holds (decoding) or will hold \n" +
"(encoding) eigenArrayLists calculated between image rows\n" +
"path to key - path to the file that holds (decoding) or will hold \n" +
"(encoding) key required to extract message\n" +
"path to mean - path to the file that holds (decoding) or will hold \n" +
"(encoding) mean value of used image component\n" +
"block size - size of blocks to which image will be divided\n" +
"start position - specifies the lowest index of diagonal values in which \n" +
"message is/will be encoded\n" +
"end position - specifies the highest index of diagonal values in which \n" +
"message is/will be encoded");
    }

    public StegoImage encode(StegoPackage sp,
            LinkedHashMap<String, String> options)
            throws EncodingException {
        StegoImage img = sp.getImage();
        int blockSize;
        int startposition;
        int endposition;

        try {
            blockSize = Integer.valueOf(options.get("block size"));
        } catch (NumberFormatException e) {
            throw new EncodingException("block size must be a valid " +
                    "integer scalar");
        }
        try {
            startposition = Integer.valueOf(options.get("start position"));
        } catch (NumberFormatException e) {
            throw new EncodingException("start position must be a valid " +
                    "integer scalar");
        }
        try {
            endposition = Integer.valueOf(options.get("end position"));
        } catch (NumberFormatException e) {
            throw new EncodingException("end position must be a valid " +
                    "integer scalar");
        }
        if (startposition < 0) {
            throw new EncodingException("start position must be a nonnegative "+
                    "integer");
        }
        if (endposition > blockSize - 1) {
            throw new EncodingException("end position must be a value lesser " +
                    "than block size");
        }
        if (startposition > endposition) {
            throw new EncodingException("start position cannot be greater " +
                    "than end position");
        }
        if (blockSize < 1) {
            throw new EncodingException("block size must be greater " +
                    "than 0");
        }
        if (blockSize > img.getWidth() || blockSize > img.getHeight()) {
            throw new EncodingException("block size cannot be greater " +
                    "than image size");
        }

        String eigColsFilename = options.get("eig cols ArrayLists");
        String eigRowsFilename = options.get("eig rows ArrayLists");
        String keyFilename = options.get("key");
        String meanFilename = options.get("mean");
        double[][] val = new double[img.getWidth()][img.getHeight()];
        double[][] saturation = new double[img.getWidth()][img.getHeight()];
        double[][] value = new double[img.getWidth()][img.getHeight()];
        int blocksInCols = (int) Math.ceil(img.getWidth() / blockSize);
        int blocksInRows = (int) Math.ceil(img.getHeight() / blockSize);
        // we do not embedd in overlapping blocks
        int embBlocksInCols = (int) Math.floor(img.getWidth() / blockSize);
        int embBlocksInRows = (int) Math.floor(img.getHeight() / blockSize);
        int colRange;
        int rowRange;
        int bitsInBlock = endposition - startposition + 1;
        double meanValue = 0;
        // matrix with values in which message will be hidden
        Matrix vals;
        // array with image blocks
        Matrix[][] blocks;
        Matrix meanBlock;
        // covariance matrices
        Matrix covCols;
        Matrix covRows;
        // matrices with eigenArrayLists
        Matrix eigValsCols;
        Matrix eigValsRows;
        Matrix[][] transformedBlocks;
        File eigColsFile = new File(eigColsFilename);
        File eigRowsFile = new File(eigRowsFilename);
        File meanFile = new File(meanFilename);
        Message msg = sp.getMessage();

        int maxBits = embBlocksInRows * embBlocksInCols * bitsInBlock;

        if (maxBits < msg.getSize() * 8) {
            throw new EncodingException("Message is to big for this method " +
                    "and image. Maximum size for this " +
                    "configuration [B]: " + maxBits/8);
        }

        switch (img.getLayerCount()) {
            case 1:
                /* Gray image */
                for (int i = 0; i < img.getWidth(); i++) {
                    for (int j = 0; j < img.getHeight(); j++) {
                        val[i][j] = img.getRaster().getSampleDouble(i, j, 0);
                        meanValue += val[i][j];
                    }
                }
                break;

            case 3:
                /* RGB image
                 * methods encodes in hue component of the image
                 * thus we need to convert RGB to HSV */
                for (int i = 0; i < img.getWidth(); i++) {
                    for (int j = 0; j < img.getHeight(); j++) {
                        int px = img.getRGB(i, j);
                        double[] hsv = ImageUtility.rgb2hsv(ImageUtility.getRed(px),
                                ImageUtility.getGreen(px),
                                ImageUtility.getBlue(px));

                        val[i][j] = hsv[ImageUtility.HUE];
                        saturation[i][j] = hsv[ImageUtility.SATURATION];
                        value[i][j] = hsv[ImageUtility.VALUE];
                        meanValue += Double.isNaN(val[i][j]) ? 0 : val[i][j];
                    }
                }
                break;

            case 0:
            default:
                throw new EncodingException("unsupported image type");

        }
        vals = new Matrix(val);
        // calculate mean value
        meanValue /= img.getWidth() * img.getHeight();

        logger.trace("dividing into blocks");
        // divide image to blocks
        blocks = new Matrix[blocksInCols][blocksInRows];
        for (int i = 0; i < blocksInCols; i++) {
            for (int j = 0; j < blocksInRows; j++) {
                boolean colOverlap = false;
                boolean rowOverlap = false;
                int colEnd = (i + 1) * blockSize - 1;
                if (colEnd > img.getWidth()) {
                    colOverlap = true;
                    colRange = colEnd - img.getWidth();
                } else {
                    colRange = colEnd;
                }
                int rowEnd = (j + 1) * blockSize - 1;
                if (rowEnd > img.getHeight()) {
                    rowOverlap = true;
                    rowRange = rowEnd - img.getHeight();
                } else {
                    rowRange = rowEnd;
                }

                if (colOverlap || rowOverlap) {
                    double tmp[][] = vals.getMatrix(i * blockSize, colRange,
                            j * blockSize, rowRange).getArray();
                    double[][] newBlock = new double[blockSize][blockSize];
                    for (int k = 0; k < blockSize; k++) {
                        for (int l = 0; l < blockSize; l++) {
                            newBlock[k][l] = (k > tmp.length ||
                                    l > tmp[0].length)
                                    ? 0
                                    : tmp[k][l];
                        }
                    }
                    blocks[i][j] = new Matrix(newBlock);
                } else {
                    blocks[i][j] = vals.getMatrix(i * blockSize, colRange,
                            j * blockSize, rowRange);
                }
            }
        }

        meanBlock = new Matrix(blockSize, blockSize, meanValue);
        //remove mean element from every block
        for (int i = 0; i < embBlocksInCols; i++) {
            for (int j = 0; j < embBlocksInRows; j++) {
                blocks[i][j].minusEquals(meanBlock);
            }
        }
        
        try {
            saveMean(meanValue, meanFile);
        } catch (Exception e) {
            throw new EncodingException("Could not save mean value to a file", e);
        }

        logger.trace("calculating covariance matrices");
        covCols = new Matrix(blockSize, blockSize, 0);
        covRows = new Matrix(blockSize, blockSize, 0);
        
        // calculate covariance matrices
        for (int i = 0; i < blocksInCols; i++) {
            for (int j = 0; j < blocksInRows; j++) {
                covCols.plusEquals(blocks[i][j].transpose().times(blocks[i][j]));
                covRows.plusEquals(blocks[i][j].times(blocks[i][j].transpose()));
            }
        }

        covCols.timesEquals(1.0d / (embBlocksInCols * embBlocksInRows));
        covRows.timesEquals(1.0d / (embBlocksInCols * embBlocksInRows));

        logger.trace("starting eigenvalue decomposition for columns");
        EigenvalueDecomposition eigCols = new EigenvalueDecomposition(covCols);
        logger.trace("starting eigenvalue decomposition for rows");
        EigenvalueDecomposition eigRows = new EigenvalueDecomposition(covRows);

        logger.trace("performing transformation of blocks");
        // transformation of blocks
        transformedBlocks = new Matrix[embBlocksInCols][embBlocksInRows];
        eigValsCols = getSortedEigenArrayLists(eigCols);
        eigValsRows = getSortedEigenArrayLists(eigRows);

        // save  eigenmatrices
        try {
            saveEigenMatrices(eigValsCols, eigColsFile,
                    eigValsRows, eigRowsFile);
        } catch (IOException e) {
            throw new EncodingException("Could not write out " +
                    "eigen matrices", e);
        }


        for (int i = 0; i < embBlocksInCols; i++) {
            for (int j = 0; j < embBlocksInRows; j++) {
                transformedBlocks[i][j] =
                        eigValsRows.times(
                        blocks[i][j].times(
                        eigValsCols));
            }
        }

        // encoding
        logger.info("starting encoding");
        ArrayList<String> key = new ArrayList<String>();
        int it = 0;
        int blockCol = 0;
        int blockRow = 0;
        int[] encodingOrder = Generator.getRandIntArray(startposition,
                endposition);

        while (!msg.isFinished()) {

            double y = transformedBlocks[blockCol][blockRow].get(
                    encodingOrder[it], encodingOrder[it]);
            byte b = (byte) y;

            try {
                transformedBlocks[blockCol][blockRow].set(
                        encodingOrder[it], encodingOrder[it],
                        (msg.nextBit() ? 1 : 0) * OFFSET);
            } catch (IOException e) {
                throw new EncodingException("IOException occured while " +
                        "fetching next bit of the message", e);
            }

            key.add(String.valueOf(encodingOrder[it]));

            it++;
            if (it == bitsInBlock) {
                it = 0;
                blockCol++;
                if (blockCol == embBlocksInCols) {
                    blockCol = 0;
                    blockRow++;
                    if (blockRow == embBlocksInRows ) {
                        throw new EncodingException("Reached end of picture. " +
                                "Message is too big.");
                    }
                }
                encodingOrder = Generator.getRandIntArray(startposition,
                        endposition);
            }
        }
        
        // save key
        try {
            saveKey(keyFilename, key.toArray(new String[0]));
        } catch (IOException e) {
            throw new EncodingException("Could not write out key", e);
        }

        logger.trace("inverse transformation of blocks");
        // inverse transformation
        for (int i = 0; i < embBlocksInCols; i++) {
            for (int j = 0; j < embBlocksInRows; j++) {
                blocks[i][j] =
                        eigValsRows.transpose().times(
                        transformedBlocks[i][j].times(
                        eigValsCols.transpose()));
            }
        }

        // add mean element to every obtained block
        for (int i = 0; i < embBlocksInCols; i++) {
            for (int j = 0; j < embBlocksInRows; j++) {
                blocks[i][j].plusEquals(meanBlock);
            }
        }

        logger.trace("compose blocks");
        // compose image hue component from blocks
        for (int i = 0; i < blocksInCols; i++) {
            for (int j = 0; j < blocksInRows; j++) {

                int colEnd = (i + 1) * blockSize - 1;
                if (i > img.getWidth()) {
                    colRange = colEnd - img.getWidth();
                } else {
                    colRange = colEnd;
                }
                int rowEnd = (j + 1) * blockSize - 1;
                if (j > img.getHeight()) {
                    rowRange = rowEnd - img.getHeight();
                } else {
                    rowRange = rowEnd;
                }

                vals.setMatrix(i * blockSize, colRange,
                        j * blockSize, rowRange, blocks[i][j]);
            }
        }

        switch (img.getLayerCount()) {
            case 1:
                /* Gray image */
                for (int i = 0; i < img.getWidth(); i++) {
                    for (int j = 0; j < img.getHeight(); j++) {
                        img.getRaster().setSample(i, j, 0,
                                ImageUtility.clamp(
                                (int) Math.round(vals.get(i, j))));
                    }
                }
                break;

            case 3:
                // back to RGB color space
                for (int i = 0; i < img.getWidth(); i++) {
                    for (int j = 0; j < img.getHeight(); j++) {
                        int px = img.getRGB(i, j);
                        int[] rgb = ImageUtility.hsv2rgb(vals.get(i, j),
                                saturation[i][j],
                                value[i][j]);

                        byte a = (byte) ((px >>> 24) & 0xFF);
                        byte r = (byte) (rgb[ImageUtility.RED] & 0xff);
                        byte g = (byte) (rgb[ImageUtility.GREEN] & 0xff);
                        byte b = (byte) (rgb[ImageUtility.BLUE] & 0xff);

                        img.setRGB(i, j, BitUtility.byteArrayToInt(new byte[] {
                            a, r, g, b
                        }) );
                    }
                }
                break;

            case 0:
            default:
                throw new EncodingException("unsupported image type");

        }

        logger.info("Encoded " + Math.ceil(key.size() / 8) + " bytes");
        return img;
    }

    public Message decode(StegoImage img, LinkedHashMap<String, String> options)
            throws DecodingException {

        int blockSize;
        int startposition;
        int endposition;

        try {
            blockSize = Integer.valueOf(options.get("block size"));
        } catch (NumberFormatException e) {
            throw new DecodingException("block size must be a valid " +
                    "integer scalar");
        }
        try {
            startposition = Integer.valueOf(options.get("start position"));
        } catch (NumberFormatException e) {
            throw new DecodingException("start position must be a valid " +
                    "integer scalar");
        }
        try {
            endposition = Integer.valueOf(options.get("end position"));
        } catch (NumberFormatException e) {
            throw new DecodingException("end position must be a valid " +
                    "integer scalar");
        }
        if (startposition < 0) {
            throw new DecodingException("start position must be a nonnegative "+
                    "integer");
        }
        if (endposition > blockSize - 1) {
            throw new DecodingException("end position must be a value lesser " +
                    "than block size");
        }
        if (startposition > endposition) {
            throw new DecodingException("start position cannot be greater " +
                    "than end position");
        }
        if (blockSize < 1) {
            throw new DecodingException("block size must be greater " +
                    "than 0");
        }
        if (blockSize > img.getWidth() || blockSize > img.getHeight()) {
            throw new DecodingException("block size cannot be greater " +
                    "than image size");
        }

        String eigColsFilename = options.get("eig cols ArrayLists");
        String eigRowsFilename = options.get("eig rows ArrayLists");
        String keyFilename = options.get("key");
        String meanFilename = options.get("mean");
        double[][] val = new double[img.getWidth()][img.getHeight()];
        int blocksInCols = (int) Math.ceil(img.getWidth() / blockSize);
        int blocksInRows = (int) Math.ceil(img.getHeight() / blockSize);
        // we do not embedd in overlapping blocks
        int embBlocksInCols = (int) Math.floor(img.getWidth() / blockSize);
        int embBlocksInRows = (int) Math.floor(img.getHeight() / blockSize);
        int colRange;
        int rowRange;
        int bitsInBlock = endposition - startposition + 1;
        Matrix meanBlock;
        // matrix with values with message
        Matrix vals;
        // array with image blocks
        Matrix[][] blocks;
        // matrices with eigenArrayLists
        Matrix eigValsCols = null;
        Matrix eigValsRows = null;
        Matrix[][] transformedBlocks;
        File eigColsFile = new File(eigColsFilename);
        File eigRowsFile = new File(eigRowsFilename);
        File meanFile = new File(meanFilename);
        double meanValue;
        
        try {
            meanValue = loadMean(meanFile);
        } catch (Exception e) {
            throw new DecodingException("Could not load mean value from given" +
                                            " file", e);
        }
        
        switch (img.getLayerCount()) {
            case 1:
                /* Gray image */
                for (int i = 0; i < img.getWidth(); i++) {
                    for (int j = 0; j < img.getHeight(); j++) {
                        val[i][j] = img.getRaster().getSampleDouble(i, j, 0);
                    }
                }
                break;

            case 3:
                /* RGB image
                 * methods encodes in hue component of the image
                 * thus we need to convert RGB to HSV */
                for (int i = 0; i < img.getWidth(); i++) {
                    for (int j = 0; j < img.getHeight(); j++) {
                        int px = img.getRGB(i, j);
                        double[] hsv = ImageUtility.rgb2hsv(
                                ImageUtility.getRed(px),
                                ImageUtility.getGreen(px),
                                ImageUtility.getBlue(px));

                        val[i][j] = hsv[ImageUtility.HUE];
                    }
                }
                break;

            case 0:
            default:
                throw new DecodingException("unsupported image type");
        }
        
        vals = new Matrix(val);

        logger.trace("dividing into blocks");
        vals = new Matrix(val);
        // divide image to blocks
        blocks = new Matrix[blocksInCols][blocksInRows];
        for (int i = 0; i < blocksInCols; i++) {
            for (int j = 0; j < blocksInRows; j++) {
                boolean colOverlap = false;
                boolean rowOverlap = false;
                int colEnd = (i + 1) * blockSize - 1;
                if (colEnd > img.getWidth()) {
                    colOverlap = true;
                    colRange = colEnd - img.getWidth();
                } else {
                    colRange = colEnd;
                }
                int rowEnd = (j + 1) * blockSize - 1;
                if (rowEnd > img.getHeight()) {
                    rowOverlap = true;
                    rowRange = rowEnd - img.getHeight();
                } else {
                    rowRange = rowEnd;
                }

                if (colOverlap || rowOverlap) {
                    double tmp[][] = vals.getMatrix(i * blockSize, colRange,
                            j * blockSize, rowRange).getArray();
                    double[][] newBlock = new double[blockSize][blockSize];
                    for (int k = 0; k < blockSize; k++) {
                        for (int l = 0; l < blockSize; l++) {
                            newBlock[k][l] = (k > tmp.length ||
                                    l > tmp[0].length)
                                    ? 0
                                    : tmp[k][l];
                        }
                    }
                    blocks[i][j] = new Matrix(newBlock);
                } else {
                    blocks[i][j] = vals.getMatrix(i * blockSize, colRange,
                            j * blockSize, rowRange);
                }
            }
        }

        
        // calculate mean value
        meanBlock = new Matrix(blockSize, blockSize, meanValue);
        //remove mean element from every block
        for (int i = 0; i < embBlocksInCols; i++) {
            for (int j = 0; j < embBlocksInRows; j++) {
                blocks[i][j].minusEquals(meanBlock);
            }
        }

        logger.trace("performing transformation of blocks");
        // transformation of blocks
        try {
            eigValsCols = loadEigenMatrix(eigColsFile);
            eigValsRows = loadEigenMatrix(eigRowsFile);
        } catch (Exception e) {
            throw new DecodingException("Could not load matrices", e);
        }
        transformedBlocks = new Matrix[embBlocksInCols][embBlocksInRows];
        for (int i = 0; i < embBlocksInCols; i++) {
            for (int j = 0; j < embBlocksInRows; j++) {
                transformedBlocks[i][j] =
                        eigValsRows.times(
                        blocks[i][j].times(
                        eigValsCols));
            }
        }

        // decoding
        logger.info("starting decoding");
        ArrayList<String> key = null;
        int it = 0;
        int blockCol = 0;
        int blockRow = 0;

        try {
            key = loadKey(keyFilename);
        } catch (Exception e) {
            throw new DecodingException("Could not load key from file", e);
        }

        Message msg = null;
        try {
            msg = new Message((int) Math.ceil(key.size() / 8));
        } catch (IOException e) {
            throw new DecodingException("Could not create message: ", e);
        }
        
        for (int i = 0; i < key.size(); i++) {

            int decodingPlace = Integer.valueOf(key.get(i));

            double y = transformedBlocks[blockCol][blockRow].get(
                    decodingPlace, decodingPlace);
            try {
                msg.setNext(Math.round(y / OFFSET) == 0 ? false : true);
            } catch (IOException e) {
                throw new DecodingException("IOException occured while " +
                        "setting next bit of the message", e);
            }

            it++;
            if (it == bitsInBlock) {
                it = 0;
                blockCol++;
                if (blockCol == blocksInCols) {
                    blockCol = 0;
                    blockRow++;
                    if (blockRow == blocksInRows) {
                        throw new DecodingException("Reached end of picture. " +
                                "Message is too big.");
                    }
                }
            }
        }
        
        logger.info("Retrieved message: " + msg.getSize() + " bytes.");
        return msg;
    }

    private Matrix getSortedEigenArrayLists(EigenvalueDecomposition ed) {
        double[] eigValue = diag(ed.getD().getArray());
        double[][] eigArrayList = ed.getV().getArray();

        /* We only need the largest associated values of the eigenvalues. 
         * Thus we sort them (and keep an index of them) */
        int num = eigValue.length;
        int[] index = new int[num];
        /* Temporary new eigArrayList */
        double[][] tempArrayList = new double[num][num];

        for (int i = 0; i < num; i++) /* Enumerate all the entries */ {
            index[i] = i;
        }
        
        doubleQuickSort(eigValue, index, 0, num - 1);

        // Put the index in inverse 
        int[] tempV = new int[num];
        for (int j = 0; j < num; j++) {
            tempV[num - 1 - j] = index[j];
        }
        index = tempV;

        /* Put the sorted eigenvalues in the appropiate columns. */
        for (int col = num - 1; col >= 0; col--) {
            for (int rows = 0; rows < num; rows++) {
                tempArrayList[rows][col] = eigArrayList[rows][index[col]];
            }
        }
        return new Matrix(tempArrayList, num, num);
    }

    private Matrix loadEigenMatrix(File eigFile) throws FileNotFoundException,
            IOException {
        BufferedReader br = new BufferedReader(new FileReader(eigFile));
        Matrix m = Matrix.read(br);
        br.close();
        return m;
    }

    private void saveEigenMatrices(Matrix eigValsCols, File eigColsFile,
            Matrix eigValsRows, File eigRowsFile)
            throws IOException {
        
        eigColsFile = 
                new File(
                FileUtility.getUniqueFilename(eigColsFile.getAbsolutePath()));
        
        eigRowsFile = 
                new File(
                FileUtility.getUniqueFilename(eigRowsFile.getAbsolutePath()));
        
        PrintWriter colsOut = new PrintWriter(new FileWriter(eigColsFile));
        eigValsCols.print(colsOut, 20, 20);
        colsOut.close();
        PrintWriter rowsOut = new PrintWriter(new FileWriter(eigRowsFile));
        eigValsRows.print(rowsOut, 20, 20);
        rowsOut.close();
    }

    private ArrayList<String> loadKey(String keyFilename)
            throws FileNotFoundException, IOException {
        ArrayList<String> key = new ArrayList<String>();
        CSVReader reader = new CSVReader(new FileReader(keyFilename));
        String[] nextLine;
        while ((nextLine = reader.readNext()) != null) {
            // nextLine[] is an array of values from the line
            for (int i = 0; i < nextLine.length; i++) {
                key.add(nextLine[i]);
            }
        }

        return key;
    }

    private void saveKey(String keyFilename, String[] key) throws IOException {
        
        keyFilename = FileUtility.getUniqueFilename(keyFilename);
        
        CSVWriter writer = new CSVWriter(new FileWriter(keyFilename));
        writer.writeNext(key);
        writer.close();
    }
    
    private double loadMean(File meanFile) throws FileNotFoundException, 
                                                                IOException {
        FileReader fw = new FileReader(meanFile); 
        BufferedReader bw = new BufferedReader(fw);
        String line = bw.readLine();
        if (line == null) {
            throw new IOException("Mean file is empty");
        }
        double m = Double.valueOf(line);
        bw.close();
        return m;
    }
    
    private void saveMean(double meanValue, File meanFile) throws IOException {
        
        meanFile = new File(
                FileUtility.getUniqueFilename(meanFile.getAbsolutePath()));
        
        FileWriter fw = new FileWriter(meanFile); 
        BufferedWriter bw = new BufferedWriter(fw);
        bw.write(String.valueOf(meanValue));
        bw.close();
    }    

    /** 
     * Find the diagonal of an matrix. 
     * 
     * @param m the number of rows and columns must be the same 
     * @return  the diagonal of the matrix 
     */
    private static double[] diag(double[][] m) {
        
        double[] d = new double[m.length];
        for (int i = 0; i < m.length; i++) {
            d[i] = m[i][i];
        }
        return d;
    }

    /** 
     * Quick sort on a ArrayList with an index.
     * 
     * @param a the array of numbers. This will be modified and sorted 
     * in ascending  order (smallest to highest)
     * @param index the index of the numbers as related to original 
     *  location. 
     * @param lo0  the index where to start from. Usually 0. 
     * @param hi0  the index where to stop. Usually a.length() 
     */
    private static void doubleQuickSort(double a[], int index[], 
                                                        int lo0, int hi0) {
        int lo = lo0;
        int hi = hi0;
        double mid;

        if (hi0 > lo0) {

            /* Arbitrarily establishing partition element as the midpoint of 
             * the array. 
             */
            mid = a[(lo0 + hi0) / 2];
            // loop through the array until indices cross 
            while (lo <= hi) {
                /* find the first element that is greater than or equal to 
                 * the partition element starting from the left Index. 
                 */
                while ((lo < hi0) && (a[lo] < mid)) {
                    ++lo;
                }

                /* find an element that is smaller than or equal to 
                 * the partition element starting from the right Index. 
                 */
                while ((hi > lo0) && (a[hi] > mid)) {
                    --hi;
                }

                // if the indexes have not crossed, swap 
                if (lo <= hi) {
                    swap(a, index, lo, hi);
                    ++lo;
                    --hi;
                }
            }
            /* If the right index has not reached the left side of array 
             * must now sort the left partition. 
             */
            if (lo0 < hi) {
                doubleQuickSort(a, index, lo0, hi);
            }
            /* If the left index has not reached the right side of array 
             * must now sort the right partition. 
             */
            if (lo < hi0) {
                doubleQuickSort(a, index, lo, hi0);
            }
        }
    }

    private static void swap(double a[], int[] index, int i, int j) {
        double T;
        T = a[i];
        a[i] = a[j];
        a[j] = T;
        // Index 
        index[i] = i;
        index[j] = j;
    }
    
}
