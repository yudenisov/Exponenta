/*
 *    Virtual Steganographic Laboratory (VSL)
 *    Copyright (C) 2008-2011  M. Wegrzyn <bend-up@users.sourceforge.net>

 *    This file is part of Virtual Steganographic Laboratory (VSL).

 *    VSL is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.

 *    VSL is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.

 *    You should have received a copy of the GNU General Public License
 *    along with VSL.  If not, see <http://www.gnu.org/licenses/>.
 */
package pl.edu.zut.wi.vsl.modules.distortions;

import java.awt.Image;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.awt.image.FilteredImageSource;
import java.awt.image.ImageProducer;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.awt.image.CropImageFilter;
import pl.edu.zut.wi.vsl.commons.StegoImage;
import pl.edu.zut.wi.vsl.commons.distortions.DistortionException;
import pl.edu.zut.wi.vsl.commons.distortions.DistortionTechnique;
import pl.edu.zut.wi.vsl.commons.utils.ImageConverter;
import pl.edu.zut.wi.vsl.commons.utils.ImageUtility;
import org.apache.log4j.Logger;

/**
 * Module performing cropping of the image.
 * 
 * @author Michal Wegrzyn
 */
public class CroppingImpl implements DistortionTechnique {

    private final static Logger logger = Logger.getLogger(CroppingImpl.class);

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        if (args.length == 1) {
            if (args[0].equals("--help") ||
                    args[0].equals("-help")  ||
                    args[0].equals("?")      ||
                    args[0].equals("/?")) {
                printUsage();
                System.exit(1);
            }
        } else if (args.length != 6) {
            System.out.println("Unsupported option");
            printUsage();
            System.exit(1);
        }
        
        StegoImage si = null;
        LinkedHashMap<String, String> o = new LinkedHashMap<String, String>();
        
        o.put("x", args[0]);
        o.put("y", args[1]);
        o.put("w", args[2]);
        o.put("h", args[3]);
        
        CroppingImpl sp = new CroppingImpl();

        try {
            BufferedImage bi = ImageUtility.readImage(args[4]);
            si = new StegoImage(bi, args[4]);
        } catch (IllegalArgumentException e) {
            logger.error("Could not create stegoimage.", e);
            System.exit(1);
        } catch (NullPointerException e) {
            logger.error("Could not create stegoimage.", e);
            System.exit(1);
        } catch (IOException e) {
            logger.error("Could not create stegoimage.", e);
            System.exit(1);
        }

        StegoImage result = null;
        
        try {
            result = sp.distort(si, o);
        } catch (DistortionException e) {
            logger.error("Could not perform distortion.", e);
            System.exit(1);
        }
        try {
            result.write(args[5]);
        } catch (IllegalArgumentException e) {
            logger.error("Could not write result image.", e);
            System.exit(1);
        } catch (IOException e) {
            logger.error("Could not write result image.", e);
            System.exit(1);
        } catch (NullPointerException e) {
            logger.error("Could not write result image.", e);
            System.exit(1);
        }

    }

    public CroppingImpl() {
    }

    /**
     * Prints usage to console.
     */
    public static void printUsage() {
        System.out.println("Usage: \n" +
"vsl-module-distortion-cropping <x> <y> <w> <h> <path to image> \n" +
"                               <path to result image>\n"+
"x - the x location of the top of the rectangle to be extracted\n" +
"y - the y location of the top of the rectangle to be extracted\n" +
"w - the width of the rectangle to be extracted\n" +
"h - the height of the rectangle to be extracted");
    }

    public StegoImage distort(StegoImage image, 
            LinkedHashMap<String, String> options) 
                        throws DistortionException {
        int x, y, w, h;
        
        try {
            x = Integer.valueOf(options.get("x"));
        } catch (NumberFormatException e) {
            throw new DistortionException("x must be a valid integer scalar");
        }
        try {
            y = Integer.valueOf(options.get("y"));
        } catch (NumberFormatException e) {
            throw new DistortionException("y must be a valid integer scalar");
        }
        try {
            w = Integer.valueOf(options.get("w"));
        } catch (NumberFormatException e) {
            throw new DistortionException("w must be a valid integer scalar");
        }
        try {
            h = Integer.valueOf(options.get("h"));
        } catch (NumberFormatException e) {
            throw new DistortionException("h must be a valid integer scalar");
        }
        if (x < 0) {
            throw new DistortionException("x must be a nonnegative integer");
        }
        if (y < 0) {
            throw new DistortionException("y must be a nonnegative integer");
        }
        if (w <= 0) {
            throw new DistortionException("w must be greater than 0");
        }
        if (h <= 0) {
            throw new DistortionException("h must be greater than 0");
        }
        
        ImageProducer imageprod = new FilteredImageSource(image.getSource(), 
                                        new CropImageFilter(x, y, w, h));
        Image filteredImage = Toolkit.getDefaultToolkit().createImage(
                                                    imageprod);
        BufferedImage bi = ImageConverter.toCompatibleBufferedImage(
                                                    filteredImage, image);
        try {
            return new StegoImage(bi, image.getPath());
        } catch (IOException e) {
            throw new DistortionException("Could not create final image", e);
        }
    }

}
