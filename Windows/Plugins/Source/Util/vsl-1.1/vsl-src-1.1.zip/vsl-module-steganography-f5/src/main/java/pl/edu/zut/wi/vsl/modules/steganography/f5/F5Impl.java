/*
 *    Virtual Steganographic Laboratory (VSL)
 *    Copyright (C) 2008-2011  M. Wegrzyn <bend-up@users.sourceforge.net>

 *    This file is part of Virtual Steganographic Laboratory (VSL).

 *    VSL is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.

 *    VSL is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.

 *    You should have received a copy of the GNU General Public License
 *    along with VSL.  If not, see <http://www.gnu.org/licenses/>.
 */
package pl.edu.zut.wi.vsl.modules.steganography.f5;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.LinkedHashMap;
import org.apache.log4j.Logger;
import pl.edu.zut.wi.vsl.commons.steganography.DecodingException;
import pl.edu.zut.wi.vsl.commons.StegoImage;
import pl.edu.zut.wi.vsl.commons.StegoPackage;
import pl.edu.zut.wi.vsl.commons.steganography.SteganographicTechnique;
import pl.edu.zut.wi.vsl.commons.steganography.EncodingException;
import pl.edu.zut.wi.vsl.commons.Message;
import pl.edu.zut.wi.vsl.commons.jpeg.HuffmanDecode;
import pl.edu.zut.wi.vsl.commons.utils.FileUtility;
import pl.edu.zut.wi.vsl.commons.utils.ImageUtility;
import pl.edu.zut.wi.vsl.modules.steganography.f5.crypt.F5Random;
import pl.edu.zut.wi.vsl.modules.steganography.f5.crypt.Permutation;


/**
 * F5 steganography.
 * <p>
 * F5 algorithm was introduced by Adreas Westfeld in 2001.
 * </p>
 * <p>
 * F5 embeds data using DCT transformation. F5 instead of replacing
 * the least-significant bit of a DCT coefficient, decrements
 * its absolute value in a process called matrix encoding.
 * </p>
 * <p>
 * This class is adaptation of F5 implementation (f5r11.zip)
 * provided by Andreas Westfeld.
 * </p>
 * <p>
 * You can contact him at <westfeld@inf.tu-dresden.de> or visit his website
 * for more informations - {@link http://www.inf.tu-dresden.de/~aw4}.
 * </p>
 * 
 * @author Michal Wegrzyn
 */
public class F5Impl implements SteganographicTechnique {

    private final static Logger logger = Logger.getLogger(F5Impl.class);

    private static final byte[] deZigZag = {
       0,  1,  5,  6, 14, 15, 27, 28,
       2,  4,  7, 13, 16, 26, 29, 42,
       3,  8, 12, 17, 25, 30, 41, 43,
       9, 11, 18, 24, 31, 40, 44, 53,
      10, 19, 23, 32, 39, 45, 52, 54,
      20, 22, 33, 38, 46, 51, 55, 60,
      21, 34, 37, 47, 50, 56, 59, 61,
      35, 36, 48, 49, 57, 58, 62, 63
    };

    public F5Impl() {
    }

    public static void main(String[] args) {
        
        F5Impl l = new F5Impl();
        
        switch(args.length) {
            // encoding
            case 5:
                LinkedHashMap<String, String> o = 
                        new LinkedHashMap<String, String>();
                o.put("password", args[3]);
                o.put("comment", args[4]);
                o.put("quality", args[5]);
                o.put("output", args[2]);
                StegoImage si = null;
                Message msg = null;
                try {
                    msg = new Message(args[1]);
                } catch (FileNotFoundException e) {
                    logger.error("Could not find message file.", e);
                    System.exit(1);
                } catch (IOException e) {
                    logger.error("Could not create message object.", e);
                    System.exit(1);

                }
                try {
                    BufferedImage bi = ImageUtility.readImage(args[0]);
                    si = new StegoImage(bi, args[0]);
                } catch (IllegalArgumentException e) {
                    logger.error("Could not create stegoimage.", e);
                    System.exit(1);
                } catch (NullPointerException e) {
                    logger.error("Could not create stegoimage.", e);
                    System.exit(1);
                } catch (IOException e) {
                    logger.error("Could not create stegoimage.", e);
                    System.exit(1);
                }

                StegoPackage p = new StegoPackage(si, msg);
                StegoImage result = null;

                try {
                    result = l.encode(p, o);
                } catch (EncodingException e) {
                    logger.error("Could not encode message.", e);
                    System.exit(1);
                }
                try {
                    result.write(args[2]);
                } catch (IllegalArgumentException e) {
                    logger.error("Could not write result image.", e);
                    System.exit(1);
                } catch (IOException e) {
                    logger.error("Could not write result image.", e);
                    System.exit(1);
                }

                break;
            // decoding   
            case 4:
                LinkedHashMap<String, String> o2 = 
                        new LinkedHashMap<String, String>();
                o2.put("password", args[2]);
                StegoImage si2 = null;
                Message rmsg = null;

                try {
                    BufferedImage bi = ImageUtility.readImage(args[0]);
                    si2 = new StegoImage(bi, args[0]);
                } catch (IllegalArgumentException e) {
                    logger.error("Could not create stegoimage.", e);
                    System.exit(1);
                } catch (NullPointerException e) {
                    logger.error("Could not create stegoimage.", e);
                    System.exit(1);
                } catch (IOException e) {
                    logger.error("Could not create stegoimage.", e);
                    System.exit(1);
                }

                try {
                    rmsg = l.decode(si2, o2);
                } catch (DecodingException e) {
                    logger.error("Could not decode message.", e);
                    System.exit(1);
                }
                try {
                    rmsg.writeBytesToFile(args[1]);
                } catch (IllegalArgumentException e) {
                    logger.error("Could not write result image.", e);
                    System.exit(1);
                } catch (IOException e) {
                    logger.error("Could not write result image.", e);
                    System.exit(1);
                }
                break;
            case 1:
                if (args[0].equals("--help") ||
                        args[0].equals("-help")  ||
                        args[0].equals("?")      ||
                        args[0].equals("/?")) {
                    printUsage();
                }
                break;
            default:
                System.out.println("Unsupported option");
                F5Impl.printUsage();
                break;
        }
    }
    
    public StegoImage encode(StegoPackage p, 
            LinkedHashMap<String, String> options) throws EncodingException {

        ByteArrayOutputStream f5Output = new ByteArrayOutputStream();
        int quality = Integer.parseInt( options.get("quality") );
        String comment = options.get("comment");
        String name = "original_f5_output_" + F5Impl.class.hashCode() + ".jpg";
        String output = FileUtility.getUniqueFilename(name);
        String password = options.get("password");

        JpegEncoder jpg = null;
        try {
            jpg = new JpegEncoder(p.getImage(), quality, f5Output, comment);
        } catch (IOException e) {
            throw new EncodingException("Exception during creating JpegEncoder", e);
        } catch (InterruptedException e) {
            logger.info("Interrupted F5 module, returning original image", e);
            return p.getImage();
        }
        try {
            jpg.Compress(new ByteArrayInputStream(p.getMessage().getBytes()), password);
        } catch (IOException e) {
            throw new EncodingException("Exception during compression", e);
        }

        StegoImage f5Image;
        try {
            // Save original F5 output
            File f5File = FileUtility.writeFile( f5Output.toByteArray(), output);
            // Create new Stegoimage from created jpeg byte[] data
            f5Image = new StegoImage(f5File, p.getImage().getPath());
        } catch (IOException e) {
            throw new EncodingException("Exception occured during F5 encoding", e);
        }

        return f5Image;
    }


    public Message decode(StegoImage simage, LinkedHashMap<String, String> options)
            throws DecodingException {

        byte[] carrier = simage.getJpegBytes(); //carrier data
        int[] coeff;                            // dct values
        ByteArrayOutputStream baos;             // embedded file (output file)
        String password = options.get("password");

	try {
	    baos = new ByteArrayOutputStream();
	    HuffmanDecode hd = new HuffmanDecode(carrier);

            logger.info("Huffman decoding starts");
	    coeff=hd.decode();
            logger.info("Permutation starts");
	    F5Random random = new F5Random(password.getBytes());
	    Permutation permutation = new Permutation(coeff.length, random);
            logger.info(coeff.length+" indices shuffled");
	    int extractedByte=0;
	    int availableExtractedBits=0;
	    int extractedFileLength=0;
	    int nBytesExtracted=0;
	    int shuffledIndex=0;
	    int extractedBit;
	    int i;

            logger.info("Extraction starts");

            // extract length information
	    for (i=0; availableExtractedBits<32; i++) {
		shuffledIndex = permutation.getShuffled(i);
		if (shuffledIndex%64 == 0) continue; // skip DC coefficients
		shuffledIndex = shuffledIndex-(shuffledIndex%64)+deZigZag[shuffledIndex%64];
                if (coeff[shuffledIndex] == 0) continue; // skip zeroes
		if (coeff[shuffledIndex] > 0)
		    extractedBit=coeff[shuffledIndex]&1;
		else
		    extractedBit=1-(coeff[shuffledIndex]&1);
		extractedFileLength |= extractedBit << availableExtractedBits++;
	    }
	    // remove pseudo random pad
	    extractedFileLength ^= random.getNextByte();
	    extractedFileLength ^= random.getNextByte()<<8;
	    extractedFileLength ^= random.getNextByte()<<16;
	    extractedFileLength ^= random.getNextByte()<<24;
	    int k = extractedFileLength >> 24;
	    k %= 32;
	    int n = (1 << k)-1;
	    extractedFileLength &= 0x007fffff;

            logger.info("Length of embedded file: "+extractedFileLength+" bytes");
	    availableExtractedBits = 0;

	    if (n>0) {

		int startOfN = i;
		int hash;
		logger.info("(1, "+n+", "+k+") code used");
extractingLoop:
		do {
		    // 1. read n places, and calculate k bits
		    hash = 0;
		    int code = 1;
		    for (i=0; code<=n; i++) {
			// check for pending end of coeff
			if (startOfN+i>=coeff.length) break extractingLoop;
			shuffledIndex = permutation.getShuffled(startOfN+i);
			if (shuffledIndex%64 == 0) continue; // skip DC coefficients
			shuffledIndex = shuffledIndex-(shuffledIndex%64)+deZigZag[shuffledIndex%64];
			if (coeff[shuffledIndex] == 0) continue; // skip zeroes
			if (coeff[shuffledIndex] > 0)
			    extractedBit=coeff[shuffledIndex]&1;
			else
			    extractedBit=1-(coeff[shuffledIndex]&1);
			if (extractedBit==1) {
			    hash ^= code;
			}
			code++;
		    }
		    startOfN += i;
		    // 2. write k bits bytewise
		    for (i=0; i<k; i++) {
			extractedByte |= ((hash>>i)&1) << availableExtractedBits++;
			if (availableExtractedBits == 8) {
			    // remove pseudo random pad
			    extractedByte ^= random.getNextByte();
			    baos.write((byte) extractedByte);
			    extractedByte=0;
			    availableExtractedBits=0;
			    nBytesExtracted++;
			    // check for pending end of embedded data
			    if (nBytesExtracted==extractedFileLength)
				break extractingLoop;
			}
		    }
		} while (true);
	    } else {
		logger.info("Default code used");
		for (; i<coeff.length; i++) {
		    shuffledIndex = permutation.getShuffled(i);
		    if (shuffledIndex%64 == 0) continue; // skip DC coefficients
		    shuffledIndex = shuffledIndex-(shuffledIndex%64)+deZigZag[shuffledIndex%64];
		    if (coeff[shuffledIndex] == 0) continue; // skip zeroes
		    if (coeff[shuffledIndex] > 0)
			extractedBit=coeff[shuffledIndex]&1;
		    else
			extractedBit=1-(coeff[shuffledIndex]&1);
		    extractedByte |= extractedBit << availableExtractedBits++;
		    if (availableExtractedBits == 8) {
			// remove pseudo random pad
			extractedByte ^= random.getNextByte();
			baos.write((byte) extractedByte);
			extractedByte=0;
			availableExtractedBits=0;
			nBytesExtracted++;
			if (nBytesExtracted==extractedFileLength)
			    break;
		    }
		}
	    }
	    if (nBytesExtracted<extractedFileLength) {
		logger.info("Incomplete file: only "+
		    nBytesExtracted+" of "+extractedFileLength+
		    " bytes extracted");
	    }
	} catch(Exception e) {
            logger.error("Error occured during F5 extraction.", e);
	    throw new DecodingException("Error occured during F5 extraction", e);
	}

        return new Message(baos.toByteArray());
    }

    /**
     * Prints usage to console.
     */
    private static void printUsage() {
        System.out.println("Usage: \n" +
"Encoding: vsl-module-lsb <path to image> <path to message> \n" +
"                         <path to result image> <password> <comment>\n"+
"                         <quality>" +
"Decoding: vsl-module-lsb <path to image> <path to result message> \n" +
"                         <password> \n" +
"password - password used in F5 steganography process \n" +
"quality - quality (0 to 100) of the output JPEG \n" +
"comment - JPEG comment; default: \"JPEG Encoder Copyright 1998, "
                + "James R. Weeks and BioElectroMech.  \"" +
"endbits - the end bit position for possible bits (0-7 integer)");
    }

}
