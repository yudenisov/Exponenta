/*
 *    Virtual Steganographic Laboratory (VSL)
 *    Copyright (C) 2008-2011  M. Wegrzyn <bend-up@users.sourceforge.net>

 *    This file is part of Virtual Steganographic Laboratory (VSL).

 *    VSL is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.

 *    VSL is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.

 *    You should have received a copy of the GNU General Public License
 *    along with VSL.  If not, see <http://www.gnu.org/licenses/>.
 */
package pl.edu.zut.wi.vsl.modules.steganography.f5.crypt;

import sun.security.provider.SecureRandom;

/**
 * Part of F5 implementation provided by Andreas Westfeld.
 * <p>
 * You can contact him at <westfeld@inf.tu-dresden.de> or visit his website
 * for more informations - {@link http://www.inf.tu-dresden.de/~aw4}.
 * </p>
 * @author Andreas Westfeld
 */
public class F5Random {
    private SecureRandom random=null;
    private byte[] b=null;

    public F5Random(byte[] password) {
	random = new SecureRandom();
	random.engineSetSeed(password);
	b = new byte[1];
    }

    // get a random integer 0 ... (maxValue-1)
    public int getNextValue(int maxValue) {
	int retVal = getNextByte()
			| (getNextByte() << 8)
			| (getNextByte() << 16)
			| (getNextByte() << 24);
	retVal %= maxValue;
	if (retVal<0)
	    retVal += maxValue;
	return retVal;
    }

    // get a random byte
    public int getNextByte() {
	random.engineNextBytes(b);
	return b[0];
    }
}
