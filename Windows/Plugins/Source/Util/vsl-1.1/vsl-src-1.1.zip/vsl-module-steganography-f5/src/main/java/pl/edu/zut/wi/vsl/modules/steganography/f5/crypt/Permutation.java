/*
 *    Virtual Steganographic Laboratory (VSL)
 *    Copyright (C) 2008-2011  M. Wegrzyn <bend-up@users.sourceforge.net>

 *    This file is part of Virtual Steganographic Laboratory (VSL).

 *    VSL is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.

 *    VSL is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.

 *    You should have received a copy of the GNU General Public License
 *    along with VSL.  If not, see <http://www.gnu.org/licenses/>.
 */
package pl.edu.zut.wi.vsl.modules.steganography.f5.crypt;

/**
 * Part of F5 implementation provided by Andreas Westfeld.
 * <p>
 * You can contact him at <westfeld@inf.tu-dresden.de> or visit his website
 * for more informations - {@link http://www.inf.tu-dresden.de/~aw4}.
 * </p>
 * @author Andreas Westfeld
 */
public class Permutation {
    int[] shuffled;   // shuffled sequence

    // The constructor of class Permutation creates a shuffled
    // sequence of the integers 0 ... (size-1).
    public Permutation(int size, F5Random random) {
        int i, randomIndex, tmp;
        shuffled = new int[size];

	// To create the shuffled sequence, we initialise an array
	// with the integers 0 ... (size-1).
        for (i=0; i<size; i++)	// initialise with �size� integers
            shuffled[i] = i;
        int maxRandom = size;	// set number of entries to shuffle
	for (i=0; i<size; i++) {	// shuffle entries
	    randomIndex = random.getNextValue(maxRandom--);
	    tmp = shuffled[randomIndex];
	    shuffled[randomIndex] = shuffled[maxRandom];
	    shuffled[maxRandom] = tmp;
	}
    }

    // get value #i from the shuffled sequence
    public int getShuffled(int i) {
	return shuffled[i];
    }
}
